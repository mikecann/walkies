// State machines for Convex: define machines on your own tables, run their
// steps in your mutations, and draw them from the same rules they run.
export * from "./machine.js";
export { duration, linkedDiagram, stateDiagram } from "./mermaid.js";
