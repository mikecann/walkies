# State machines for Convex

Write your app's lifecycles (an order, a build, a booking) as state machines that run inside your own Convex mutations. The rules are plain data, so the diagram is drawn from the same rules the code runs and can't drift from it. The state is a typed field on your own row, so you query it like any other field.

It's a Convex component, `@convex-dev/state-machines`: a library your mutations call, and a small component that keeps each machine's history. It's experimental: not published to npm yet.

## Why

We've been climbing the abstraction ladder for a long time now. We used to understand machine code, then assembly, then C, then higher-level languages like Java and JavaScript, and at each step most of us stopped reading the level below.

To be totally honest, most of us don't really read the code anymore either, the agents write it. So if we still want to understand our apps at all, I think our understanding has to move up a level too. What I'm proposing is that the next level is the state machine: the states your app can be in, and the ways it can get from one to another.

Now this won't give you the whole picture. Plenty of an app isn't a state machine, so there's other work you'll still need to do to understand the rest of it. But it does bite off a good chunk: the lifecycles, the things in your app that move through stages over time, which in my experience is where a lot of the nasty bugs live.

The important bit is that the diagram isn't something someone drew after the fact. It's generated from the same rules the code runs, so you can look at it and see what your agent actually built, without reading the code.

The great thing about doing this on Convex is that the states live right in your schema, so you can see exactly which states a row can be in, and the database holds you to them. A row's state has to be one of those states, with exactly that state's data, or Convex won't store it. So a project can't be `building` without the version it's building, for example.

## How it works on Convex

- **The state lives on your row.** It's a union in your schema, one member per state, tagged with `kind`. Each state carries only its own data, so a combination that makes no sense can't be stored, and `state.kind` takes an ordinary index.
- **A step is one mutation.** Guards can read the database, effects write your tables, and the new state commits with them, or nothing does.
- **Asking is free.** `inspect` runs the same decision as `send` without writing, in a query, so a page can show what you can do next, and why not, reactively.

## Install

```bash
npm install @convex-dev/state-machines
```

Then install its component in `convex/convex.config.ts`:

```ts
import { defineApp } from "convex/server";
import stateMachines from "@convex-dev/state-machines/convex.config.js";

const app = defineApp();
app.use(stateMachines);
export default app;
```

## How to use it

The walkthrough is [examples/lets-build-it](examples/lets-build-it/README.md): Let's Build It, where kids build games by prompting an AI. A **project** goes from no app, to building, to ready, and through editing when the kid changes it. Each build is a **version**, with a 20-second watchdog, fallback models, and a refund if it fails.

### 1. The states, in your schema

```ts
// convex/states.ts
export const versionState = v.union(
  v.object({ kind: v.literal("building"), model }),
  v.object({ kind: v.literal("ready"), model, builtAt: v.number() }),
  v.object({ kind: v.literal("failed"), model, error: v.string(), refunded: v.number() }),
  v.object({ kind: v.literal("timedOut"), model, refunded: v.number() }),
  v.object({ kind: v.literal("cancelled"), refunded: v.number() }),
);

// convex/schema.ts
import { machineTimers } from "@convex-dev/state-machines";

export default defineSchema({
  projects: defineTable({ accountId: v.id("accounts"), name: v.string(), nextNumber: v.number(), state: projectState }),
  versions: defineTable({ projectId: v.id("projects"), /* ... */ state: versionState, stateTimers: machineTimers }) // its timers, beside its state
    .index("by_project_state", ["projectId", "state.kind", "number"]),
});
```

### 2. The rules, then the code behind them

The first argument is the rules, as data. The second is the code that the names in the rules point at.

```ts
// convex/version.ts
import { defineMachine } from "@convex-dev/state-machines";

export const version = defineMachine(schema, {
  name: "version",
  table: "versions",
  events: {
    server: { SUCCEEDED: {}, FAILED: { error: v.string() }, TRY_FALLBACK: {} }, // the build pipeline
    project: { BUILD: {}, CANCEL: {} },                                          // only its project sends these
  },
  guards: { hasFallbackModel: "There's no other model left to try." },
  states: {
    start: { on: { BUILD: { to: "building", effect: "firstModel" } } }, // how a row is born
    building: {
      timers: { TIMED_OUT: { after: BUILD_TIMEOUT_MS } },
      on: {
        SUCCEEDED: { to: "ready", effect: "finish", sends: [{ machine: "project", event: "BUILD_SUCCEEDED", onRefused: "ignore" }] },
        TIMED_OUT: { to: "timedOut", effect: "refundTimeout", sends: [{ machine: "project", event: "BUILD_FAILED", onRefused: "ignore" }] },
        TRY_FALLBACK: { guard: "hasFallbackModel", effect: "tryNextModel" }, // no `to`: stays building
        CANCEL: { to: "cancelled", effect: "refundCancel" },
        // FAILED, like TIMED_OUT
      },
    },
    ready: {}, failed: {}, timedOut: {}, cancelled: {}, // final: nothing more happens
  },
}, {
  guards: { hasFallbackModel: (_ctx, { state }) => nextModel(state.model) !== undefined },
  effects: {
    firstModel: async () => ({ kind: "building", model: MODELS[0] }),
    tryNextModel: async (_ctx, { state }) => ({ ...state, model: nextModel(state.model) ?? state.model }),
    finish: async (_ctx, { state }) => ({ kind: "ready", model: state.model, builtAt: Date.now() }),
    // refundTimeout, refundCancel: give the credits back, and return the next state
  },
  links: { "project.BUILD_SUCCEEDED": ({ row }) => row.projectId, "project.BUILD_FAILED": ({ row }) => row.projectId },
});
```

### 3. Wiring it up

Every machine goes in one catalog, which checks them together when the app loads and makes the app's builders.

```ts
// convex/machines.ts
import { defineMachines, deliveryArgs, type Machines } from "@convex-dev/state-machines";

export const machines: Machines<typeof schema> = defineMachines(schema, [project, version], {
  ...{ mutation, internalMutation, internalQuery }, // Convex's raw builders, from ./_generated/server
  deliver: internal.machines.deliver,
  component: components.stateMachines,
});
export const deliver = machines.internalMutation({ args: deliveryArgs, handler: machines.deliver }); // timers and links

// convex/functions.ts: what app code imports instead of ./_generated/server
export const { mutation, internalMutation, internalQuery } = machines;
```

### 4. Calling it

```ts
// convex/projects.ts
export const send = mutation({
  args: { projectId: v.id("projects"), event: project.events.owner },
  returns: project.results.send,
  handler: async (ctx, { projectId, event }) => await project.send(ctx, projectId, event),
});

// What the kid can do next, and why not. Reactive, like any query.
export const nextSteps = query({
  args: { projectId: v.id("projects") },
  returns: project.results.inspect,
  handler: async (ctx, { projectId }) => await project.inspect(ctx, projectId),
});
```

### 5. The diagram

`stateDiagram(manifest)` draws one machine as Mermaid, and `linkedDiagram(manifests)` draws every machine and the links between them, from `machines.manifests`. The example's `npm run diagrams` writes them all to [docs/diagrams.md](examples/lets-build-it/docs/diagrams.md), and its check fails if they're out of date. Here's the version:

```mermaid
stateDiagram-v2
  direction LR
  state "building" as building
  building : model
  state "ready" as ready
  ready : model, builtAt
  state "failed" as failed
  failed : model, error, refunded
  state "timedOut" as timedOut
  timedOut : model, refunded
  state "cancelled" as cancelled
  cancelled : refunded
  [*] --> building : BUILD from project / firstModel
  building --> ready : SUCCEEDED (server) / finish, sends BUILD_SUCCEEDED to project (ignore)
  building --> failed : FAILED(error) (server) / refundFailure, sends BUILD_FAILED to project (ignore)
  building --> timedOut : TIMED_OUT after 20 seconds / refundTimeout, sends BUILD_FAILED to project (ignore)
  building --> building : TRY_FALLBACK (server) [hasFallbackModel] / tryNextModel
  building --> cancelled : CANCEL from project / refundCancel
  ready --> [*]
  failed --> [*]
  timedOut --> [*]
  cancelled --> [*]
```

## Using it in an existing app

You can move one lifecycle at a time: an order, a build, a booking. Each one does mean reshaping the table it lives on, and changing the code that writes to it. Your other tables stay as they are, even one that already has a `state` union you'll move over later (see "State fields that aren't machines yet" below).

**What changes**

- **The table.** A status field, and the optional fields only some statuses use (`status: "failed"` with `error?` and `refundedAt?`), become one `state` field: a union with a member per state, each holding only its own data. Add `stateTimers: machineTimers` beside it if any state has a timer. The table's other fields stay.
- **Reads.** `row.status` becomes `row.state.kind`, and an index on `status` becomes one on `state.kind`.
- **Writes.** A patch that sets the status becomes an event, `machine.send(ctx, id, event)`. An insert becomes `machine.create(ctx, fields, event)`, and a delete becomes a transition into a final state, or `purge`. Webhooks and actions report back through an internal mutation, as `server` events.

**How to move one over**

1. **Write the machine** from what your code does today: its states, events, guards and effects. Draw it with `stateDiagram` and check the picture matches the lifecycle you think you have. It often doesn't, and that's the point.
2. **Migrate the rows** the usual Convex way. Add `state` (and `stateTimers`) as optional fields, have the code that writes the status set `state` too, and backfill every row from its old fields with a migration ([the migrations component](https://www.convex.dev/components/migrations) helps). Then, in one deploy, make the fields required and add the machine: `defineMachine` needs the field required. A migration writes `state` directly, which the lint rule flags, so give its `eslint-disable` a reason.
3. **Switch the code** that touches the table onto the catalog's builders (`convex/functions.ts`), one function at a time, turning each status write into an event. Code still on Convex's own builders isn't guarded, which is what lets you switch gradually. Once nothing uses the old fields, drop them, and refuse the raw builders with a lint rule (the example apps' `no-restricted-imports`), so nothing slips back.
4. **Arm the timers.** A row you migrate into a state with a timer starts with none. Once the machine is live, run a migration that calls `armTimers` on those rows: it arms what the row's state has, as if the row had just entered it. It needs the internal brand, so build that migration's mutation with the catalog's `internalMutation`.

```ts
await version.armTimers(ctx, versionId); // [{ event: "TIMED_OUT", dueAt }]
```

History starts from the first step each row takes through the machine.

**State fields that aren't machines yet**

The catalog takes any field named `state` or `<name>State` that holds a union tagged with `kind` to be a machine's, so it fails to load if no machine is on one, and it guards each one. If a table already has one that you'll move over later, list it in `notMachines` until then, as `"table.field"`:

```ts
export const machines: Machines<typeof schema, "renewals.state"> = defineMachines(schema, [approval], {
  ...{ mutation, internalMutation, internalQuery },
  component: components.stateMachines,
  notMachines: ["renewals.state"], // a state union with no machine yet
});
```

Those fields are then the app's, as before: the catalog's builders insert, patch and delete their rows with no check, and their types allow it, as `Machines` takes the same list. Give the lint rules the list too, with `machines.recommended({ notMachines })` (see [Lint rules](#lint-rules)). A machine's effects are typed before the catalog is, so their `ctx.db` still refuses those writes at compile time, though not at runtime: write them from the handler. For the same reason, if the field is on a machine's own table, that machine's `create` types leave it out, as they can't tell it from another machine's state: pass it with a cast. At runtime `create` takes it, and refuses a machine's state or timers passed that way. When a machine takes the field, take it off the list. The catalog refuses an entry that a machine is on, or that isn't a state field in the schema.

## The pieces

- **Events, by who sends them.** A role (`owner`), `server` (internal code), another machine, or a timer. A role comes with the sentence a refused caller gets, and its check runs before any guard.
- **Guards** are named in the rules with their "why not", and get a database reader and who's asking. A list of transitions for one event is tried in order: `[1. retriesLeft]`, then `[else]`.
- **Effects** return the whole next state, typed as the state the transition enters. They can write your tables (the refund), never a machine's state.
- **A row is born by an event.** `create(ctx, fields, event)` runs the `start` transition. A transition can also `creates` rows of another machine, as a project's BUILD creates a version.
- **Links** tell another machine about a step, once it's saved. `rollback` means both steps happen or neither does. `ignore` means a refusal over there doesn't undo this step, and history records why. A bug over there fails this step either way, so it gets retried once it's fixed.
- **Timers** are events the clock sends: `after` a delay, or `at` a time in the state's data. A machine with timers keeps them on its row, in `stateTimers` beside its state: each one's event, due time and scheduled job. Leaving a state cancels them. A timer whose step throws stays pending, and `failedTimers` and `rearmTimer` are there for an operator.
- **History** is a fact per step, kept by the `stateMachines` component and read with `machine.history(ctx, id, { paginationOpts })`. Each step makes one call to it. Turn it off per machine with `history: false`: then nothing is recorded, the machine never calls the component, and its refusals go to the logs.
- **Deleting** a row is a transition into a final state. `purge` is for operators, and `ctx.db.delete` on a machine's table is refused.
- **The write guard.** The app's mutation builders give a `ctx.db` that can't write a machine's state: a type error, an error at runtime, and a lint rule for casts. `server` events and `purge` need the `internalMutation` builder's ctx. The `internalQuery` builder carries the same brand, for what an operator's page reads live.

## API

```ts
// rules:      { name, table, field?, history?: false, callers?: { [role]: whyNot }, guards?: { [name]: whyNot },
//               events: { [role | "server" | machine]: { [EVENT]: payload } }, states: { start: { on }, [kind]: { timers?, on? } } }
// a timer:    { [EVENT]: { after: ms } | { at: "requiredNumberField" } }
// on:         { [EVENT]: transition | transition[] }, a list tried in order, never empty
// transition: { to?, guard?, effect?, sends?: [{ machine, event, onRefused: "rollback" | "ignore" }], creates?: { machine, event } }
// code:       callers: { [role]: (ctx, { id, row }) => boolean },  guards: { [name]: (ctx, { id, row, state, event, from }) => boolean },
//             effects: { [name]: async (ctx, { id, row, state, event, from, to, create }) => nextState },
//             links: { "machine.EVENT": ({ db, id, row, state, next, event }) => id | id[] }

await project.create(ctx, fields, event)     // done { id, from: "start", to } or rejected { code, reasons }
await project.send(ctx, id, event)           // done { from, to, created } or rejected { code, reasons }
await project.inspect(ctx, id, eventsToTry?) // { kind, events this caller may send, timers }, or null
await project.purge(ctx, id, { force? })     // internal ctx only: deletes a row in a final state, and cancels its timers
await project.armTimers(ctx, id)             // internal ctx only: arms its state's timers, as if it had just entered it
await project.history(ctx, id, { paginationOpts, order? }) // its history, oldest first, from the component
project.events.owner, project.startEvents.owner // validators for an endpoint's args
project.results.send                         // validators for its `returns`: create, send and inspect
defineMachines(schema, machines, { mutation, internalMutation, internalQuery, deliver?, component?, notMachines?: ["table.field"] })
machines.failedTimers(ctx, { limit? })       // internal ctx only, a query's too: timers whose delivery threw, newest first
machines.rearmTimer(ctx, { machine, id, event }), machines.pruneHistory(ctx, { before }) // internal ctx only
// Refusals: NOT_ALLOWED, NOT_ACCEPTED, GUARD_BLOCKED. Thrown: ConvexError({ code, message }). A wiring mistake throws when the app loads.
```

## Patterns

- **A field every state shares, that only the machine may change** (a subscription's `plan`). Put it in every member of the union with a shared spread, `{ kind: v.literal("active"), ...billing }`. It's then state: the write guard protects it, and only an event changes it.
- **Children at birth.** A start can't create, as its row doesn't exist yet. Create the parent, then send it an init event whose transition `creates` the children, in the same mutation.
- **One event from several senders.** For people, a role whose check ORs (`staff: isOwner || isAdmin`). For machines, two event names sharing one transition constant: `on: { DISCARD: discard, POST_ARCHIVED: discard }`.
- **A wide fan-out.** One step sends 100 links at most. To tell more rows than that, have the effect schedule an internal mutation that sends a server event to one page of rows and schedules the next.
- **Webhook dedupe.** Keep the provider's event ID once the step is done, as `projects.report` does, so a retry is dropped and a refused report can run again.
- **Suspend and restore.** Keep the state to go back to in the suspended state's data, and give the restoring event a guarded list, one guard per state it can return to.
- **Calling an outside service.** A step is one mutation, so its effect schedules an action, the state says the call is out (`building`), and the action reports back through an internal mutation as a `server` event (`projects.report`).
- **Two independent things on one row.** Give each its own machine on its own field (`paymentState`, `fulfillmentState`), both born by the same event. Each draws its own diagram.

## FAQ

**What happens to rows when I change a machine?**
The rules are code, so a change applies to every row from its next event. Rows don't pin a version. What a row stores is its state, so that's the part to be careful with:
- Adding a state, an event, a guard or a transition needs nothing else.
- Removing or renaming a state means moving the rows in it first. Convex checks every row against the schema when you deploy, so it refuses a deploy that would leave a row in a state the union no longer has. Keep the old member, migrate those rows out, then remove it.
- Changing a state's data is an ordinary schema change: widen, migrate, narrow.
- Renaming an event breaks callers still sending the old name (`INVALID_EVENT`). Renaming a machine starts its history again, as history is kept by the machine's name.

**What shouldn't be a state machine?**
A machine is for something that moves through stages over time, where what's allowed depends on the stage, and people, servers, timers or other rows can move it. Most of an app isn't like that, so leave the rest as plain code:
- Fields you just edit, like a name, a profile, settings or a prompt, stay plain fields on the row. The exception is a field that only the machine may change: see "A field every state shares" under Patterns.
- Numbers that go up and down, like credits, stock or a position, aren't states. Guards and effects read and write them. Something that changes every few seconds belongs in a table of its own.
- What a page shows, search and aggregates are queries.
- A straight pipeline with retries draws a single line. [The workflow component](https://www.convex.dev/components/workflow) may fit it better.
- Rules across many rows, and the logic inside an effect, stay in code. The diagram shows a guard's or an effect's name, not what it does.

So the diagrams show your app's lifecycles, not the whole app.

**And when I change a timer?**
A pending timer keeps the due time it was armed with. Change an `after` and rows already waiting keep their old deadline, until they next enter the state or you call `armTimers`. Remove a timer and the row's next step cancels it. If it fires before that, its state refuses it, and it's spent.

**How do I migrate a machine's rows?**
With a migration, like any Convex data ([the migrations component](https://www.convex.dev/components/migrations) helps). A migration that sets `state` goes round the machine on purpose: no guards, no effects, no history. Build it with Convex's own `internalMutation`, as the catalog's refuses that write, and give the lint rule's `eslint-disable` a reason. Then call `armTimers` for the rows that land in a state with timers. [Using it in an existing app](#using-it-in-an-existing-app) walks through it.

**What if a row ends up somewhere it shouldn't?**
- A step threw: nothing commits, so the row is still where it was. Fix the bug and send the event again.
- A timer's step threw: the row stays in its state, and the timer stays pending with its job failed. `failedTimers` lists it: an admin page can watch it as a query, and a cron can check it, as the example's `checkTimers` does. Fix the bug, then `rearmTimer`.
- Its stored state doesn't match its member (an import, or a deploy with schema validation off): `send` and `inspect` refuse it with `UNKNOWN_STATE` rather than hand a guard half a state. Fix it with a migration.
- It needs moving by hand: add an event for it, such as an admin's `RESET`, so the move is on the diagram and in history. A raw write works too, as a migration does, but it skips everything the machine does.
- It needs to go: `purge(ctx, id, { force: true })` deletes it from any state, cancels its timers, and records that it was forced.

**Do two events on one row conflict?**
They queue. Each step reads and writes its row, so Convex runs them one after the other, retrying the second. Events on different rows don't touch each other, unless a guard reads a row the other writes, like an account's credits. Within one mutation, await each `send` in turn.

**What does it cost?**
A step is your own mutation, plus one call to the component when history is on. Timers live on the row, so reading them costs nothing extra. `inspect` is a query that runs the guards, so it reads what they read. An `ignore` link runs its receiver as a nested mutation.

**What does history keep?**
For each step: the event's name, the state before and after, who sent it (a role, `server`, a timer, or the row that linked it), and why a refusal or an ignored link happened. Not the event's payload, so nothing a user typed ends up in it. Prune it with `pruneHistory`, or turn it off per machine.

**Where does auth go?**
In your app, as roles. Each role's check gets `ctx.auth` and the row, and runs before any guard. The component never sees auth: history records the role's name.

**How do I find rows in a state?**
`state.kind` is an ordinary field, so index it: `.index("by_project_state", ["projectId", "state.kind", "number"])`.

**Are there limits?**
Links go 4 deep and 100 per step. Past either, the step fails. To tell more rows than that, see "A wide fan-out" under Patterns.

## Testing

`@convex-dev/state-machines/test` registers the component with [convex-test](https://docs.convex.dev/testing/convex-test), and has the helpers a machine's tests need:

```ts
import { advance, asInternal, register } from "@convex-dev/state-machines/test";

const t = convexTest(schema, modules);
register(t); // the component, as convex.config.ts installs it
await t.run(async (ctx) => version.send(await asInternal(machines, ctx), versionId, { type: "SUCCEEDED" })); // a server event
await advance(t, 20_000); // with vi.useFakeTimers(): runs every timer due on the way
```

## Lint rules

`@convex-dev/state-machines/eslint` has four rules that keep the design intact when an agent is in a hurry: no optional fields beside a machine's state, no direct writes to its state or timers, no way round the internal brand, and a reason on any `eslint-disable` that turns one off. See [src/eslint](src/eslint/README.md).

```js
// eslint.config.js
import machines from "@convex-dev/state-machines/eslint";

export default [{ files: ["convex/**/*.ts"], ...machines.configs.recommended }];
```

With state fields that aren't machines yet, pass the list `defineMachines` has:

```js
export default [{ files: ["convex/**/*.ts"], ...machines.recommended({ notMachines: ["renewals.state"] }) }];
```

## Examples

- [examples/lets-build-it](examples/lets-build-it/README.md): the walkthrough above, a project and its versions.
- [examples/business](examples/business/README.md): an order, a subscription, a document approval, a support ticket and an AI job queue.
- [examples/coordination](examples/coordination/README.md): a booking, a game lobby, scheduled publishing, KYC checks and delivery dispatch.

## Developing

```bash
npm install
npm run dev     # builds the package, and runs Let's Build It on a Convex deployment
npm run check   # build, typecheck, lint, every test, every example's diagrams, and the type-error probes
```

```
src/client/      the library: defineMachine, defineMachines, the diagrams, and its tests
src/component/   the stateMachines component: history
src/eslint/      the lint rules and their tests
src/test.ts      @convex-dev/state-machines/test
examples/        three apps that install the package
```
