import type { ComponentApi } from "../component/_generated/component.js";
import type {
  GenericQueryCtx,
  GenericMutationCtx,
} from "convex/server";
import type { GenericId } from "convex/values";

// The component's generated boundary type. The host passes its own
// `components.feedback`, which has this shape.
type FeedbackApi = ComponentApi;

type RunQueryCtx = GenericQueryCtx<any>;
type RunMutationCtx = GenericMutationCtx<any>;

export type ItemState =
  | "submitted"
  | "requested"
  | "planned"
  | "inProgress"
  | "rejected"
  | "completed";

export type AttachmentKind = "screenshot" | "audio";

export type Attachment = {
  _id: string;
  kind: AttachmentKind;
  url: string | null;
  mimeType: string;
  size: number;
  createdAt: number;
};

export type ActorArgs = { viewer?: string | null; agentKey?: string };

/**
 * Thin typed wrapper around the feedback component API.
 *
 * Host usage (inside its own query/mutation after authenticating the user):
 *
 *   import { components } from "./_generated/api";
 *   import { Feedback } from "@convex-dev/feedback";
 *   const feedback = new Feedback(components.feedback);
 *   await feedback.items.create(ctx, { userId, title, description });
 *
 * The host is responsible for:
 *   - authenticating the user and passing a stable `userId` string
 *   - gating admin operations (listAll, transitionState, post dev logs)
 *   - (optional) debiting/crediting its own chip economy around bids
 */
export class Feedback {
  constructor(public component: FeedbackApi) {}

  // Identity + roles. Host forwards the authenticated userId (never ctx.auth).
  // `ensure` registers a member; admins are named with setRole (or chefCloud's chefSetAdmin).
  users = {
    ensure: (ctx: RunMutationCtx, args: { userId: string }) =>
      ctx.runMutation(this.component.users.ensure, args),
    get: (ctx: RunQueryCtx, args: { userId: string }) =>
      ctx.runQuery(this.component.users.get, args),
    /** Whether any app user (not the CLI's `operator:` identity) has registered. */
    hasAppUsers: (ctx: RunQueryCtx) =>
      ctx.runQuery(this.component.users.hasAppUsers, {}),
    setRole: (
      ctx: RunMutationCtx,
      args: { userId: string; role: "admin" | "member" },
    ) => ctx.runMutation(this.component.users.setRole, args),
    /** Every admin's userId (to notify them, e.g. about a request awaiting approval). */
    listAdmins: (ctx: RunQueryCtx) =>
      ctx.runQuery(this.component.users.listAdmins, {}),
  };

  items = {
    create: (
      ctx: RunMutationCtx,
      args: {
        userId: string;
        title: string;
        description: string;
        autoApprove?: boolean;
        kind?: "feature" | "refinement";
        /** Voice-note transcript, stored separately from `description`. */
        transcript?: string;
      },
    ) => ctx.runMutation(this.component.items.create, args),

    /** Delete an item + its bids, dev logs, notifications and attachments. Host-gate to admins. */
    remove: (ctx: RunMutationCtx, args: { itemId: GenericId<"items"> }) =>
      ctx.runMutation(this.component.items.remove, args),

    listRefinementOpen: (
      ctx: RunQueryCtx,
      args: { limit?: number } & ActorArgs = {},
    ) => ctx.runQuery(this.component.items.listRefinementOpen, args),

    get: (ctx: RunQueryCtx, args: { itemId: GenericId<"items"> }) =>
      ctx.runQuery(this.component.items.get, args),

    transitionState: (
      ctx: RunMutationCtx,
      args: { itemId: GenericId<"items">; state: ItemState },
    ) => ctx.runMutation(this.component.items.transitionState, args),

    /**
     * Set the item's user-facing changelog line ("You can now export as PDF."),
     * trimmed to 280 chars; empty text clears it. Shown under "What's new" once
     * the item is completed. Admin/agent paths only — never raw request text.
     */
    setChangelog: (
      ctx: RunMutationCtx,
      args: { itemId: GenericId<"items"> | string; text: string },
    ): Promise<null> => ctx.runMutation(this.component.items.setChangelog, args as any),

    /**
     * Ship an item: record its changelog (optional) and move it to "completed"
     * (stamps completedAt, notifies supporters like transitionState).
     *
     *   await feedback.items.complete(ctx, { itemId, changelog: "Dark mode is here." });
     */
    complete: (
      ctx: RunMutationCtx,
      args: { itemId: GenericId<"items"> | string; changelog?: string },
    ): Promise<null> => ctx.runMutation(this.component.items.complete, args as any),

    /**
     * Release notes: completed items with a changelog that shipped after `since`
     * (ms epoch), newest first (limit default 20, max 50). Public-safe.
     */
    listShippedSince: (
      ctx: RunQueryCtx,
      args: { since: number; limit?: number },
    ): Promise<Array<{ _id: string; changelog: string; completedAt: number }>> =>
      ctx.runQuery(this.component.items.listShippedSince, args),

    /**
     * Requests from non-admins waiting for approval ("submitted"), newest first. Admins/agents only
     * (pass `viewer` or `agentKey`). Pair with attachments.listForItems for screenshots/voice notes.
     */
    listAwaitingApproval: (
      ctx: RunQueryCtx,
      args: { limit?: number } & ActorArgs = {},
    ) => ctx.runQuery(this.component.items.listAwaitingApproval, args),

    /**
     * The requests `userId` filed (not refinements), newest first, with attachment counts.
     * Forward the AUTHENTICATED user's id — this is "my requests", not a privileged read.
     */
    listByCreator: (
      ctx: RunQueryCtx,
      args: { userId: string; limit?: number },
    ): Promise<
      Array<{
        _id: string;
        _creationTime: number;
        number: number;
        title: string;
        state: ItemState;
        mergedInto?: string;
        screenshotCount: number;
        hasAudio: boolean;
      }>
    > => ctx.runQuery(this.component.items.listByCreator, args),

    /** An admin approves (→ "requested") or rejects (→ "rejected") a submitted request. */
    review: (
      ctx: RunMutationCtx,
      args: { itemId: GenericId<"items">; approve: boolean; reviewerId: string },
    ) => ctx.runMutation(this.component.items.review, args),

    listPublic: (
      ctx: RunQueryCtx,
      args: {
        limit?: number;
        cursor?: string | null;
        // Include pre-triage "community" requests (dedup board). The host
        // forwards the owner's setting.
        includeCommunity?: boolean;
      } = {},
    ) => ctx.runQuery(this.component.items.listPublic, args),

    // Owner Console prioritization feed: submitted + requested, votes-sorted.
    // Privileged — the component enforces admin/agent via the forwarded actor.
    listForTriage: (
      ctx: RunQueryCtx,
      args: { limit?: number } & ActorArgs = {},
    ) => ctx.runQuery(this.component.items.listForTriage, args),

    listByState: (
      ctx: RunQueryCtx,
      args: { state: ItemState; limit?: number; cursor?: string | null } & ActorArgs,
    ) => ctx.runQuery(this.component.items.listByState, args),

    listAll: (
      ctx: RunQueryCtx,
      args: { limit?: number; cursor?: string | null } & ActorArgs = {},
    ) => ctx.runQuery(this.component.items.listAll, args),

    countByState: (ctx: RunQueryCtx, args: { state: ItemState }) =>
      ctx.runQuery(this.component.items.countByState, args),

    merge: (
      ctx: RunMutationCtx,
      args: {
        sourceId: GenericId<"items">;
        targetId: GenericId<"items">;
      },
    ) => ctx.runMutation(this.component.items.merge, args),

    boost: (
      ctx: RunMutationCtx,
      args: {
        itemId: GenericId<"items">;
        amount: number;
        grantedBy: string;
        reason?: string;
      },
    ) => ctx.runMutation(this.component.items.boost, args),
  };

  /**
   * Screenshots + voice notes on items, stored in the component's file storage.
   *
   *   const url = await feedback.attachments.generateUploadUrl(ctx); // mutation
   *   // client: fetch(url, { method: "POST", body: blob, headers: { "Content-Type": blob.type } })
   *   await feedback.attachments.add(ctx, { itemId, kind: "screenshot", storageId, userId });
   *   const files = await feedback.attachments.list(ctx, { itemId, viewer: userId });
   *
   * Limits: image/* ≤10 MB (≤4 per item), audio/* or video/mp4 ≤25 MB (1 per
   * item); uploads must be attached within an hour and only once. `list` is
   * readable by admins/agents, the item's creator, or anyone while the item is
   * on the public board — it returns [] otherwise.
   */
  attachments = {
    generateUploadUrl: (ctx: RunMutationCtx): Promise<string> =>
      ctx.runMutation(this.component.attachments.generateUploadUrl, {}),

    add: (
      ctx: RunMutationCtx,
      args: {
        itemId: GenericId<"items"> | string;
        kind: AttachmentKind;
        storageId: string;
        /** Host-authenticated uploader; must be the item's creator unless admin/agent. */
        userId: string;
        agentKey?: string;
      },
    ): Promise<string> =>
      ctx.runMutation(this.component.attachments.add, args),

    list: (
      ctx: RunQueryCtx,
      args: { itemId: GenericId<"items"> | string; includeCommunity?: boolean } & ActorArgs,
    ): Promise<Attachment[]> =>
      ctx.runQuery(this.component.attachments.list, args),

    listForItems: (
      ctx: RunQueryCtx,
      args: { itemIds: Array<GenericId<"items"> | string>; includeCommunity?: boolean } & ActorArgs,
    ): Promise<Array<{ itemId: string; attachments: Attachment[] }>> =>
      ctx.runQuery(this.component.attachments.listForItems, args),

    remove: (
      ctx: RunMutationCtx,
      args: { attachmentId: string; userId: string; agentKey?: string },
    ) => ctx.runMutation(this.component.attachments.remove, args),
  };

  bids = {
    place: (
      ctx: RunMutationCtx,
      args: { userId: string; itemId: GenericId<"items">; amount: number },
    ) => ctx.runMutation(this.component.bids.place, args),

    remove: (
      ctx: RunMutationCtx,
      args: { userId: string; itemId: GenericId<"items"> },
    ) => ctx.runMutation(this.component.bids.remove, args),

    getUserBid: (
      ctx: RunQueryCtx,
      args: { userId: string; itemId: GenericId<"items"> },
    ) => ctx.runQuery(this.component.bids.getUserBid, args),

    itemStats: (ctx: RunQueryCtx, args: { itemId: GenericId<"items"> }) =>
      ctx.runQuery(this.component.bids.itemStats, args),

    backfillStats: (ctx: RunMutationCtx) =>
      ctx.runMutation(this.component.bids.backfillStats, {}),
  };

  devLogs = {
    post: (
      ctx: RunMutationCtx,
      args: {
        itemId: GenericId<"items">;
        authorId: string;
        message: string;
      },
    ) => ctx.runMutation(this.component.devLogs.post, args),

    listForItem: (
      ctx: RunQueryCtx,
      args: { itemId: GenericId<"items"> },
    ) => ctx.runQuery(this.component.devLogs.listForItem, args),
  };

  notifications = {
    listForUser: (
      ctx: RunQueryCtx,
      args: { userId: string; limit?: number; unreadOnly?: boolean },
    ) => ctx.runQuery(this.component.notifications.listForUser, args),

    unreadCount: (ctx: RunQueryCtx, args: { userId: string }) =>
      ctx.runQuery(this.component.notifications.unreadCount, args),

    markRead: (
      ctx: RunMutationCtx,
      args: { id: GenericId<"notifications">; userId: string },
    ) => ctx.runMutation(this.component.notifications.markRead, args),

    markAllRead: (ctx: RunMutationCtx, args: { userId: string }) =>
      ctx.runMutation(this.component.notifications.markAllRead, args),
  };

  todos = {
    plan: (ctx: RunMutationCtx, args: { items: string[] }) =>
      ctx.runMutation(this.component.todos.plan, args),

    advance: (ctx: RunMutationCtx) =>
      ctx.runMutation(this.component.todos.advance, {}),

    setStatus: (
      ctx: RunMutationCtx,
      args: {
        id: GenericId<"todos">;
        status: "pending" | "active" | "done";
      },
    ) => ctx.runMutation(this.component.todos.setStatus, args),

    listAll: (ctx: RunQueryCtx) =>
      ctx.runQuery(this.component.todos.listAll, {}),
  };

  progress = {
    post: (
      ctx: RunMutationCtx,
      args: { message: string; kind: "step" | "shipped" | "note" },
    ) => ctx.runMutation(this.component.progress.post, args),

    listRecent: (ctx: RunQueryCtx, args: { limit?: number } = {}) =>
      ctx.runQuery(this.component.progress.listRecent, args),
  };

  agentState = {
    snapshot: (
      ctx: RunQueryCtx,
      args: {
        mode?: "all" | "chef" | "queue";
        limit?: number;
        includeCompleted?: boolean;
      } & ActorArgs = {},
    ) => ctx.runQuery(this.component.agentState.snapshot, args),
  };

  // /agent/* keys. Pass the AUTHENTICATED admin's id; the component checks
  // the role. Keys are stored hashed: `create` returns the plaintext once,
  // `list` returns names and prefixes only.
  agentKeys = {
    list: (ctx: RunQueryCtx, args: { viewer: string | null }) =>
      ctx.runQuery(this.component.agentKeys.list, args),

    create: (
      ctx: RunMutationCtx,
      args: {
        name: string;
        adminUserId: string;
        // Defaults to build-only. Pass ["build","triage"] to mint a key that
        // may also approve/reject — the owner does this deliberately.
        scopes?: Array<"build" | "triage">;
      },
    ) => ctx.runMutation(this.component.agentKeys.create, args),

    revoke: (
      ctx: RunMutationCtx,
      args: { id: GenericId<"agentKeys">; adminUserId: string },
    ) => ctx.runMutation(this.component.agentKeys.revoke, args),

    /** Hash any keys stored as plaintext before hashing; call until `remaining` is false. */
    migrateToHashes: (ctx: RunMutationCtx) =>
      ctx.runMutation(this.component.agentKeys.migrateToHashes, {}),
  };

  // Chef approval snapshots (docs/chef-pipeline.md). Pass the AUTHENTICATED
  // admin's id; the component checks the role.
  chefSnapshots = {
    prepareApproval: (
      ctx: RunMutationCtx,
      args: { itemId: string; adminUserId: string },
    ): Promise<{ snapshotId: string; contentHash: string }> =>
      ctx.runMutation(this.component.chefSnapshots.prepareApproval, args),
    approve: (
      ctx: RunMutationCtx,
      args: { snapshotId: string; contentHash: string; adminUserId: string },
    ): Promise<{ itemId: string }> =>
      ctx.runMutation(this.component.chefSnapshots.approve, args),
    get: (ctx: RunQueryCtx, args: { snapshotId: string; viewer: string | null }) =>
      ctx.runQuery(this.component.chefSnapshots.get, args),
    snapshotOwnRequest: (
      ctx: RunMutationCtx,
      args: { itemId: string; adminUserId: string },
    ) => ctx.runMutation(this.component.chefSnapshots.snapshotOwnRequest, args),
  };

  // Owner-controlled settings (community-board visibility + run-mode). `set` is
  // host-admin-gated; `get` is unprivileged (values are not sensitive).
  settings = {
    get: (ctx: RunQueryCtx) =>
      ctx.runQuery(this.component.settings.get, {}),

    set: (
      ctx: RunMutationCtx,
      args: {
        communityBoardVisible?: boolean;
        runMode?: "local" | "cloud";
      },
    ) => ctx.runMutation(this.component.settings.set, args),
  };
}

// One-file drop-in: ready-made public functions for the Chef web panel and iOS ChefKit.
export { exposeChefApi } from "./chef.js";
// The CLI's admin functions (chefSetAdmin, chefMigrateAgentKeys). Cloud
// builds are @convex-dev/chef-cloud's chefCloud, which includes these.
export { chefAdmin, OPERATOR_USER, NO_ADMIN } from "./chefAdmin.js";
export type { ChefAdminOptions } from "./chefAdmin.js";
// What @convex-dev/chef-cloud checks it was built for.
export { CHEF_CONTRACT_VERSION } from "../chef/contract.js";
export {
  RUNNER_VERSION,
  DEFAULT_BASE_SNAPSHOT,
  defaultRunnerJson,
  runnerDelivery,
  deployDelivery,
} from "./chefDelivery.js";
export { exposeChefRelease, RELEASE_FUNCTIONS } from "./chefRelease.js";
export type { ChefApiOptions, ChefSubmission } from "./chef.js";
