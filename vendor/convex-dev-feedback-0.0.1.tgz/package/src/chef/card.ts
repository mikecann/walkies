// The plain-language Ship card (docs/chef-pipeline.md, "The Ship card"):
// what a build changed and what to try, in the owner's words, and the risk
// flags. Pure functions, no Convex imports: the component, the runner's
// tests and the panel's tests share them.
//
// Two very different sources, kept apart on purpose:
//
// - "What changed" and "What to try" come from the agent's summary.md, in
//   two fixed sections the prompt asks for (src/chef/prompt.ts). That is the
//   agent's text: untrusted. It is scrubbed before it is stored, cut to a few
//   short lines here, shown as text (never markup, never a link), and it
//   never decides anything.
// - The risk flags come from the diff alone (paths and changed lines),
//   computed here by fixed rules. The agent's words can't add or remove one.

import { singleLine } from "./text.js";
import { isDependencyFile } from "./release.js";

/** The summary's two fixed sections, as the prompt names them. */
export const CARD_SECTIONS = { whatChanged: "What changed", whatToTry: "What to try" } as const;

/** A batch build's third section (src/chef/prompt.ts): one line per request, `- #12: what was done`. */
export const EACH_REQUEST_SECTION = "Each request";

export const CARD_LIMITS = {
  whatChanged: 4,
  whatToTry: 3,
  /** Characters per line. */
  line: 240,
  /** Files named per flag. */
  filesPerFlag: 5,
  /** Changed lines scanned per file, and characters per line. */
  linesPerFile: 4000,
  lineChars: 2000,
};

export type SummaryCard = { whatChanged: string[]; whatToTry: string[] };

const HEADING = /^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$/;
const BULLET = /^\s{0,6}(?:[-*+•]|\d{1,2}[.)])\s+(.*)$/;

/** Markdown decoration an owner shouldn't see: emphasis, code ticks, links' URLs. Text stays. */
function plain(s: string): string {
  return s
    .replace(/!\[([^\]]*)\]\([^)]*\)/g, "$1")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/[*_`]{1,3}([^*_`]+)[*_`]{1,3}/g, "$1")
    .replace(/<[^>]{0,200}>/g, "");
}

/**
 * "What changed" (up to 4 lines) and "What to try" (up to 3) from the
 * agent's summary: the bullets under those two headings, in any heading
 * level and case. Lines that aren't bullets under a heading count as one
 * line each. Every line is one line of display text (invisible characters
 * shown, controls marked), markdown stripped, at most 240 characters. A
 * summary without the sections gives empty lists: the card then says the
 * agent didn't write one, rather than guessing from the rest.
 */
export function parseSummaryCard(summary: string | null | undefined): SummaryCard {
  const out: SummaryCard = { whatChanged: [], whatToTry: [] };
  if (!summary) return out;
  let section: keyof SummaryCard | null = null;
  // Whether the last line read was a bullet: an indented line right after
  // one continues it (a wrapped bullet), anything else is a line of its own.
  let lastBullet = false;
  for (const raw of summary.replace(/\r\n?/g, "\n").split("\n")) {
    const h = HEADING.exec(raw);
    if (h) {
      lastBullet = false;
      const name = h[1].toLowerCase().replace(/[:.]+$/, "").trim();
      section =
        name === CARD_SECTIONS.whatChanged.toLowerCase()
          ? "whatChanged"
          : name === CARD_SECTIONS.whatToTry.toLowerCase()
            ? "whatToTry"
            : null;
      continue;
    }
    if (!section || raw.trim() === "") {
      lastBullet = false;
      continue;
    }
    const b = BULLET.exec(raw);
    const list = out[section];
    if (!b && lastBullet && /^\s/.test(raw) && list.length > 0) {
      list[list.length - 1] = singleLine(`${list[list.length - 1]} ${plain(raw)}`, CARD_LIMITS.line);
      continue;
    }
    const text = singleLine(plain(b ? b[1] : raw), CARD_LIMITS.line);
    lastBullet = !!b;
    if (text === "") continue;
    if (list.length < CARD_LIMITS[section]) list.push(text);
    else lastBullet = false;
  }
  return out;
}

/**
 * A batch build's per-request lines (the "Each request" section): request
 * number to one display line. Bullets that don't start with a number the
 * build was given are ignored, and so is a second line for the same one.
 */
export function parseEachRequest(summary: string | null | undefined, numbers: readonly number[]): Map<number, string> {
  const out = new Map<number, string>();
  if (!summary) return out;
  let inSection = false;
  for (const raw of summary.replace(/\r\n?/g, "\n").split("\n")) {
    const h = HEADING.exec(raw);
    if (h) {
      inSection = h[1].toLowerCase().replace(/[:.]+$/, "").trim() === EACH_REQUEST_SECTION.toLowerCase();
      continue;
    }
    if (!inSection) continue;
    const b = BULLET.exec(raw);
    const m = b ? /^\s*(?:request\s+)?#?(\d{1,9})\b\s*[:.)\-–—]?\s*(.*)$/i.exec(plain(b[1])) : null;
    if (!m) continue;
    const n = Number(m[1]);
    if (!numbers.includes(n) || out.has(n)) continue;
    const text = singleLine(m[2], CARD_LIMITS.line);
    if (text) out.set(n, text);
  }
  return out;
}

// ---------------------------------------------------------------- the diff

export type DiffFile = {
  path: string;
  status: "added" | "deleted" | "modified";
  /** Lines the diff adds, without the leading "+", bounded. */
  added: string[];
  /** Lines it removes, without the leading "-", bounded. */
  removed: string[];
};

const unquote = (s: string) =>
  s.replace(/\\([0-7]{3}|.)/g, (_, c: string) =>
    c.length === 3 ? String.fromCharCode(parseInt(c, 8)) : ({ n: "\n", t: "\t", '"': '"', "\\": "\\" } as Record<string, string>)[c] ?? c,
  );

/** The path in a `diff --git a/<x> b/<x>` header (the b side), or null. */
function headerPath(rest: string): string | null {
  const quoted = rest.match(/^"a\/((?:[^"\\]|\\.)*)" "b\/((?:[^"\\]|\\.)*)"$/);
  if (quoted) return unquote(quoted[2]);
  const n = (rest.length - 5) / 2;
  if (Number.isInteger(n) && n > 0 && rest.startsWith("a/")) {
    const path = rest.slice(2, 2 + n);
    if (rest.slice(2 + n) === ` b/${path}`) return path;
  }
  // A rename (a/x b/y): the new side.
  const m = rest.match(/^a\/.+ b\/(.+)$/);
  return m ? m[1] : null;
}

/**
 * The files of a unified `git diff`, each with its status and the lines it
 * adds and removes (bounded: CARD_LIMITS.linesPerFile lines of at most
 * CARD_LIMITS.lineChars each). Binary files have no lines.
 */
export function parseDiffFiles(text: string): DiffFile[] {
  const files: DiffFile[] = [];
  let cur: DiffFile | null = null;
  let inHunk = false;
  for (const line of text.split("\n")) {
    if (line.startsWith("diff --git ")) {
      const path = headerPath(line.slice("diff --git ".length));
      cur = path === null ? null : { path, status: "modified", added: [], removed: [] };
      if (cur) files.push(cur);
      inHunk = false;
      continue;
    }
    if (!cur) continue;
    if (!inHunk) {
      if (line.startsWith("new file mode")) cur.status = "added";
      else if (line.startsWith("deleted file mode")) cur.status = "deleted";
      else if (line.startsWith("@@")) inHunk = true;
      continue;
    }
    if (line.startsWith("@@")) continue;
    const keep = (list: string[], l: string) => {
      if (list.length < CARD_LIMITS.linesPerFile) list.push(l.slice(0, CARD_LIMITS.lineChars));
    };
    if (line.startsWith("+")) keep(cur.added, line.slice(1));
    else if (line.startsWith("-")) keep(cur.removed, line.slice(1));
  }
  return files;
}

// ---------------------------------------------------------------- risk flags

export const RISK_KINDS = [
  "auth",
  "newAuthPath",
  "dataDeletion",
  "schema",
  "payments",
  "secrets",
  "permissions",
  "dependencies",
  "ios",
] as const;
export type RiskKind = (typeof RISK_KINDS)[number];

/** What each flag says to the app's owner. */
export const RISK_LABELS: Record<RiskKind, string> = {
  auth: "Changes sign-in or session code",
  newAuthPath: "Adds a new way to sign in or get a token",
  dataDeletion: "Deletes data or migrates existing data",
  schema: "Changes the database schema",
  payments: "Touches payments or billing",
  secrets: "Reads environment variables or secrets",
  permissions: "Changes who can see, share or manage things",
  dependencies: "Changes dependencies (package.json or a lockfile)",
  ios: "Changes iOS code the cloud can't compile",
};

export type RiskFlag = {
  kind: RiskKind;
  label: string;
  /** The first few files that raised it. */
  files: string[];
  /** How many files raised it. */
  count: number;
};

const TEST_FILE = /(^|\/)(tests?|__tests__|e2e|fixtures?)\/|\.(test|spec)\.[cm]?[jt]sx?$/i;
const CODE_FILE = /\.([cm]?[jt]sx?|swift|kt|py|rb|go|rs|java|m|mm|vue|svelte)$/i;

/** A file or directory name about signing in ("author" and "authors" aren't). */
const AUTH_PATH = /(auth(?!or(s|ship|ed)?(\b|[._-]|$))|session|log-?in|log-?out|sign-?in|sign-?up|passkey|oauth|jwt|jwks)[^/]*$|(^|\/)(auth|sessions?)\//i;
const AUTH_CODE =
  /\b(getAuthUserId|getUserIdentity|ctx\.auth\b|signIn|signOut|createSession|invalidateSessions|convexAuth|authTables|JWT_PRIVATE_KEY|JWKS|createAccount|retrieveAccount|modifyAccountCredentials|useAuthActions|ConvexAuthProvider)\b/;
const NEW_ROUTE = /\bhttp\.route\s*\(|\b(path|pathPrefix)\s*:\s*["'`][^"'`]*(auth|login|sign|token|session|callback|oauth|magic|verify|reset)/i;
const NEW_TOKEN_FN =
  /\bexport\s+const\s+\w*(signIn|signin|login|token|Token|session|Session|issue|magicLink|impersonat|verify|resetPassword)\w*\s*=\s*(mutation|action|query|httpAction|internalMutation|internalAction)/;
const DELETE_CODE =
  /\bctx\.db\.delete\s*\(|\bctx\.storage\.delete\s*\(|\bdeleteMany\b|\bdropTable\b|\bmigrations?\.define\b|\bmakeMigration\b|\.runMigration\b|\bclearTable\b|\bdb\.replace\s*\(/;
const MIGRATION_PATH = /(^|\/)migrations?(\/|\.[cm]?[jt]s$)/i;
const SCHEMA_PATH = /(^|\/)schema\.[cm]?[jt]s$/i;
const SCHEMA_CODE = /\bdefineTable\s*\(|\bdefineSchema\s*\(|\.index\s*\(\s*["'`]/;
const PAYMENTS = /\b(stripe|billing|payments?|checkout|subscriptions?|invoices?|paywall|priceId|price_id|lemonsqueezy|paddle|refunds?)\b/i;
const PAYMENTS_PATH = /(stripe|billing|payment|checkout|subscription|invoice|paywall)/i;
const SECRET_CODE =
  /\bprocess\.env\b|\bDeno\.env\b|\bimport\.meta\.env\b|\b(api[_-]?key|apiKey|secret|private[_-]?key|privateKey|access[_-]?token|accessToken|client[_-]?secret|clientSecret|webhook[_-]?secret)\b/i;
const SECRET_PATH = /(^|\/)\.env[^/]*$|(^|\/)(secrets?|credentials?)([./_-][^/]*)?$/i;
const PERMISSION_CODE =
  /\b(permissions?|sharing|shared|shareWith|shareLink|isAdmin|setRole|roles?|acl|ownerId|owner|canRead|canWrite|canEdit|canView|collaborators?|invites?|visibility|isPublic|requireAdmin|requireOwner)\b/;
const PERMISSION_PATH = /(^|\/)[^/]*(permission|sharing|share|roles?|acl|access|invite|collaborat)[^/]*$/i;
export const IOS_PATH =
  /\.(swift|m|mm|xib|storyboard|entitlements|xcconfig|pbxproj|xcscheme|xcworkspacedata)$|\.xcodeproj\/|\.xcworkspace\/|(^|\/)(Podfile|Podfile\.lock|Package\.swift|Package\.resolved|project\.yml|Info\.plist)$|(^|\/)ios\//;

/**
 * The risk flags for a change, from the diff alone: its paths, whether each
 * file is new, and the lines it adds and removes. Fixed rules, in a fixed
 * order (RISK_KINDS); nothing the agent wrote about the change is read.
 * Content rules skip test files (a delete in a test isn't one in the app).
 * With no diff text, only the path rules apply (`files` from the run).
 */
export function riskFlags(input: { diffText?: string | null; files?: string[] }): RiskFlag[] {
  const parsed: DiffFile[] = input.diffText
    ? parseDiffFiles(input.diffText)
    : (input.files ?? []).map((path) => ({ path, status: "modified" as const, added: [], removed: [] }));
  const hits = new Map<RiskKind, string[]>();
  const hit = (kind: RiskKind, path: string) => {
    const list = hits.get(kind) ?? [];
    if (!list.includes(path)) list.push(path);
    hits.set(kind, list);
  };
  for (const f of parsed) {
    const p = f.path;
    const code = CODE_FILE.test(p) && !TEST_FILE.test(p);
    const changed = code ? [...f.added, ...f.removed] : [];
    const added = code ? f.added : [];
    const any = (re: RegExp, lines: string[]) => lines.some((l) => re.test(l));

    if (IOS_PATH.test(p)) hit("ios", p);
    if (isDependencyFile(p)) hit("dependencies", p);
    if (!TEST_FILE.test(p)) {
      if (AUTH_PATH.test(p) || any(AUTH_CODE, changed)) hit("auth", p);
      if ((f.status === "added" && AUTH_PATH.test(p)) || any(NEW_ROUTE, added) || any(NEW_TOKEN_FN, added)) hit("newAuthPath", p);
      if (f.status === "deleted" && /(^|\/)convex\//.test(p)) hit("dataDeletion", p);
      if (MIGRATION_PATH.test(p) || any(DELETE_CODE, added)) hit("dataDeletion", p);
      if ((SCHEMA_PATH.test(p) && /(^|\/)convex\//.test(p)) || any(SCHEMA_CODE, changed)) hit("schema", p);
      if (PAYMENTS_PATH.test(p) || any(PAYMENTS, changed)) hit("payments", p);
      if (SECRET_PATH.test(p) || any(SECRET_CODE, added)) hit("secrets", p);
      if (PERMISSION_PATH.test(p) || any(PERMISSION_CODE, changed)) hit("permissions", p);
    }
  }
  return RISK_KINDS.filter((k) => hits.has(k)).map((kind) => {
    const files = hits.get(kind)!;
    return { kind, label: RISK_LABELS[kind], files: files.slice(0, CARD_LIMITS.filesPerFlag), count: files.length };
  });
}
