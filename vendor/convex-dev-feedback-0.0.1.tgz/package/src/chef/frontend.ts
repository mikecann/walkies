// The frontend artifact (docs/chef-pipeline.md, "The preview"). The app's
// frontend is built in the build sandbox, by the runner, as the agent user,
// with the Convex URL set to a placeholder. The deploy sandbox, which holds
// the real preview deploy key, runs no repo code: it gets the built files,
// swaps the placeholder for the preview's URL as a plain string replace, and
// uploads them. No Convex imports: the runner, the component, the HTTP route
// and the launcher all use this.

/**
 * What the build sees as its Convex URL. `.invalid` can never resolve
 * (RFC 2606), so a build that somehow keeps it talks to nothing. The deploy
 * sandbox's unpacker (runner/chef-frontend-unpack.mjs) has the same string.
 */
export const CONVEX_URL_PLACEHOLDER = "https://__CHEF_CONVEX_URL__.invalid";

/**
 * The most a gzipped artifact may be. Convex HTTP actions take request
 * bodies up to 20 MB, and the bytes then cross one action argument; 8 MiB
 * leaves room under both. A built frontend is usually a few MB.
 */
export const MAX_ARTIFACT_BYTES = 8 * 1024 * 1024;

/** The most files and unpacked bytes an artifact may hold. */
export const MAX_ARTIFACT_FILES = 5000;
export const MAX_ARTIFACT_UNPACKED_BYTES = 200 * 1024 * 1024;

export type FrontendConfig = {
  /** Run as the agent user in the checkout. Default `npm run build`. */
  command?: string[];
  /** The variable the build reads the Convex URL from. Default VITE_CONVEX_URL. */
  urlEnvVar?: string;
  /** The build's output directory, relative to the checkout. Default dist. */
  distDir?: string;
};

export type ResolvedFrontend = { command: string[]; urlEnvVar: string; distDir: string };

export const DEFAULT_FRONTEND: ResolvedFrontend = {
  command: ["npm", "run", "build"],
  urlEnvVar: "VITE_CONVEX_URL",
  distDir: "dist",
};

const ENV_NAME = /^[A-Z_][A-Z0-9_]*$/;
const DIST = /^[A-Za-z0-9_][A-Za-z0-9_.-]*(\/[A-Za-z0-9_][A-Za-z0-9_.-]*)*$/;
// Names the runner sets itself or that would change how the build's tools load.
const RESERVED_ENV = new Set(["PATH", "HOME", "NODE_OPTIONS", "LD_PRELOAD", "LD_LIBRARY_PATH"]);

/** Fills in defaults and checks the shapes. Throws on anything malformed. */
export function resolveFrontendConfig(cfg: FrontendConfig | undefined): ResolvedFrontend {
  const out: ResolvedFrontend = {
    command: cfg?.command ?? DEFAULT_FRONTEND.command,
    urlEnvVar: cfg?.urlEnvVar ?? DEFAULT_FRONTEND.urlEnvVar,
    distDir: cfg?.distDir ?? DEFAULT_FRONTEND.distDir,
  };
  if (!Array.isArray(out.command) || out.command.length === 0 || !out.command.every((s) => typeof s === "string")) {
    throw new Error("frontend.command must be a non-empty argv");
  }
  if (typeof out.urlEnvVar !== "string" || !ENV_NAME.test(out.urlEnvVar) || RESERVED_ENV.has(out.urlEnvVar)) {
    throw new Error("frontend.urlEnvVar must be an upper-case variable name");
  }
  if (typeof out.distDir !== "string" || !DIST.test(out.distDir) || out.distDir.split("/").some((p) => p === "." || p === "..")) {
    throw new Error("frontend.distDir must be a relative path inside the checkout");
  }
  return out;
}

const SHA256 = /^[0-9a-f]{64}$/;
const SHA40 = /^[0-9a-f]{40}$/;

export const isSha256Hex = (s: unknown): s is string => typeof s === "string" && SHA256.test(s);
export const isCommitSha = (s: unknown): s is string => typeof s === "string" && SHA40.test(s);
