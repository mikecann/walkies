// The web preview of a build (docs/chef-pipeline.md, "The preview"): which
// changes it could show at all, and which Convex preview deployment a run's
// preview is. Pure, no Convex imports: the component, the host's launcher
// (packages/chef-cloud) and the local worker share it.

import { IOS_PATH } from "./card.js";

// ---------------------------------------------------------------- what a preview can show

/** Why a build gets no web preview: its change is nowhere the preview serves. */
export type PreviewSkip = {
  /** "app": the phone or Mac app (with tests or docs, perhaps); "testsOrDocs": only tests and docs. */
  kind: "app" | "testsOrDocs";
  /** One line for people: the card, the request's history, the build email, the run log. */
  note: string;
};

export const NO_PREVIEW_NOTES: Record<PreviewSkip["kind"], string> = {
  app: "This change is to the phone or Mac app, so there's no web preview — it ships with the next app build.",
  testsOrDocs: "This change is only to tests or docs, so there's no web preview — nothing on the site looks different.",
};

// The phone and Mac apps' own files: what the "ios" risk flag reads (Swift,
// Xcode projects, Podfiles, Info.plist, an ios/ directory), the Mac app's
// directory, and an Xcode app's resources (asset catalogs, localizations).
const MAC_APP = /(^|\/)apps\/mac\//;
const XCODE_RESOURCE = /\.(xcassets|lproj|xcdatamodeld)\/|\.(xcstrings|strings|stringsdict|plist|entitlements|xcprivacy)$/;
// Tests: a test or spec file, or anything under a tests directory.
const TEST = /\.(test|spec)\.[cm]?[jt]sx?$|(^|\/)(tests?|__tests__)\//;
// Docs: Markdown, or anything under a docs directory.
const DOC = /\.md$|(^|\/)docs\//i;
// Where a test or a doc could still be the app: the Convex backend (it
// bundles its whole directory), and directories a web build serves or
// routes from (a Markdown page, a file in public/).
const SERVED = /(^|\/)(convex|public|static|app|pages|content)\//;

const isApp = (p: string) => IOS_PATH.test(p) || MAC_APP.test(p) || XCODE_RESOURCE.test(p);
const isTestOrDoc = (p: string) => (TEST.test(p) || DOC.test(p)) && !SERVED.test(p);

/**
 * Whether a build's web preview would show nothing new: every file it
 * changed is the phone or Mac app's, a test, or a doc. Conservative: any
 * other file (the Convex backend, the web app, a library, a package file,
 * config), or no list of files at all, and the preview deploys as before.
 * Null means "preview it".
 */
export function previewSkip(files: readonly string[] | null | undefined): PreviewSkip | null {
  const list = (files ?? []).filter((f) => f !== "");
  if (list.length === 0) return null;
  let app = false;
  for (const p of list) {
    if (isApp(p)) app = true;
    else if (!isTestOrDoc(p)) return null;
  }
  const kind = app ? "app" : "testsOrDocs";
  return { kind, note: NO_PREVIEW_NOTES[kind] };
}

// ---------------------------------------------------------------- the preview's name

/**
 * A run's Convex preview deployment is named after its request, not its
 * commit: `chef-req-<item number>` (a batch's, after the request that leads
 * it). The deploy script's `convex deploy --preview-create <name>` replaces
 * a preview of that name that already exists, so a retry or a follow-up
 * build of the same request takes its earlier preview's place instead of a
 * new slot on the Convex team. `chef-<sha12>` is the old name, still used
 * when a run has no request number, and still accepted from a deploy
 * script that predates `CHEF_PREVIEW_NAME`.
 */
export function previewNameFor(o: { itemNumber: number | null | undefined; sha: string }): string {
  const n = o.itemNumber;
  if (typeof n === "number" && Number.isSafeInteger(n) && n > 0 && n < 1e9) return `chef-req-${n}`;
  return legacyPreviewName(o.sha);
}

/** The name before previews were per request: `chef-<sha12>`. */
export const legacyPreviewName = (sha: string) => `chef-${sha.slice(0, 12)}`;

/** Every name Chef gives a preview; the deploy script checks CHEF_PREVIEW_NAME against the same pattern. */
export const PREVIEW_NAME_RE = /^chef-(req-[1-9][0-9]{0,8}|[0-9a-f]{12})$/;

/** The names a run's preview may have: its request's, or the old per-commit one. */
export function isRunPreviewName(name: unknown, o: { itemNumber: number | null | undefined; sha: string }): name is string {
  return typeof name === "string" && (name === previewNameFor(o) || name === legacyPreviewName(o.sha));
}

/** The request number in a request branch, `chef-req/<number>-<run8>` (src/chef/prompt.ts requestBranchName). */
export function itemNumberOfBranch(branch: string | null | undefined): number | null {
  const m = /^chef-req\/([1-9][0-9]{0,8})-/.exec(branch ?? "");
  return m ? Number(m[1]) : null;
}
