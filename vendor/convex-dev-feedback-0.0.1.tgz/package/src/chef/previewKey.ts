// The preview deploy key, split (docs/chef-pipeline.md, "The preview"). A
// Convex preview deploy key is `preview:<team>:<project>|<secret>`. The part
// before `|` names the project and isn't secret; the CLI parses it locally.
// The part after it is the credential. No Convex imports: the host's action
// and the component both use this.

/** `preview:<team>:<project>`, the non-secret prefix. */
export const PREVIEW_KEY_PREFIX_RE = /^preview:[A-Za-z0-9][A-Za-z0-9_-]{0,63}:[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/;

export function isPreviewKeyPrefix(prefix: string): boolean {
  return PREVIEW_KEY_PREFIX_RE.test(prefix);
}

/**
 * Split a pasted preview deploy key into its prefix and secret. Throws for
 * anything else (a `prod:` or `dev:` key, a bare secret, a malformed prefix).
 * Error messages never repeat any part of the input.
 */
export function splitPreviewDeployKey(key: string): { prefix: string; secret: string } {
  const trimmed = key.trim();
  const bar = trimmed.indexOf("|");
  if (bar < 0) throw new Error("Not a deploy key: expected preview:<team>:<project>|<secret>");
  const prefix = trimmed.slice(0, bar);
  const secret = trimmed.slice(bar + 1);
  if (!prefix.startsWith("preview:")) {
    throw new Error(
      "Only a preview deploy key is accepted (preview:<team>:<project>|...); " +
        "a production or development key never goes into a sandbox",
    );
  }
  if (!isPreviewKeyPrefix(prefix)) throw new Error("Malformed preview deploy key prefix");
  if (secret.length < 8 || /[\s|]/.test(secret)) throw new Error("Malformed preview deploy key");
  return { prefix, secret };
}
