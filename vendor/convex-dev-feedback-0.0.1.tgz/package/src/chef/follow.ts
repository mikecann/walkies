// "Ship it" follows main (docs/chef-pipeline.md, "When main moves under Ship
// it"). An approval binds to the build's own change, not to where main was:
// when main moves before or during a release, Chef merges it in and ships on
// the same approval if the build's own change is what was approved. This
// module is the pure part: the change's fingerprint, taken from the release
// diff the admin approved, and the rule that says whether a merged change is
// still covered. No Convex imports; the component and the tests share it.

import { sha256Hex } from "./snapshotHash.js";

/** How many times one approval follows main on its own before it waits for a person. */
export const MAX_FOLLOW_MERGES = 3;
/** Fix rounds a release merge's agent gets to resolve conflicts or fix the checks. */
export const MERGE_REPAIR_ROUNDS = 2;
/** The most change blocks kept per diff; past it only the whole hash compares. */
export const MAX_CHANGE_BLOCKS = 2000;
/** The most of a resolution diff (what Chef's agent changed to merge main in) kept for the card. */
export const RESOLUTION_DIFF_MAX_BYTES = 64 * 1024;

export type ChangeFingerprint = {
  /** sha256 over every block, sorted: equal when the build's own change is byte-identical. */
  changeHash: string;
  /** One entry per block, `<hash16>:<path>`, sorted; absent past MAX_CHANGE_BLOCKS. */
  blocks?: string[];
};

const PATH_IN_HEADER = /^diff --git a\/(.*) b\/(.*)$/;

/**
 * The build's own change in a release diff (`git diff <main>..<commit>`
 * with RELEASE_DIFF_ARGS), without what depends on where main is: hunk line
 * numbers, context lines and, for text files, the `index` line (whose blob
 * ids change whenever main changed the same file elsewhere). What is left is
 * every file's header (paths, modes, new or deleted, a binary file's
 * post-image blob) and every run of removed and added lines, each a "block"
 * hashed with its file. Two diffs of the same change on top of different
 * mains have the same blocks; a merge that changed any of the build's lines
 * doesn't.
 */
export async function changeFingerprint(diffText: string): Promise<ChangeFingerprint> {
  const blocks: string[] = [];
  let path = "";
  let header: string[] = [];
  let index: string | null = null;
  let binary = false;
  let run: string[] = [];
  let inHunk = false;
  const flushRun = async () => {
    if (run.length === 0) return;
    blocks.push(`${(await sha256Hex(`${path}\n${run.join("\n")}`)).slice(0, 16)}:${path}`);
    run = [];
  };
  const flushFile = async () => {
    await flushRun();
    if (!path) return;
    const meta = [...header, ...(binary && index ? [index] : [])];
    blocks.push(`${(await sha256Hex(`${path}\n#meta\n${meta.join("\n")}`)).slice(0, 16)}:${path}`);
  };
  for (const line of diffText.split("\n")) {
    if (line.startsWith("diff --git ")) {
      await flushFile();
      const m = PATH_IN_HEADER.exec(line);
      path = (m ? m[2] : line.slice(11)).slice(0, 200);
      header = [line];
      index = null;
      binary = false;
      inHunk = false;
      continue;
    }
    if (!path) continue;
    if (!inHunk) {
      if (line.startsWith("@@")) {
        inHunk = true;
        continue;
      }
      if (line.startsWith("index ")) {
        // The post-image blob: only a binary file's content is in no other line.
        index = line.split(" ")[1]?.split("..")[1] ?? line;
        continue;
      }
      if (line.startsWith("Binary files ")) binary = true;
      if (line !== "") header.push(line);
      continue;
    }
    if (line.startsWith("@@")) {
      await flushRun();
      continue;
    }
    if (line.startsWith("+") || line.startsWith("-") || line.startsWith("\\")) run.push(line);
    else await flushRun();
  }
  await flushFile();
  blocks.sort();
  const changeHash = await sha256Hex(blocks.join("\n"));
  return blocks.length <= MAX_CHANGE_BLOCKS ? { changeHash, blocks } : { changeHash };
}

export type Coverage =
  | { covered: true; same: boolean }
  | { covered: false; reason: string; files: string[] };

/**
 * Whether an approval of `approved` covers `merged`: the same change, or
 * every block of it approved (the rest already on main, so it dropped out
 * of the diff: a release that shipped part of an approved build's change, or
 * a hotfix that made the same edit). A dependency change needs its own
 * confirmation. Anything else (a block the admin never saw: a conflict's
 * resolution, an agent's fix, main changing the build's own lines) is not
 * covered, and the files it is in are named.
 */
export function coverage(
  approved: { changeHash: string; blocks?: string[] },
  merged: { changeHash: string; blocks?: string[]; depsChanged: boolean },
  depsAcknowledged: boolean,
): Coverage {
  if (merged.depsChanged && !depsAcknowledged) {
    return { covered: false, reason: "the merged change touches dependencies, and that wasn't confirmed", files: [] };
  }
  if (merged.changeHash === approved.changeHash) return { covered: true, same: true };
  if (!approved.blocks || !merged.blocks) {
    return { covered: false, reason: "the change is too large to compare block by block, and it isn't byte-identical", files: [] };
  }
  const left = new Map<string, number>();
  for (const b of approved.blocks) left.set(b, (left.get(b) ?? 0) + 1);
  const files = new Set<string>();
  for (const b of merged.blocks) {
    const n = left.get(b) ?? 0;
    if (n > 0) left.set(b, n - 1);
    else files.add(b.slice(b.indexOf(":") + 1));
  }
  if (files.size === 0) return { covered: true, same: false };
  const list = [...files].sort();
  return { covered: false, reason: `what ships changed with the merge (${fileList(list)})`, files: list };
}

/** "a, b and 3 more". */
export function fileList(files: readonly string[], max = 3): string {
  if (files.length === 0) return "no files";
  const shown = files.slice(0, max);
  return files.length > max ? `${shown.join(", ")} and ${files.length - max} more` : shown.join(", ");
}

/** Where a release that follows main is. */
export type FollowStatus = "merging" | "needsApproval" | "failed" | "stalled" | "merged";

export type FollowState = {
  status: FollowStatus;
  mainSha: string;
  attempts: number;
  reason?: string | null;
  files?: string[] | null;
  conflicts?: string[] | null;
  repaired?: boolean | null;
};

/**
 * A release's follow state in words, for the panel, the React card and
 * ChefKit (which repeats these texts): "Merged main in", "Resolving a
 * conflict", "Needs you: conflict in X".
 */
export function followText(seq: number, f: FollowState): string {
  const main = f.mainSha.slice(0, 7);
  switch (f.status) {
    case "merging":
      return f.conflicts && f.conflicts.length
        ? `Release #${seq}: main moved (${main}). Resolving a conflict in ${fileList(f.conflicts)}…`
        : `Release #${seq}: main moved (${main}). Merging main in and checking again; it ships on its own if the change is the same…`;
    case "merged":
      return `Release #${seq}: merged main ${main} in (clean). Shipping on the same approval…`;
    case "needsApproval":
      return f.repaired
        ? `Release #${seq}: merged main ${main} in; Chef resolved ${f.conflicts && f.conflicts.length ? `conflicts in ${fileList(f.conflicts)}` : `the checks in ${fileList(f.files ?? [])}`}. Approve the resolution to ship.`
        : `Release #${seq}: merged main ${main} in, and ${f.reason ?? "what ships changed"}. Approve the merged change to ship.`;
    case "failed":
      return `Needs you: ${f.conflicts && f.conflicts.length ? `conflict in ${fileList(f.conflicts)}` : "merging main in failed"}. ${f.reason ?? ""} The approval is kept: Try again merges main in once more.`.trim();
    case "stalled":
      return `Needs you: main moved ${f.attempts} times while release #${seq} was shipping. The approval is kept: Ship it again merges the newest main in.`;
  }
}
