// The preview's one-time sign-in link (docs/chef-pipeline.md, "The preview").
// The app's `loginLinkFunction` returns it from the preview; the deploy
// script checks it and writes it only to its result file. It holds a sign-in
// token, so it is kept out of every log and output: it lives on the run row,
// which only admins read, and in the build email. No Convex imports: the
// host's action and the component both use this.

const DEPLOYMENT_NAME = /^[a-z0-9-]{1,64}$/;
export const MAX_LOGIN_URL = 4096;

/**
 * The link if it is https on exactly `<deploymentName>.convex.site`, with
 * no credentials and no port; null otherwise. Never throws, and never
 * repeats the input.
 */
export function checkPreviewLoginUrl(url: unknown, deploymentName: string): string | null {
  if (typeof url !== "string" || !DEPLOYMENT_NAME.test(deploymentName)) return null;
  // eslint-disable-next-line no-control-regex
  if (url.length > MAX_LOGIN_URL || /[\s\x00-\x1f\x7f]/.test(url)) return null;
  let u: URL;
  try {
    u = new URL(url);
  } catch {
    return null;
  }
  if (u.protocol !== "https:" || u.username !== "" || u.password !== "" || u.port !== "") return null;
  if (u.hostname !== `${deploymentName}.convex.site`) return null;
  return u.href;
}
