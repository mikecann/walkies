// The plain-language Ship card (docs/chef-pipeline.md, "The Ship card"): for
// one build, or for what "Ship it" would ship, everything an owner needs to
// decide on a phone, in one read: what changed and what to try (the agents'
// summaries, untrusted text), the screenshots, the preview links, the risk
// flags (from the diff, by fixed rules: src/chef/card.ts), and the diff's
// facts for "Details". Admins only; null for everyone else.
import { v } from "convex/values";
import { query } from "./_generated/server.js";
import type { QueryCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import { isAdminUser } from "./access.js";
import { coveredRuns, newestBuiltRun } from "./chefShip.js";
import { runItemIds } from "./chefRuns.js";
import { screenshotsOf, vScreenshot } from "./chefScreenshots.js";
import { vRiskFlag, vRunPhase, vRunStatus } from "./schema.js";
import { parseEachRequest, parseSummaryCard, riskFlags } from "../chef/card.js";
import { previewSkip } from "../chef/preview.js";
import { betaSettingsRow, betaStateOf } from "./chefBeta.js";

/** The beta channel (chefBeta.ts): where the beta is, and whether this build is on it ("Promote to everyone"). */
export const vCardBeta = v.object({
  siteUrl: v.string(),
  onBeta: v.boolean(),
  deployedAt: v.union(v.number(), v.null()),
  status: v.union(v.literal("deploying"), v.literal("deployed"), v.literal("failed"), v.null()),
  note: v.union(v.string(), v.null()),
});

const vCardRequest = v.object({
  runId: v.id("chefRuns"),
  itemId: v.id("items"),
  number: v.union(v.number(), v.null()),
  title: v.string(),
  whatChanged: v.array(v.string()),
  whatToTry: v.array(v.string()),
  /** Whether that build's agent wrote the two sections at all. */
  wroteSummary: v.boolean(),
  /** A batch build (chefBatches.ts): the other requests it built together with this one. */
  builtWith: v.array(v.number()),
});

export const vCard = v.object({
  runId: v.id("chefRuns"),
  seq: v.number(),
  status: vRunStatus,
  phase: vRunPhase,
  commitSha: v.union(v.string(), v.null()),
  finishedAt: v.union(v.number(), v.null()),
  previewUrl: v.union(v.string(), v.null()),
  previewLoginUrl: v.union(v.string(), v.null()),
  /** The preview was seeded with the admin's own data ("admin-copy", chefPreviewData.ts). */
  previewHasYourData: v.boolean(),
  /** Why a built run has no preview: its change is only the phone or Mac app, tests or docs (src/chef/preview.ts). */
  previewNote: v.union(v.string(), v.null()),
  /** The newest build first; for a ship, every request it ships. */
  requests: v.array(vCardRequest),
  screenshots: v.array(vScreenshot),
  flags: v.array(vRiskFlag),
  /** "diff" when the flags come from the whole diff, "paths" when only from the file names. */
  flagsFrom: v.union(v.literal("diff"), v.literal("paths")),
  /** The release diff's facts, for "Details"; null when the build uploaded none. */
  details: v.union(
    v.null(),
    v.object({
      diffHash: v.string(),
      chunkCount: v.number(),
      bytes: v.number(),
      files: v.number(),
      filesTruncated: v.boolean(),
      depsChanged: v.boolean(),
      redactions: v.number(),
    }),
  ),
  filesChanged: v.number(),
  /** The demo videos (chefDemo.ts): the feature being used, on the preview. */
  videos: v.array(
    v.object({
      viewport: v.union(v.literal("phone"), v.literal("desktop")),
      url: v.union(v.string(), v.null()),
      durationMs: v.number(),
      failed: v.union(v.null(), v.object({ step: v.number(), what: v.string(), reason: v.string() })),
    }),
  ),
  /** Why there's no video, or where it stopped. */
  demoNote: v.union(v.string(), v.null()),
  /** Null without a beta channel. */
  beta: v.union(v.null(), vCardBeta),
  /** `npx chef ios` on the developer's Mac: compiled ✓ / installed ✓. Null until it ran. */
  iosCheck: v.union(
    v.null(),
    v.object({ compiled: v.boolean(), installed: v.boolean(), at: v.number(), device: v.union(v.string(), v.null()), error: v.union(v.string(), v.null()) }),
  ),
});

async function cardBeta(ctx: QueryCtx, run: Doc<"chefRuns">) {
  const b = betaStateOf(await betaSettingsRow(ctx));
  if (!b) return null;
  const onBeta = b.runId === run._id || (b.sha !== null && b.sha === run.commitSha);
  return {
    siteUrl: b.siteUrl,
    onBeta,
    deployedAt: onBeta ? b.deployedAt : null,
    status: run.beta?.status ?? null,
    note: run.beta?.note ?? null,
  };
}

type RunItem = { itemId: Id<"items">; number: number | null; title: string };

/**
 * One request's lines on the card. A batch build's summary is one for all
 * of it: its shared sections go with the batch's first request, and each
 * request gets its own line from "Each request" when the agent wrote one.
 */
function requestOf(run: Doc<"chefRuns">, it: RunItem, all: RunItem[]) {
  const card = parseSummaryCard(run.summary);
  const builtWith = all.filter((o) => o.itemId !== it.itemId && o.number !== null).map((o) => o.number!);
  if (!run.batch || all.length <= 1) {
    return {
      runId: run._id,
      itemId: it.itemId,
      number: it.number,
      title: it.title,
      whatChanged: card.whatChanged,
      whatToTry: card.whatToTry,
      wroteSummary: card.whatChanged.length > 0 || card.whatToTry.length > 0,
      builtWith,
    };
  }
  const notes = parseEachRequest(run.summary, all.flatMap((o) => (o.number === null ? [] : [o.number])));
  const note = it.number !== null ? notes.get(it.number) : undefined;
  const lead = it.itemId === run.itemId;
  const whatChanged = [...(note ? [note] : []), ...(lead ? card.whatChanged : [])];
  const whatToTry = lead ? card.whatToTry : [];
  return {
    runId: run._id,
    itemId: it.itemId,
    number: it.number,
    title: it.title,
    whatChanged,
    whatToTry,
    wroteSummary: whatChanged.length > 0 || whatToTry.length > 0,
    builtWith,
  };
}

/** A run's requests on the card: its own, then a batch's others. */
async function runRequests(ctx: QueryCtx, run: Doc<"chefRuns">) {
  const all: RunItem[] = [];
  for (const itemId of runItemIds(run)) {
    const item = await ctx.db.get("items", itemId);
    all.push({ itemId, number: item?.number ?? null, title: item?.title ?? "" });
  }
  return all.map((it) => requestOf(run, it, all));
}

/**
 * The card for one run (`runId`), or, without one, for "Ship it"'s
 * candidate: the newest built run, with every request a ship of it covers.
 * Admins only; null for everyone else, and for an unknown run.
 */
export const card = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())), runId: v.optional(v.string()) },
  returns: v.union(v.null(), vCard),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    let run: Doc<"chefRuns"> | null;
    if (args.runId !== undefined) {
      const id = ctx.db.normalizeId("chefRuns", args.runId);
      run = id === null ? null : await ctx.db.get("chefRuns", id);
    } else run = await newestBuiltRun(ctx);
    if (!run) return null;

    const requests = await runRequests(ctx, run);
    if (args.runId === undefined) {
      const done = new Set<string>([run._id]);
      const covered = await coveredRuns(ctx, run);
      const coveredItems = new Set<string>(covered.map((c) => c.itemId));
      for (const c of covered) {
        if (done.has(c.runId) || requests.some((r) => r.itemId === c.itemId)) continue;
        done.add(c.runId);
        const other = await ctx.db.get("chefRuns", c.runId);
        if (!other) continue;
        // The covered requests of that build (a batch's, all of them still unshipped).
        for (const r of await runRequests(ctx, other)) {
          if (coveredItems.has(r.itemId) && !requests.some((x) => x.itemId === r.itemId)) requests.push(r);
        }
      }
    }
    const d = run.releaseDiff;
    const fromDiff = run.riskFlags !== undefined;
    return {
      runId: run._id,
      seq: run.seq,
      status: run.status,
      phase: run.endedPhase ?? run.phase,
      commitSha: run.commitSha ?? null,
      finishedAt: run.finishedAt ?? null,
      previewUrl: run.previewUrl ?? null,
      previewLoginUrl: run.previewLoginUrl ?? null,
      previewHasYourData: run.previewAdminCopy === true,
      previewNote:
        run.status === "built" && !run.previewUrl && run.refresh?.releaseId === undefined ? (previewSkip(run.filesChanged)?.note ?? null) : null,
      requests,
      screenshots: await screenshotsOf(ctx, run._id),
      flags: fromDiff ? run.riskFlags! : riskFlags({ files: run.filesChanged ?? [] }),
      flagsFrom: fromDiff ? ("diff" as const) : ("paths" as const),
      details: d
        ? {
            diffHash: d.diffHash,
            chunkCount: d.chunkCount,
            bytes: d.bytes,
            files: d.filesChanged.length,
            filesTruncated: d.filesTruncated,
            depsChanged: d.depsChanged,
            redactions: d.redactions,
          }
        : null,
      filesChanged: (run.filesChanged ?? []).length,
      videos: await Promise.all(
        (run.demoVideos ?? []).map(async (x) => ({
          viewport: x.viewport,
          url: await ctx.storage.getUrl(x.storageId),
          durationMs: x.durationMs,
          failed: x.failed ?? null,
        })),
      ),
      demoNote: run.demoNote ?? null,
      beta: await cardBeta(ctx, run),
      iosCheck: run.iosCheck
        ? { compiled: run.iosCheck.compiled, installed: run.iosCheck.installed, at: run.iosCheck.at, device: run.iosCheck.device ?? null, error: run.iosCheck.error ?? null }
        : null,
    };
  },
});
