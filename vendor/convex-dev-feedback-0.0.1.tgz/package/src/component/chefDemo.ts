// The demo video (docs/chef-pipeline.md, "The demo video"), the feedback
// component's side: what the host's demo step needs (forHost), the videos
// it stores in this component's storage (storeVideo, checked by sha256 and
// size), and what admins see (forRun). The recording itself is the host's
// (packages/chef-cloud/src/client/chefDemo.ts) in a demo sandbox.
//
// forRun: admins (null for everyone else). forHost, storeVideo, finish: the
// host only (component functions are never public).
import { v } from "convex/values";
import { action, internalMutation, mutation, query } from "./_generated/server.js";
import type { Id } from "./_generated/dataModel.js";
import { internal } from "./_generated/api.js";
import { isAdminUser } from "./access.js";
import { writeAudit } from "./chefAudit.js";
import { runActor } from "./chefRuns.js";
import { vDemoStep } from "./schema.js";
import { DEMO_LIMITS } from "../chef/demo.js";

const vViewport = v.union(v.literal("phone"), v.literal("desktop"));
const vFailed = v.object({ step: v.number(), what: v.string(), reason: v.string() });

/** What the host's demo step needs: the script, the preview, the demo's sign-in link. Host-only. */
export const forHost = query({
  args: { runId: v.id("chefRuns") },
  returns: v.union(
    v.null(),
    v.object({
      status: v.string(),
      commitSha: v.union(v.string(), v.null()),
      previewUrl: v.union(v.string(), v.null()),
      demoScript: v.union(v.null(), v.object({ steps: v.array(vDemoStep) })),
      loginUrl: v.union(v.string(), v.null()),
      recorded: v.array(vViewport),
    }),
  ),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) return null;
    return {
      status: run.status,
      commitSha: run.commitSha ?? null,
      previewUrl: run.previewUrl ?? null,
      demoScript: run.demoScript ?? null,
      loginUrl: run.previewDemoLoginUrl ?? null,
      recorded: (run.demoVideos ?? []).map((x) => x.viewport),
    };
  },
});

async function sha256Hex(bytes: ArrayBuffer): Promise<string> {
  const d = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes));
  return Array.from(d, (b) => b.toString(16).padStart(2, "0")).join("");
}

/**
 * One demo video into this component's storage, checked against its sha256
 * and the size cap, recorded on the run. Once per viewport: a repeat is a
 * no-op. Host-only.
 */
export const storeVideo = action({
  args: {
    runId: v.id("chefRuns"),
    viewport: vViewport,
    bytes: v.bytes(),
    sha256: v.string(),
    durationMs: v.number(),
    done: v.number(),
    steps: v.number(),
    failed: v.optional(vFailed),
    timedOut: v.optional(v.boolean()),
  },
  returns: v.object({ stored: v.boolean(), reason: v.optional(v.string()) }),
  handler: async (ctx, args): Promise<{ stored: boolean; reason?: string }> => {
    if (args.bytes.byteLength === 0 || args.bytes.byteLength > DEMO_LIMITS.videoBytes) return { stored: false, reason: "size" };
    if ((await sha256Hex(args.bytes)) !== args.sha256) return { stored: false, reason: "sha256" };
    const storageId: Id<"_storage"> = await ctx.storage.store(new Blob([args.bytes], { type: "video/webm" }));
    const { bytes: _bytes, ...facts } = args;
    const ok: boolean = await ctx.runMutation(internal.chefDemo.recordVideo, { ...facts, storageId, size: args.bytes.byteLength });
    if (!ok) await ctx.storage.delete(storageId);
    return ok ? { stored: true } : { stored: false, reason: "already recorded" };
  },
});

export const recordVideo = internalMutation({
  args: {
    runId: v.id("chefRuns"),
    viewport: vViewport,
    storageId: v.id("_storage"),
    sha256: v.string(),
    size: v.number(),
    durationMs: v.number(),
    done: v.number(),
    steps: v.number(),
    failed: v.optional(vFailed),
    timedOut: v.optional(v.boolean()),
  },
  returns: v.boolean(),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) return false;
    const videos = run.demoVideos ?? [];
    if (videos.some((x) => x.viewport === args.viewport)) return false;
    const { runId: _r, size, ...rest } = args;
    await ctx.db.patch("chefRuns", run._id, {
      demoVideos: [
        ...videos,
        {
          ...rest,
          bytes: size,
          ...(rest.failed ? { failed: { step: rest.failed.step, what: rest.failed.what.slice(0, 200), reason: rest.failed.reason.slice(0, 300) } } : {}),
        },
      ],
    });
    await writeAudit(ctx, {
      actor: runActor(run._id),
      action: "demo.video",
      runId: run._id,
      outcome: "ok",
      detail: { viewport: args.viewport, bytes: size, sha256: args.sha256, done: args.done, steps: args.steps, failedStep: args.failed?.step ?? null },
    });
    return true;
  },
});

/** The demo step is over: the demo's sign-in link goes, and why there's no video, if there isn't one. Host-only. */
export const finish = mutation({
  args: { runId: v.id("chefRuns"), note: v.optional(v.string()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) return null;
    await ctx.db.patch("chefRuns", run._id, {
      previewDemoLoginUrl: undefined,
      ...(args.note ? { demoNote: args.note.replace(/[\r\n]+/g, " ").slice(0, 900) } : {}),
    });
    return null;
  },
});

export const vDemoView = v.object({
  videos: v.array(
    v.object({
      viewport: vViewport,
      url: v.union(v.string(), v.null()),
      durationMs: v.number(),
      bytes: v.number(),
      done: v.number(),
      steps: v.number(),
      failed: v.union(v.null(), vFailed),
      timedOut: v.boolean(),
    }),
  ),
  note: v.union(v.string(), v.null()),
});

/** One run's demo videos, with their storage URLs. Admins only: null for everyone else. */
export const forRun = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())), runId: v.string() },
  returns: v.union(v.null(), vDemoView),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    const runId = ctx.db.normalizeId("chefRuns", args.runId);
    const run = runId ? await ctx.db.get("chefRuns", runId) : null;
    if (!run) return null;
    return {
      videos: await Promise.all(
        (run.demoVideos ?? []).map(async (x) => ({
          viewport: x.viewport,
          url: await ctx.storage.getUrl(x.storageId),
          durationMs: x.durationMs,
          bytes: x.bytes,
          done: x.done,
          steps: x.steps,
          failed: x.failed ?? null,
          timedOut: x.timedOut === true,
        })),
      ),
      note: run.demoNote ?? null,
    };
  },
});
