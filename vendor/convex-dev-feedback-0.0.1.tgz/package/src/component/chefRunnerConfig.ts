// The non-secret run settings GET /chef-agent/run hands any runner under
// `config`, when the host's mountChefAgentRoutes passes none of its own:
// the app's repo URL (no credentials), the gates, the frontend build, the
// local env command and the app's sign-in link function. Whatever
// orchestrates builds sets them (the host's chefCloud from
// @convex-dev/chef-cloud does, at setup and at each launch).
// One row. Host-only, like every component function.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { QueryCtx } from "./_generated/server.js";
import type { Doc } from "./_generated/dataModel.js";
import { MAX_FIX_ROUNDS } from "../chef/gates.js";
import { LOGIN_FUNCTION } from "../chef/screenshots.js";

export const vGates = v.union(v.literal("auto"), v.array(v.array(v.string())));
export const vFrontend = v.union(
  v.literal(false),
  v.object({ command: v.array(v.string()), urlEnvVar: v.string(), distDir: v.string() }),
);
export const vLocalEnv = v.union(v.literal("auto"), v.literal(false), v.array(v.string()));

const vConfig = {
  repoUrl: v.optional(v.string()),
  gates: v.optional(vGates),
  frontend: v.optional(vFrontend),
  localEnv: v.optional(vLocalEnv),
  // Fix rounds after a gate regression (src/chef/gates.ts): 0 to 5, default 2.
  fixRounds: v.optional(v.number()),
  // The app's `previewLoginFunction` (`module:function`, returns `{ url }`): the
  // build's screenshots sign in through it on the local backend. A name, never a link.
  loginFunction: v.optional(v.string()),
};

async function read(ctx: QueryCtx): Promise<Doc<"chefRunnerConfig"> | null> {
  return await ctx.db
    .query("chefRunnerConfig")
    .withIndex("by_key", (q) => q.eq("key", "singleton"))
    .unique();
}

const httpsUrl = (u: string) => {
  let url: URL;
  try {
    url = new URL(u);
  } catch {
    return false;
  }
  return url.protocol === "https:" && !url.username && !url.password && !url.search;
};

/**
 * Set the fields given; the others stay. Writes only when something changed,
 * so calling it at every launch costs nothing. Returns whether it wrote.
 */
export const set = mutation({
  args: vConfig,
  returns: v.boolean(),
  handler: async (ctx, args) => {
    if (args.repoUrl !== undefined && !httpsUrl(args.repoUrl)) throw new Error("repoUrl must be an https URL with no credentials");
    if (args.fixRounds !== undefined && (!Number.isInteger(args.fixRounds) || args.fixRounds < 0 || args.fixRounds > MAX_FIX_ROUNDS)) {
      throw new Error(`fixRounds must be a whole number from 0 to ${MAX_FIX_ROUNDS}`);
    }
    if (args.loginFunction !== undefined && !LOGIN_FUNCTION.test(args.loginFunction)) {
      throw new Error("loginFunction must be module:function");
    }
    const row = await read(ctx);
    const next = {
      repoUrl: args.repoUrl ?? row?.repoUrl,
      gates: args.gates ?? row?.gates,
      frontend: args.frontend ?? row?.frontend,
      localEnv: args.localEnv ?? row?.localEnv,
      fixRounds: args.fixRounds ?? row?.fixRounds,
      loginFunction: args.loginFunction ?? row?.loginFunction,
    };
    const same =
      row !== null &&
      JSON.stringify([row.repoUrl, row.gates, row.frontend, row.localEnv, row.fixRounds, row.loginFunction]) ===
        JSON.stringify([next.repoUrl, next.gates, next.frontend, next.localEnv, next.fixRounds, next.loginFunction]);
    if (same) return false;
    const fields = Object.fromEntries(Object.entries(next).filter(([, x]) => x !== undefined));
    if (row) await ctx.db.patch("chefRunnerConfig", row._id, { ...fields, updatedAt: Date.now() });
    else await ctx.db.insert("chefRunnerConfig", { key: "singleton", ...fields, updatedAt: Date.now() });
    return true;
  },
});

/** What GET /chef-agent/run hands the runner under `config`. Never a credential. */
export const get = query({
  args: {},
  returns: v.object(vConfig),
  handler: async (ctx) => {
    const row = await read(ctx);
    if (!row) return {};
    return {
      ...(row.repoUrl !== undefined ? { repoUrl: row.repoUrl } : {}),
      ...(row.gates !== undefined ? { gates: row.gates } : {}),
      ...(row.frontend !== undefined ? { frontend: row.frontend } : {}),
      ...(row.localEnv !== undefined ? { localEnv: row.localEnv } : {}),
      ...(row.fixRounds !== undefined ? { fixRounds: row.fixRounds } : {}),
      ...(row.loginFunction !== undefined ? { loginFunction: row.loginFunction } : {}),
    };
  },
});
