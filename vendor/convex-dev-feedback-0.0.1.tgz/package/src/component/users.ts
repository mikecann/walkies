import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import { hasAppAdminUser, hasAppUser } from "./access.js";

export const vRole = v.union(v.literal("admin"), v.literal("member"));

/** User ids for the deployment's own CLI (chefCloud's setup functions), never an app user. */
export const OPERATOR_PREFIX = "operator:";

// The component now owns a sense of "who's who". Consistent with the trust
// model (the component never reads ctx.auth — the host forwards a trusted
// userId), the host calls `ensure` with the authenticated userId after sign-in.
//
// `ensure` only ever creates **members**. Admins are provisioned explicitly:
// the operator runs chefCloud's `chefSetAdmin` (or `npx chef init --admin`),
// or the host promotes with `setRole` (e.g. syncing an owner's email). Signing
// in first grants nothing. Roles drive visibility: only admins (and agents,
// via an agentKey) may list all active requests/refinements or see build
// status once real users exist. See access.ts.
//
// Installs from before this change keep their admins: existing rows are never
// rewritten here.

export const ensure = mutation({
  args: { userId: v.string() },
  returns: v.object({ userId: v.string(), role: vRole }),
  handler: async (ctx, { userId }) => {
    const existing = await ctx.db
      .query("users")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    if (existing) return { userId, role: existing.role };
    await ctx.db.insert("users", { userId, role: "member", createdAt: Date.now() });
    return { userId, role: "member" as const };
  },
});

export const get = query({
  args: { userId: v.string() },
  returns: v.union(
    v.object({ userId: v.string(), role: vRole, createdAt: v.number() }),
    v.null(),
  ),
  handler: async (ctx, { userId }) => {
    const u = await ctx.db
      .query("users")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    return u ? { userId: u.userId, role: u.role, createdAt: u.createdAt } : null;
  },
});

// Whether any app user (not the CLI's `operator:` identity) has registered:
// the "answer Chef's questions only as an admin, or while nobody has signed
// up" rule. Indexed reads, never a count of the table, so it stays inside
// Convex's read limits however many users there are.
export const hasAppUsers = query({
  args: {},
  returns: v.boolean(),
  handler: async (ctx) => await hasAppUser(ctx),
});

// Admin management: promote/demote. Host gates the call to an existing admin.
export const setRole = mutation({
  args: { userId: v.string(), role: vRole },
  returns: v.null(),
  handler: async (ctx, { userId, role }) => {
    const u = await ctx.db
      .query("users")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    if (u) await ctx.db.patch("users", u._id, { role });
    else await ctx.db.insert("users", { userId, role, createdAt: Date.now() });
    return null;
  },
});

/**
 * Whether an admin exists who is an app user, not the CLI's `operator:` identity.
 * Cloud builds and "Ship it" need one.
 */
export const hasAppAdmin = query({
  args: {},
  returns: v.boolean(),
  handler: async (ctx) => await hasAppAdminUser(ctx),
});

/**
 * Every admin's userId (for the host to notify them, e.g. email on a new request awaiting
 * approval). Small by nature; capped at 100.
 */
export const listAdmins = query({
  args: {},
  returns: v.array(v.string()),
  handler: async (ctx) => {
    const rows = await ctx.db
      .query("users")
      .withIndex("by_role", (q) => q.eq("role", "admin"))
      .take(100);
    return rows.map((r) => r.userId);
  },
});
