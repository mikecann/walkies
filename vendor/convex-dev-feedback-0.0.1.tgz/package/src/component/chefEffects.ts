// The run's side of the orchestration's side effects (docs/chef-pipeline.md,
// "Idempotency and reconciliation for every side effect"). The calls to
// Daytona, Code Storage and Resend, and the ledger of what each call is
// about to do and did, live in @convex-dev/chef-cloud (its `effects`
// table); the run they belong to lives here. So the orchestration asks here
// before it starts something (checkIntent: only the active run may), and
// reports here what it did (recordEffect: the run's sandbox ids and the
// audit log). finishReconciled is how a reconciled run finally frees the slot.
//
// Nothing here stores a secret: secrets are recorded by name, sandboxes by
// id, emails by the provider's message id.
import { v } from "convex/values";
import { checkPreviewLoginUrl } from "../chef/previewLogin.js";
import { isRunPreviewName } from "../chef/preview.js";
import { scrub } from "../chef/scrub.js";
import { mutation, query } from "./_generated/server.js";
import type { QueryCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import { writeAudit } from "./chefAudit.js";
import { finishRun, runActor, runItemIds } from "./chefRuns.js";
import { numberList } from "../chef/batching.js";
import { armRunCheck } from "./chefWatchdog.js";

// A preview deployed again after a transient failure: deploy:2, deploy:3.
// A beta deploy tried once more after a transient failure is `:2`, like a preview's redeploy.
const KEY = /^(sandbox:(build|deploy(:[2-9])?|demo|beta(:2)?)|exec:(runner|deploy(:[2-9])?|demo|beta(:2)?)|email:[a-z][a-z0-9-]{0,30})$/;
const SECRET_NAME = /^chef-[a-z0-9-]{1,60}$/;
const SHA = /^[0-9a-f]{7,64}$/;

async function activeRunId(ctx: QueryCtx): Promise<Id<"chefRuns"> | undefined> {
  const state = await ctx.db
    .query("chefState")
    .withIndex("by_key", (q) => q.eq("key", "singleton"))
    .unique();
  return state?.activeRunId;
}

const effectKind = (key: string) => (key.startsWith("email:") ? "email" : key.startsWith("exec:") ? "exec" : "sandbox");

/**
 * Before the orchestration writes an effect's intent: creating something new
 * (a sandbox, a command) needs the run to be the active run and still
 * active, so a run that was reconciled away can't start anything. Emails go
 * out at the end, from a run that is finishing, so they only need the run.
 * Throws if not allowed.
 */
export const checkIntent = query({
  args: { runId: v.id("chefRuns"), key: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    if (!KEY.test(args.key)) throw new Error(`Bad effect key ${args.key}`);
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) throw new Error("Run not found");
    if (effectKind(args.key) !== "email" && (run.status !== "active" || (await activeRunId(ctx)) !== run._id)) {
      throw new Error("Run is not the active run");
    }
    return null;
  },
});

/**
 * What an effect did, on the run: the sandbox id (created or adopted) on the
 * run, and one audit row. Called once per effect, when the orchestration's
 * ledger records it done.
 */
export const recordEffect = mutation({
  args: {
    runId: v.id("chefRuns"),
    key: v.string(),
    result: v.string(),
    adopted: v.optional(v.boolean()),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    if (!KEY.test(args.key)) throw new Error(`Bad effect key ${args.key}`);
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) throw new Error("Run not found");
    const result = args.result.slice(0, 200);
    const kind = effectKind(args.key);
    if (args.key === "sandbox:build") await ctx.db.patch("chefRuns", args.runId, { buildSandboxId: result });
    if (/^sandbox:deploy(:\d)?$/.test(args.key)) await ctx.db.patch("chefRuns", args.runId, { deploySandboxId: result });
    await writeAudit(ctx, {
      actor: runActor(args.runId),
      action:
        kind === "email"
          ? "email.sent"
          : kind === "exec"
            ? args.adopted
              ? "exec.adopted"
              : "exec.started"
            : args.adopted
              ? "sandbox.adopted"
              : "sandbox.created",
      runId: args.runId,
      target: result,
      outcome: "ok",
      detail: { key: args.key },
    });
    return null;
  },
});

/**
 * An email that could not be sent, audited as `email.failed` with the
 * error's message. The run goes on: the email is a courtesy. The effect
 * stays at its intent.
 */
export const emailFailed = mutation({
  args: { runId: v.id("chefRuns"), key: v.string(), error: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    if (!KEY.test(args.key) || !args.key.startsWith("email:")) throw new Error(`Bad email key ${args.key}`);
    await writeAudit(ctx, {
      actor: runActor(args.runId),
      action: "email.failed",
      runId: args.runId,
      outcome: "error",
      reason: args.error.slice(0, 500),
      detail: { key: args.key },
    });
    return null;
  },
});

/** Audit a secret change by name only, and keep the run's list of its secrets. */
export const recordSecrets = mutation({
  args: {
    runId: v.id("chefRuns"),
    names: v.array(v.string()),
    event: v.union(
      v.literal("created"),
      v.literal("adopted"),
      v.literal("live"),
      v.literal("dead"),
      v.literal("deleted"),
    ),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    if (args.names.length > 10 || args.names.some((n) => !SECRET_NAME.test(n))) {
      throw new Error("Bad secret names");
    }
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) throw new Error("Run not found");
    if (
      (args.event === "created" || args.event === "live") &&
      (run.status !== "active" || (await activeRunId(ctx)) !== run._id)
    ) {
      // Secrets are created, and go live, only for the active run.
      throw new Error("Run is not the active run");
    }
    if (args.event === "created" || args.event === "adopted") {
      const names = Array.from(new Set([...(run.secretNames ?? []), ...args.names]));
      await ctx.db.patch("chefRuns", run._id, { secretNames: names });
    }
    await writeAudit(ctx, {
      actor: runActor(run._id),
      action: `secrets.${args.event}`,
      runId: run._id,
      target: args.names.join(","),
      outcome: "ok",
    });
    return null;
  },
});

/**
 * The runner reported the commit before pushing, but not that the push
 * happened. The orchestration read the refs back: if the request branch and
 * `chef` both point at that commit, the push happened, and the run moves on
 * as if the report had arrived. Also raises an alert if `main` moved.
 */
export const confirmPushFromRefs = mutation({
  args: {
    runId: v.id("chefRuns"),
    refs: v.object({
      branch: v.union(v.string(), v.null()),
      chef: v.union(v.string(), v.null()),
      main: v.union(v.string(), v.null()),
    }),
  },
  returns: v.object({ pushed: v.boolean(), branchPushed: v.boolean(), mainMoved: v.boolean() }),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) throw new Error("Run not found");
    for (const sha of Object.values(args.refs)) {
      if (sha !== null && !SHA.test(sha)) throw new Error("Refs must be hex shas");
    }
    const commit = run.commitSha;
    const branchPushed = !!commit && args.refs.branch === commit;
    // A release merge (chefShip.followMain) goes to its request branch only:
    // it ships through its release, and chef keeps the newer builds.
    const pushed = branchPushed && (args.refs.chef === commit || run.refresh?.releaseId !== undefined);
    // `main` only moves through a release; the run's base is where it was.
    const mainMoved = !!run.baseSha && args.refs.main !== null && args.refs.main !== run.baseSha;
    if (mainMoved) {
      await writeAudit(ctx, {
        actor: "system:refs",
        action: "git.mainMoved",
        runId: run._id,
        outcome: "error",
        reason: "main is not at the run's base sha",
        detail: { baseSha: run.baseSha ?? null, main: args.refs.main },
      });
    }
    if (pushed && (run.status === "active" || run.status === "reconciling") && run.phase === "pushing") {
      const now = Date.now();
      await ctx.db.patch("chefRuns", run._id, {
        phase: "pushed",
        // A release merge's push is its branch only: chef didn't move.
        ...(run.refresh?.releaseId === undefined ? { chefAfter: commit } : {}),
        lastReport: { from: "pushing", to: "pushed", at: now },
      });
    }
    await writeAudit(ctx, {
      actor: "system:refs",
      action: "git.refsRead",
      runId: run._id,
      outcome: "ok",
      detail: {
        commit: commit ?? null,
        branch: args.refs.branch,
        chef: args.refs.chef,
        pushed,
        branchPushed,
      },
    });
    return { pushed, branchPushed, mainMoved };
  },
});

const vReconcileInfo = v.object({
  runId: v.id("chefRuns"),
  status: v.string(),
  phase: v.string(),
  commitSha: v.union(v.string(), v.null()),
  branch: v.union(v.string(), v.null()),
  secretNames: v.array(v.string()),
  sandboxIds: v.array(v.string()),
  pendingOutcome: v.union(v.literal("failed"), v.literal("cancelled"), v.null()),
});

/** What the reconciler needs to know about a run. */
export const reconcileInfo = query({
  args: { runId: v.id("chefRuns") },
  returns: v.union(vReconcileInfo, v.null()),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) return null;
    return {
      runId: run._id,
      status: run.status,
      phase: run.phase,
      commitSha: run.commitSha ?? null,
      branch: run.branch ?? null,
      secretNames: run.secretNames ?? [],
      sandboxIds: [run.buildSandboxId, run.deploySandboxId].filter((x): x is string => !!x),
      pendingOutcome: run.pendingOutcome ?? null,
    };
  },
});

/**
 * The reconciler's last step, after its cleanup: record the outcome and free
 * the slot (finishRun). A run whose commit reached `chef` is built, whatever
 * stopped it, so the item doesn't go back to the queue while `chef` has it.
 */
export const finishReconciled = mutation({
  args: {
    runId: v.id("chefRuns"),
    pushedToChef: v.boolean(),
    cleanup: v.object({
      sandboxesDeleted: v.number(),
      secretsDeleted: v.number(),
    }),
  },
  returns: v.object({ finished: v.boolean() }),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run || run.status !== "reconciling") return { finished: false };
    const outcome = args.pushedToChef ? "built" : (run.pendingOutcome ?? "failed");
    await writeAudit(ctx, {
      actor: "system:reconcile",
      action: "run.reconciled",
      runId: run._id,
      outcome: "ok",
      detail: { outcome, ...args.cleanup, pushedToChef: args.pushedToChef },
    });
    const error = args.pushedToChef
      ? `${run.pendingError ?? "stopped"}; its commit had reached chef`
      : (run.pendingError ?? "reconciled");
    const { finished } = await finishRun(ctx, run._id, outcome, { actor: "system:reconcile", error });
    return { finished };
  },
});

const vRunInfo = v.object({
  runId: v.id("chefRuns"),
  seq: v.number(),
  status: v.string(),
  phase: v.string(),
  startedVia: v.string(),
  deadline: v.number(),
  heartbeatAt: v.number(),
  itemNumber: v.union(v.number(), v.null()),
  title: v.string(),
  baseSha: v.union(v.string(), v.null()),
  branch: v.union(v.string(), v.null()),
  commitSha: v.union(v.string(), v.null()),
  filesChanged: v.array(v.string()),
  error: v.union(v.string(), v.null()),
  previewName: v.union(v.string(), v.null()),
  previewUrl: v.union(v.string(), v.null()),
  // The one-time sign-in link, for the build email only.
  previewLoginUrl: v.union(v.string(), v.null()),
  // The non-secret `preview:<team>:<project>` half of the preview deploy key.
  previewKeyPrefix: v.union(v.string(), v.null()),
  // A release merge (chefShip.followMain): no preview, no email; built once pushed.
  releaseMerge: v.optional(v.boolean()),
});

/** " (built together with #13 and #14)" for a batch run (chefBatches.ts), else "". */
async function togetherWith(ctx: QueryCtx, run: Doc<"chefRuns">): Promise<string> {
  const numbers: number[] = [];
  for (const id of runItemIds(run).slice(1)) {
    const it = await ctx.db.get("items", id);
    if (it) numbers.push(it.number);
  }
  return numbers.length ? ` (built together with ${numberList(numbers)})` : "";
}

/** What the host's orchestration needs to drive a run. Host-only. */
export const runInfo = query({
  args: { runId: v.id("chefRuns") },
  returns: v.union(vRunInfo, v.null()),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) return null;
    const item = await ctx.db.get("items", run.itemId);
    const snapshot = await ctx.db.get("chefSnapshots", run.snapshotId);
    const settings = await ctx.db
      .query("settings")
      .withIndex("by_key", (q) => q.eq("key", "singleton"))
      .unique();
    return {
      runId: run._id,
      seq: run.seq,
      status: run.status,
      phase: run.phase,
      startedVia: run.startedVia,
      deadline: run.deadline,
      heartbeatAt: run.heartbeatAt,
      itemNumber: item?.number ?? null,
      title: `${snapshot?.title ?? item?.title ?? ""}${await togetherWith(ctx, run)}`,
      baseSha: run.baseSha ?? null,
      branch: run.branch ?? null,
      commitSha: run.commitSha ?? null,
      filesChanged: run.filesChanged ?? [],
      error: run.error ?? null,
      previewName: run.previewName ?? null,
      previewUrl: run.previewUrl ?? null,
      previewLoginUrl: run.previewLoginUrl ?? null,
      previewKeyPrefix: settings?.previewKeyPrefix ?? null,
      releaseMerge: run.refresh?.releaseId !== undefined,
    };
  },
});

const BUILT_PHASES = ["pushed", "previewing", "done"];

// The phases the orchestration moves: the grants for the runner's requests
// (`cloned`, `committed`), and everything after the push.
const ORCHESTRATION_TRANSITIONS: Record<string, string> = {
  cloned: "agent",
  committed: "pushing",
  pushed: "previewing",
  previewing: "done",
};

/**
 * Compare-and-set for the orchestration's phases. The orchestration grants
 * `agent` only after it set the git secret dead and narrowed egress, and
 * `pushing` only after the git write credential is live and the git host
 * reachable; the runner waits for the grant. Repeating the last one is a
 * no-op.
 */
export const setPhase = mutation({
  args: {
    runId: v.id("chefRuns"),
    from: v.union(v.literal("cloned"), v.literal("committed"), v.literal("pushed"), v.literal("previewing")),
    to: v.union(v.literal("agent"), v.literal("pushing"), v.literal("previewing"), v.literal("done")),
  },
  returns: v.object({ applied: v.boolean() }),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) throw new Error("Run not found");
    if (run.status !== "active" || (await activeRunId(ctx)) !== run._id) throw new Error("Run is not the active run");
    if (ORCHESTRATION_TRANSITIONS[args.from] !== args.to) throw new Error(`Can't move ${args.from} to ${args.to}`);
    if (run.phase === args.to && run.lastReport?.from === args.from) return { applied: false };
    if (run.phase !== args.from) throw new Error(`Stale: the run is in ${run.phase}`);
    const now = Date.now();
    // A grant keeps the hash of the runner's request it answers, so a replay
    // of that request with other facts is still refused (chefAgent.report).
    const requestHash = run.lastReport?.to === args.from ? run.lastReport.hash : undefined;
    await ctx.db.patch("chefRuns", run._id, {
      phase: args.to,
      lastReport: {
        from: args.from,
        to: args.to,
        at: now,
        ...(requestHash !== undefined ? { hash: requestHash } : {}),
      },
      heartbeatAt: now,
    });
    await writeAudit(ctx, {
      actor: "system:orchestrator",
      action: "run.phase",
      runId: run._id,
      outcome: "ok",
      detail: { from: args.from, to: args.to },
    });
    return { applied: true };
  },
});

/**
 * The orchestration is alive while it waits on something without a runner
 * (the preview deploy), so the run isn't taken for stale.
 */
export const orchestratorHeartbeat = mutation({
  args: { runId: v.id("chefRuns") },
  returns: v.null(),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (run && run.status === "active" && (run.phase === "previewing" || run.phase === "done")) {
      const now = Date.now();
      await ctx.db.patch("chefRuns", run._id, { heartbeatAt: now });
      // A run claimed before deadline checks existed gets its one now.
      if (run.watchdogDueAt === undefined) await armRunCheck(ctx, { ...run, heartbeatAt: now }, now);
    }
    return null;
  },
});

const WARM_NAME = /^chef-warm-[0-9a-f]{12}$/;
const WARM_KEY = /^[0-9a-f]{64}$/;

/**
 * Which warm snapshot (docs/chef-pipeline.md, "Warm snapshots") a run's
 * build or preview deploy sandbox started from, and its key: on the run's
 * provenance, and one `warm.used` audit row. The host's launcher records it
 * as it creates the sandbox. Host-only.
 */
export const recordWarm = mutation({
  args: {
    runId: v.id("chefRuns"),
    role: v.union(v.literal("build"), v.literal("deploy")),
    snapshot: v.string(),
    key: v.string(),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    if (!WARM_NAME.test(args.snapshot) || !WARM_KEY.test(args.key)) throw new Error("Bad warm snapshot");
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) throw new Error("Run not found");
    const mine =
      args.role === "build"
        ? { warmSnapshot: args.snapshot, warmKey: args.key }
        : { previewWarmSnapshot: args.snapshot, previewWarmKey: args.key };
    await ctx.db.patch("chefRuns", run._id, { provenance: { ...run.provenance, ...mine } });
    await writeAudit(ctx, {
      actor: runActor(run._id),
      action: "warm.used",
      runId: run._id,
      target: args.snapshot,
      outcome: "ok",
      detail: { role: args.role, key: args.key },
    });
    return null;
  },
});

/** The launcher's log batches start here, past any seq a runner may use (chefAgent's MAX_LOG_SEQ). */
export const LAUNCHER_LOG_SEQ = 1_000_000;
const MAX_LAUNCHER_LINES = 200;
const MAX_LAUNCHER_LINE = 4000;

/**
 * Lines the orchestration adds to a run's log (chefRunLogs) after its runner
 * is gone: a failed deploy script's last lines, the preview's or a "Ship
 * it" of the run's commit. Scrubbed here as well (the scripts scrub their
 * own output of the deploy key; this catches any other credential shape).
 * Appended after everything else; any run, finished or not. Host-only.
 */
export const appendRunLog = mutation({
  args: { runId: v.id("chefRuns"), lines: v.array(v.string()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) throw new Error("Run not found");
    if (args.lines.length === 0) return null;
    const last = await ctx.db
      .query("chefRunLogs")
      .withIndex("by_runId_and_seq", (q) => q.eq("runId", run._id))
      .order("desc")
      .first();
    const seq = Math.max(LAUNCHER_LOG_SEQ, (last?.seq ?? -1) + 1);
    await ctx.db.insert("chefRunLogs", {
      runId: run._id,
      seq,
      // Scrub the whole line, then cut it, so a cut can't split a secret.
      lines: args.lines.slice(-MAX_LAUNCHER_LINES).map((l) => scrub(l.slice(0, MAX_LAUNCHER_LINE * 4)).slice(0, MAX_LAUNCHER_LINE)),
      at: Date.now(),
    });
    return null;
  },
});

const DEPLOYMENT_NAME = /^[a-z0-9-]{1,64}$/;

/**
 * Record the run's preview deployment. The name must be the run's request's
 * (`chef-req-<number>`, src/chef/preview.ts), or `chef-<sha12>` of its own
 * commit from a deploy script that predates per-request previews, and the
 * URL is the one the orchestration built from the deployment name, never
 * one the sandbox printed. Repeating it is a no-op.
 *
 * Deploying a request's preview again replaces the deployment, so an earlier
 * run of the same request that recorded that name loses its link (its
 * deployment is gone): it is cleared there, not left pointing at nothing.
 */
export const recordPreview = mutation({
  args: {
    runId: v.id("chefRuns"),
    sha: v.string(),
    previewName: v.string(),
    deploymentName: v.string(),
    // The one-time sign-in link the deploy script got from the app, if any.
    loginUrl: v.optional(v.string()),
    // A second one, for the demo video only.
    demoLoginUrl: v.optional(v.string()),
  },
  returns: v.object({ previewName: v.string(), previewUrl: v.string() }),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) throw new Error("Run not found");
    if (run.status !== "active") throw new Error("Run is not active");
    if (!run.commitSha || run.commitSha !== args.sha) throw new Error("Not the run's commit");
    const item = await ctx.db.get("items", run.itemId);
    if (!isRunPreviewName(args.previewName, { itemNumber: item?.number ?? null, sha: args.sha })) {
      throw new Error("Preview name must be the request's (chef-req-<number>) or chef-<sha12>");
    }
    if (!DEPLOYMENT_NAME.test(args.deploymentName)) throw new Error("Bad deployment name");
    const previewUrl = `https://${args.deploymentName}.convex.site`;
    // Checked again here; the error never repeats it.
    const loginUrl = args.loginUrl === undefined ? undefined : checkPreviewLoginUrl(args.loginUrl, args.deploymentName);
    if (loginUrl === null) throw new Error("The sign-in link is not on the preview's own site");
    const demoLoginUrl = args.demoLoginUrl === undefined ? undefined : checkPreviewLoginUrl(args.demoLoginUrl, args.deploymentName);
    if (demoLoginUrl === null) throw new Error("The demo's sign-in link is not on the preview's own site");
    if (run.previewName === args.previewName && run.previewUrl === previewUrl && (loginUrl ?? run.previewLoginUrl) === run.previewLoginUrl) {
      return { previewName: args.previewName, previewUrl };
    }
    for (const earlier of await ctx.db
      .query("chefRuns")
      .withIndex("by_itemId", (q) => q.eq("itemId", run.itemId))
      .order("desc")
      .take(50)) {
      if (earlier._id === run._id || earlier.previewName !== args.previewName || earlier.previewUrl === undefined) continue;
      await ctx.db.patch("chefRuns", earlier._id, { previewUrl: undefined, previewLoginUrl: undefined, previewDemoLoginUrl: undefined });
    }
    await ctx.db.patch("chefRuns", run._id, {
      previewName: args.previewName,
      previewUrl,
      ...(loginUrl !== undefined ? { previewLoginUrl: loginUrl } : {}),
      ...(demoLoginUrl !== undefined ? { previewDemoLoginUrl: demoLoginUrl } : {}),
      heartbeatAt: Date.now(),
    });
    await writeAudit(ctx, {
      actor: "system:orchestrator",
      action: "preview.deployed",
      runId: run._id,
      target: args.previewName,
      outcome: "ok",
      // Whether there is a sign-in link, never the link.
      detail: { deploymentName: args.deploymentName, sha: args.sha, loginLink: loginUrl !== undefined, demoLink: demoLoginUrl !== undefined },
    });
    return { previewName: args.previewName, previewUrl };
  },
});

/**
 * The orchestration's end of a run that is still active: built (only once
 * its commit was pushed) or failed. Its cleanup comes first: secrets dead,
 * sandboxes and secrets deleted. A run that went to reconciling meanwhile is
 * left to the reconciler, which finishes it.
 */
export const finishActive = mutation({
  args: {
    runId: v.id("chefRuns"),
    outcome: v.union(v.literal("built"), v.literal("failed")),
    error: v.optional(v.string()),
  },
  returns: v.object({ finished: v.boolean() }),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) throw new Error("Run not found");
    if (run.status !== "active") return { finished: false };
    if (args.outcome === "built" && !BUILT_PHASES.includes(run.phase)) {
      throw new Error(`A run in ${run.phase} can't be built: its commit wasn't pushed`);
    }
    const { finished } = await finishRun(ctx, run._id, args.outcome, {
      actor: "system:orchestrator",
      ...(args.error !== undefined ? { error: args.error } : {}),
    });
    return { finished };
  },
});

/**
 * Register the host's orchestrator (a function handle from
 * `createFunctionHandle`, to a mutation that starts the run's workflow or an
 * action that drives it). chefOrchestrator.startRun schedules it once per
 * claimed run, with `{ runId }`. Runs from an external runner's enroll are
 * driven by that runner and never handed to it. Host-only.
 */
export const setOrchestrator = mutation({
  args: { handle: v.union(v.string(), v.null()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    const state = await ctx.db
      .query("chefState")
      .withIndex("by_key", (q) => q.eq("key", "singleton"))
      .unique();
    const patch = { orchestratorHandle: args.handle ?? undefined };
    if (state) await ctx.db.patch("chefState", state._id, patch);
    else await ctx.db.insert("chefState", { key: "singleton", nextSeq: 1, ...patch });
    await writeAudit(ctx, {
      actor: "system:host",
      action: "orchestrator.set",
      outcome: "ok",
      detail: { registered: args.handle !== null },
    });
    return null;
  },
});

/**
 * Register the host's reconcile action (a function handle from
 * `createFunctionHandle`). It is scheduled with `{ runId }` whenever a run
 * goes to reconciling. Host-only, like every component function.
 */
export const setReconciler = mutation({
  args: { handle: v.union(v.string(), v.null()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    const state = await ctx.db
      .query("chefState")
      .withIndex("by_key", (q) => q.eq("key", "singleton"))
      .unique();
    const patch = { reconcilerHandle: args.handle ?? undefined };
    if (state) await ctx.db.patch("chefState", state._id, patch);
    else await ctx.db.insert("chefState", { key: "singleton", nextSeq: 1, ...patch });
    await writeAudit(ctx, {
      actor: "system:host",
      action: "reconciler.set",
      outcome: "ok",
      detail: { registered: args.handle !== null },
    });
    return null;
  },
});

/**
 * Register the host's cleanup (a function handle from
 * `createFunctionHandle`, to a mutation that takes no arguments: chefCloud's
 * chefCleanup). finishRun schedules it once each time a run finishes, so
 * whatever the run left is cleaned up then, not by an hourly sweep.
 * Host-only.
 */
export const setCleaner = mutation({
  args: { handle: v.union(v.string(), v.null()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    const state = await ctx.db
      .query("chefState")
      .withIndex("by_key", (q) => q.eq("key", "singleton"))
      .unique();
    const patch = { cleanerHandle: args.handle ?? undefined };
    if (state) {
      if (state.cleanerHandle === patch.cleanerHandle) return null;
      await ctx.db.patch("chefState", state._id, patch);
    } else await ctx.db.insert("chefState", { key: "singleton", nextSeq: 1, ...patch });
    await writeAudit(ctx, {
      actor: "system:host",
      action: "cleaner.set",
      outcome: "ok",
      detail: { registered: args.handle !== null },
    });
    return null;
  },
});

/**
 * For the cleanup sweep: runs that may still own resources (active or
 * reconciling) and the secret names they own. Anything labelled or named for
 * another run is a leftover.
 */
export const liveResources = query({
  args: {},
  returns: v.object({
    runIds: v.array(v.id("chefRuns")),
    secretNames: v.array(v.string()),
    // Open releases, whose ship sandbox (label chef-release) and git secret are live.
    releaseIds: v.array(v.id("chefReleases")),
    // Runs whose repair commit is being made (chefRepairs, label chef-repair).
    repairRunIds: v.optional(v.array(v.id("chefRuns"))),
  }),
  handler: async (ctx) => {
    const runs: Doc<"chefRuns">[] = [];
    for (const status of ["active", "reconciling"] as const) {
      runs.push(
        ...(await ctx.db
          .query("chefRuns")
          .withIndex("by_status", (q) => q.eq("status", status))
          .take(20)),
      );
    }
    const open = await ctx.db
      .query("chefReleases")
      .withIndex("by_open", (q) => q.eq("open", true))
      .take(5);
    return {
      runIds: runs.map((r) => r._id),
      secretNames: [
        ...runs.flatMap((r) => r.secretNames ?? []),
        ...open.flatMap((r) => (r.ship?.secretName ? [r.ship.secretName] : [])),
      ],
      releaseIds: open.map((r) => r._id),
      repairRunIds: (
        await ctx.db
          .query("chefRepairs")
          .withIndex("by_status", (q) => q.eq("status", "making"))
          .take(10)
      ).map((r) => r.runId),
    };
  },
});

export const BRANCH_RETENTION_MS = 14 * 24 * 60 * 60_000;

/** Finished runs whose request branch is older than 14 days and not yet swept. */
export const branchesToSweep = query({
  args: { now: v.number(), limit: v.optional(v.number()) },
  returns: v.array(v.object({ runId: v.id("chefRuns"), branch: v.union(v.string(), v.null()) })),
  handler: async (ctx, args) => {
    const limit = Math.min(50, Math.max(1, Math.floor(args.limit ?? 20) || 20));
    const cutoff = args.now - BRANCH_RETENTION_MS;
    const runs = await ctx.db
      .query("chefRuns")
      .withIndex("by_branchSweptAt_and_finishedAt", (q) =>
        q.eq("branchSweptAt", undefined).gt("finishedAt", 0).lt("finishedAt", cutoff),
      )
      .take(limit);
    return runs.map((r) => ({ runId: r._id, branch: r.branch ?? null }));
  },
});

/**
 * When the oldest request branch not yet swept is due (its run's finish
 * plus 14 days), or null when none is waiting: the cleanup schedules its
 * next branch sweep for then, once, instead of looking every hour.
 */
export const nextBranchExpiry = query({
  args: {},
  returns: v.union(v.number(), v.null()),
  handler: async (ctx) => {
    const oldest = await ctx.db
      .query("chefRuns")
      .withIndex("by_branchSweptAt_and_finishedAt", (q) => q.eq("branchSweptAt", undefined).gt("finishedAt", 0))
      .first();
    return oldest?.finishedAt !== undefined ? oldest.finishedAt + BRANCH_RETENTION_MS : null;
  },
});

export const markBranchSwept = mutation({
  args: { runId: v.id("chefRuns"), deleted: v.boolean() },
  returns: v.null(),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run || run.branchSweptAt !== undefined) return null;
    if (run.status === "active" || run.status === "reconciling") throw new Error("Run is still live");
    await ctx.db.patch("chefRuns", run._id, { branchSweptAt: Date.now() });
    if (args.deleted && run.branch) {
      await writeAudit(ctx, {
        actor: "system:sweep",
        action: "git.branchDeleted",
        runId: run._id,
        target: run.branch,
        outcome: "ok",
      });
    }
    return null;
  },
});

/** One audit row per sweep: what it removed, by id and name only. */
export const recordSweep = mutation({
  args: {
    sandboxes: v.array(v.string()),
    secrets: v.array(v.string()),
    branches: v.number(),
    errors: v.number(),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    await writeAudit(ctx, {
      actor: "system:sweep",
      action: "sweep.done",
      outcome: args.errors > 0 ? "error" : "ok",
      detail: {
        sandboxes: args.sandboxes.slice(0, 20).join(",").slice(0, 400),
        secrets: args.secrets.slice(0, 20).join(",").slice(0, 400),
        sandboxCount: args.sandboxes.length,
        secretCount: args.secrets.length,
        branches: args.branches,
        errors: args.errors,
      },
    });
    return null;
  },
});
