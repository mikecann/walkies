// Previews with the admin's own data (docs/chef-pipeline.md, "Preview
// data"). Off unless both the app opts in (chefCloud's previewData option,
// with its two hooks) and an app admin turns it on here ("admin-copy",
// default "demo"). Then, for each preview, the host runs the app's
// exportForPreviewFunction on the live deployment for that admin's own
// rows only, stores the export here (size-capped, audited by hash, never
// its content), hands the preview's previewSeedFunction a one-time URL to
// it, signs the admin's link in as the copied user, and deletes the export
// once the preview is made.
//
// mode: admins (null for everyone else). setMode: an app admin, audited.
// settingsForHost, storeExport, exportUrl, dropExport: the host only.
import { v } from "convex/values";
import { action, internalMutation, mutation, query } from "./_generated/server.js";
import type { Id } from "./_generated/dataModel.js";
import { internal } from "./_generated/api.js";
import { hasAppAdminUser, isAdminUser, requireAdminUser } from "./access.js";
import { userActor, writeAudit } from "./chefAudit.js";
import { runActor } from "./chefRuns.js";

/** The export's cap: JSON bytes. */
export const PREVIEW_EXPORT_MAX_BYTES = 8 * 1024 * 1024;
const vMode = v.union(v.literal("demo"), v.literal("admin-copy"));

async function settingsRow(ctx: { db: any }) {
  return await ctx.db
    .query("settings")
    .withIndex("by_key", (q: any) => q.eq("key", "singleton"))
    .unique();
}

/** The mode and whose data. Admins only; null for everyone else. */
export const mode = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())) },
  returns: v.union(v.null(), v.object({ mode: vMode, userId: v.union(v.string(), v.null()) })),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    const row = await settingsRow(ctx);
    return { mode: row?.previewData ?? "demo", userId: row?.previewDataUserId ?? null };
  },
});

/**
 * Turn "admin-copy" on (copying the caller's own rows, never anyone
 * else's) or back to "demo". An app admin, never the CLI's operator.
 */
export const setMode = mutation({
  args: { adminUserId: v.string(), mode: vMode },
  returns: v.object({ mode: vMode }),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    if (args.adminUserId.startsWith("operator:") || !(await hasAppAdminUser(ctx))) {
      throw new Error("Preview data is an app admin's choice: run chefSetAdmin first.");
    }
    const row = await settingsRow(ctx);
    const patch =
      args.mode === "admin-copy"
        ? { previewData: "admin-copy" as const, previewDataUserId: args.adminUserId }
        : { previewData: "demo" as const, previewDataUserId: undefined };
    if (row) await ctx.db.patch("settings", row._id, patch);
    else await ctx.db.insert("settings", { key: "singleton", communityBoardVisible: true, runMode: "local", ...patch });
    await writeAudit(ctx, { actor: userActor(args.adminUserId), action: "previewData.mode", outcome: "ok", detail: { mode: args.mode } });
    return { mode: args.mode };
  },
});

/** What the host's preview step needs: the mode and whose data. Host-only. */
export const settingsForHost = query({
  args: {},
  returns: v.object({ mode: vMode, userId: v.union(v.string(), v.null()) }),
  handler: async (ctx) => {
    const row = await settingsRow(ctx);
    const on = row?.previewData === "admin-copy" && typeof row.previewDataUserId === "string";
    return { mode: on ? ("admin-copy" as const) : ("demo" as const), userId: on ? row.previewDataUserId : null };
  },
});

async function sha256Hex(bytes: ArrayBuffer): Promise<string> {
  const d = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes));
  return Array.from(d, (b) => b.toString(16).padStart(2, "0")).join("");
}

/**
 * The admin's export for one run's preview, into this component's storage:
 * size-capped, checked against its sha256, for exactly the admin the
 * setting names. Once per run. Audited by size and hash, never content.
 * Host-only.
 */
export const storeExport = action({
  args: { runId: v.id("chefRuns"), userId: v.string(), bytes: v.bytes(), sha256: v.string() },
  returns: v.object({ stored: v.boolean(), reason: v.optional(v.string()) }),
  handler: async (ctx, args): Promise<{ stored: boolean; reason?: string }> => {
    if (args.bytes.byteLength === 0 || args.bytes.byteLength > PREVIEW_EXPORT_MAX_BYTES) return { stored: false, reason: "size" };
    if ((await sha256Hex(args.bytes)) !== args.sha256) return { stored: false, reason: "sha256" };
    const storageId: Id<"_storage"> = await ctx.storage.store(new Blob([args.bytes], { type: "application/json" }));
    const r: { ok: boolean; reason?: string } = await ctx.runMutation(internal.chefPreviewData.recordExport, {
      runId: args.runId,
      userId: args.userId,
      storageId,
      sha256: args.sha256,
      bytes: args.bytes.byteLength,
    });
    if (!r.ok) await ctx.storage.delete(storageId);
    return r.ok ? { stored: true } : { stored: false, ...(r.reason ? { reason: r.reason } : {}) };
  },
});

export const recordExport = internalMutation({
  args: { runId: v.id("chefRuns"), userId: v.string(), storageId: v.id("_storage"), sha256: v.string(), bytes: v.number() },
  returns: v.object({ ok: v.boolean(), reason: v.optional(v.string()) }),
  handler: async (ctx, args) => {
    const row = await settingsRow(ctx);
    // Only ever with the setting on, and only for the admin it names.
    if (row?.previewData !== "admin-copy" || row.previewDataUserId !== args.userId) return { ok: false, reason: "admin-copy is off" };
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run || run.status !== "active") return { ok: false, reason: "the run is not active" };
    if (run.previewExport) return { ok: false, reason: "already exported" };
    await ctx.db.patch("chefRuns", run._id, { previewExport: { storageId: args.storageId, sha256: args.sha256, bytes: args.bytes, userId: args.userId } });
    await writeAudit(ctx, {
      actor: runActor(run._id),
      action: "previewData.exported",
      runId: run._id,
      target: userActor(args.userId),
      outcome: "ok",
      detail: { bytes: args.bytes, sha256: args.sha256 },
    });
    return { ok: true };
  },
});

/** The export's one-time URL for the preview's seed function, with its hash. Host-only. */
export const exportUrl = query({
  args: { runId: v.id("chefRuns") },
  returns: v.union(v.null(), v.object({ url: v.string(), sha256: v.string(), bytes: v.number(), userId: v.string() })),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    const e = run?.previewExport;
    if (!e) return null;
    const url = await ctx.storage.getUrl(e.storageId);
    return url ? { url, sha256: e.sha256, bytes: e.bytes, userId: e.userId } : null;
  },
});

/** The preview is made (or failed): the export goes, and whether the preview got it is recorded. Host-only. */
export const dropExport = mutation({
  args: { runId: v.id("chefRuns"), seeded: v.optional(v.boolean()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) return null;
    if (run.previewExport) await ctx.storage.delete(run.previewExport.storageId).catch(() => {});
    await ctx.db.patch("chefRuns", run._id, {
      previewExport: undefined,
      ...(args.seeded !== undefined ? { previewAdminCopy: args.seeded } : {}),
    });
    if (args.seeded !== undefined) {
      await writeAudit(ctx, { actor: runActor(run._id), action: "previewData.seeded", runId: run._id, outcome: args.seeded ? "ok" : "error", detail: { seeded: args.seeded } });
    }
    return null;
  },
});
