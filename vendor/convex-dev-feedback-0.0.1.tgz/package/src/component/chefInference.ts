// The inference proxy's bookkeeping (docs/chef-pipeline.md, "Inference: a
// per-run proxy now"). The HTTP action in src/client/chefHttp.ts calls `begin`
// before it forwards anything and `end` when the response is over, in a
// finally. Both are mutations, so every limit is checked and counted in one
// transaction: two requests racing for the last in-flight slot conflict on
// the run row and Convex retries one, which then sees the slot taken. No lock.
//
// Limits per run: phase `agent` only, the model allowlist, a max_tokens
// ceiling, at most 2 in flight, a request count, and a spend ceiling counted
// from the cost the gateway reports on each response.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { MutationCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import { chefInferenceFields } from "./schema.js";
import { authorize, credActor } from "./chefAgent.js";
import { writeAudit } from "./chefAudit.js";
import { readChefSettings } from "./chefSettings.js";
import { isAdminUser } from "./access.js";
import {
  AI_MODELS,
  MAX_AI_IN_FLIGHT,
  estimateCostUsd,
  worstCaseCostUsd,
} from "../chef/ai.js";

/**
 * A pending request older than this had its action die without running its
 * finally (HTTP actions can't run this long). It stops holding a slot.
 */
export const STALE_PENDING_MS = 15 * 60_000;

const vRefusal = v.object({
  ok: v.literal(false),
  status: v.number(),
  error: v.string(),
  retryAfter: v.optional(v.number()),
});

type Refused = { ok: false; status: number; error: string; retryAfter?: number };

const MODELS: readonly string[] = AI_MODELS;

/** A request older than STALE_PENDING_MS is marked abandoned, charged worst case, and frees its slot. */
async function reapStale(ctx: MutationCtx, run: Doc<"chefRuns">, now: number) {
  const pending = await ctx.db
    .query("chefInference")
    .withIndex("by_runId_and_status", (q) => q.eq("runId", run._id).eq("status", "pending"))
    .take(MAX_AI_IN_FLIGHT + 8);
  let freed = 0;
  let charged = 0;
  for (const r of pending) {
    if (now - r.startedAt < STALE_PENDING_MS) continue;
    const cost = worstCaseCostUsd(r.model, r.requestBytes ?? 0, r.maxTokens ?? 0);
    await ctx.db.patch("chefInference", r._id, {
      status: "abandoned",
      costUsd: cost,
      costSource: "worstCase",
      latencyMs: now - r.startedAt,
    });
    freed++;
    charged += cost;
  }
  if (freed === 0) return run;
  const patch = {
    aiInFlight: Math.max(0, (run.aiInFlight ?? 0) - freed),
    spendUsd: (run.spendUsd ?? 0) + charged,
  };
  await ctx.db.patch("chefRuns", run._id, patch);
  await writeAudit(ctx, {
    actor: "system:inference",
    action: "inference.abandoned",
    runId: run._id,
    outcome: "error",
    reason: "pending past its time; the action never finished it",
    detail: { requests: freed, chargedUsd: charged },
  });
  return { ...run, ...patch };
}

/**
 * Admit one request or refuse it. Admitting takes an in-flight slot and
 * counts the request; `end` gives the slot back.
 */
export const begin = mutation({
  args: {
    token: v.string(),
    model: v.string(),
    maxTokens: v.union(v.number(), v.null()),
    stream: v.boolean(),
    requestBytes: v.number(),
  },
  returns: v.union(vRefusal, v.object({ ok: v.literal(true), requestId: v.id("chefInference") })),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, { route: "ai", scope: "ai.proxy", phases: ["agent"] });
    if (!a.ok) {
      // 409 would make the Anthropic SDK retry; a wrong phase isn't going to change.
      return { ok: false as const, status: a.status === 409 ? 403 : a.status, error: a.error };
    }
    const now = Date.now();
    const run = await reapStale(ctx, a.run, now);
    const settings = await readChefSettings(ctx);
    // Only an allowlisted model id is stored. Anything else came from the
    // sandbox and could carry anything, a credential included, so neither
    // the row, the audit log nor the error repeats it.
    const allowed = MODELS.includes(args.model);
    const model = allowed ? args.model : "(not allowed)";
    const maxTokens = Number.isFinite(args.maxTokens) ? args.maxTokens : null;

    const refuse = async (r: Refused, action = "inference.refused"): Promise<Refused> => {
      await ctx.db.insert("chefInference", {
        runId: run._id,
        model,
        ...(maxTokens !== null ? { maxTokens } : {}),
        stream: args.stream,
        status: "refused",
        httpStatus: r.status,
        reason: r.error,
        requestBytes: args.requestBytes,
        startedAt: now,
        latencyMs: 0,
      });
      await writeAudit(ctx, {
        actor: credActor(a.token.prefix),
        action,
        runId: run._id,
        outcome: "refused",
        reason: r.error,
        detail: { model, maxTokens, spendUsd: run.spendUsd ?? 0 },
      });
      return r;
    };

    if (!allowed) {
      return await refuse({
        ok: false,
        status: 400,
        error: `Model not allowed; use one of ${MODELS.join(", ")}`,
      });
    }
    if (maxTokens === null || !Number.isInteger(maxTokens) || maxTokens < 1) {
      return await refuse({ ok: false, status: 400, error: "max_tokens must be a positive integer" });
    }
    if (maxTokens > settings.aiMaxTokens) {
      return await refuse({
        ok: false,
        status: 400,
        error: `max_tokens is over this run's ceiling of ${settings.aiMaxTokens}`,
      });
    }
    // The ceiling covers every attempt of one approval: Chef's own retries
    // of a transient failure start with the earlier attempts' spend.
    if ((run.spendUsd ?? 0) + (run.priorSpendUsd ?? 0) >= settings.spendCeilingUsd) {
      return await refuse(
        {
          ok: false,
          status: 429,
          error: `This run reached its inference spend ceiling of $${settings.spendCeilingUsd}`,
        },
        "inference.ceiling",
      );
    }
    if ((run.aiRequests ?? 0) >= settings.aiMaxRequests) {
      return await refuse(
        { ok: false, status: 429, error: `This run reached its limit of ${settings.aiMaxRequests} requests` },
        "inference.requestCap",
      );
    }
    if ((run.aiInFlight ?? 0) >= MAX_AI_IN_FLIGHT) {
      return await refuse({
        ok: false,
        status: 429,
        error: `At most ${MAX_AI_IN_FLIGHT} requests in flight per run`,
        retryAfter: 1,
      });
    }

    const requestId = await ctx.db.insert("chefInference", {
      runId: run._id,
      model,
      maxTokens,
      stream: args.stream,
      status: "pending",
      requestBytes: args.requestBytes,
      startedAt: now,
    });
    await ctx.db.patch("chefRuns", run._id, {
      aiInFlight: (run.aiInFlight ?? 0) + 1,
      aiRequests: (run.aiRequests ?? 0) + 1,
    });
    return { ok: true as const, requestId };
  },
});

const vUsage = v.object({
  inputTokens: v.optional(v.number()),
  outputTokens: v.optional(v.number()),
  cacheCreationInputTokens: v.optional(v.number()),
  cacheReadInputTokens: v.optional(v.number()),
  costUsd: v.optional(v.number()),
});

function clean(x: number | undefined): number | undefined {
  return typeof x === "number" && Number.isFinite(x) && x >= 0 ? x : undefined;
}

/**
 * Finish a request: record usage and cost, give back the in-flight slot, add
 * the cost to the run's spend. Repeating it for a finished request is a no-op,
 * so the slot is never given back twice.
 */
export const end = mutation({
  args: {
    requestId: v.id("chefInference"),
    outcome: v.union(v.literal("ok"), v.literal("error"), v.literal("cancelled")),
    httpStatus: v.number(),
    usage: vUsage,
    firstByteMs: v.optional(v.number()),
    latencyMs: v.number(),
    // Why the proxy ended it as an error, when it was the proxy's doing.
    reason: v.optional(v.string()),
  },
  returns: v.object({ recorded: v.boolean(), costUsd: v.number() }),
  handler: async (ctx, args) => {
    const row = await ctx.db.get("chefInference", args.requestId);
    if (!row || row.status !== "pending") return { recorded: false, costUsd: 0 };
    const u = {
      inputTokens: clean(args.usage.inputTokens),
      outputTokens: clean(args.usage.outputTokens),
      cacheCreationInputTokens: clean(args.usage.cacheCreationInputTokens),
      cacheReadInputTokens: clean(args.usage.cacheReadInputTokens),
      costUsd: clean(args.usage.costUsd),
    };
    const sawTokens =
      u.inputTokens !== undefined ||
      u.outputTokens !== undefined ||
      u.cacheCreationInputTokens !== undefined ||
      u.cacheReadInputTokens !== undefined;
    let costUsd = 0;
    let costSource: "gateway" | "estimate" | "worstCase" | undefined;
    if (u.costUsd !== undefined) {
      costUsd = u.costUsd;
      costSource = "gateway";
    } else if (sawTokens) {
      costUsd = estimateCostUsd(row.model, u);
      costSource = "estimate";
    } else if (args.httpStatus >= 200 && args.httpStatus < 300) {
      // A success with no usage at all: the stream broke or was cut off. The
      // upstream may still have spent; count the most it could have.
      costUsd = worstCaseCostUsd(row.model, row.requestBytes ?? 0, row.maxTokens ?? 0);
      costSource = "worstCase";
    }
    const status = args.outcome;
    await ctx.db.patch("chefInference", row._id, {
      status,
      httpStatus: args.httpStatus,
      ...(u.inputTokens !== undefined ? { inputTokens: u.inputTokens } : {}),
      ...(u.outputTokens !== undefined ? { outputTokens: u.outputTokens } : {}),
      ...(u.cacheCreationInputTokens !== undefined
        ? { cacheCreationInputTokens: u.cacheCreationInputTokens }
        : {}),
      ...(u.cacheReadInputTokens !== undefined ? { cacheReadInputTokens: u.cacheReadInputTokens } : {}),
      ...(costSource ? { costUsd, costSource } : {}),
      ...(args.firstByteMs !== undefined ? { firstByteMs: Math.max(0, args.firstByteMs) } : {}),
      latencyMs: Math.max(0, args.latencyMs),
      ...(args.reason !== undefined ? { reason: args.reason.slice(0, 500) } : {}),
    });
    if (args.reason !== undefined) {
      await writeAudit(ctx, {
        actor: "system:inference",
        action: "inference.error",
        runId: row.runId,
        outcome: "error",
        reason: args.reason,
        detail: { httpStatus: args.httpStatus, model: row.model },
      });
    }
    const run = await ctx.db.get("chefRuns", row.runId);
    if (run) {
      const before = (run.spendUsd ?? 0) + (run.priorSpendUsd ?? 0);
      const after = before + costUsd;
      await ctx.db.patch("chefRuns", run._id, {
        aiInFlight: Math.max(0, (run.aiInFlight ?? 0) - 1),
        spendUsd: (run.spendUsd ?? 0) + costUsd,
        // Tokens for the cost trend (chefRuns.costs).
        aiInputTokens:
          (run.aiInputTokens ?? 0) + (u.inputTokens ?? 0) + (u.cacheCreationInputTokens ?? 0) + (u.cacheReadInputTokens ?? 0),
        aiOutputTokens: (run.aiOutputTokens ?? 0) + (u.outputTokens ?? 0),
      });
      const { spendCeilingUsd } = await readChefSettings(ctx);
      if (before < spendCeilingUsd && after >= spendCeilingUsd) {
        await writeAudit(ctx, {
          actor: "system:inference",
          action: "inference.ceilingReached",
          runId: run._id,
          outcome: "ok",
          reason: "the run's inference spend reached its ceiling; further requests get 429",
          detail: { spendUsd: after, ceilingUsd: spendCeilingUsd },
        });
      }
    }
    return { recorded: true, costUsd };
  },
});

/** One run's inference requests, newest first. Admins only; [] for everyone else. */
export const listForRun = query({
  args: {
    viewer: v.optional(v.union(v.string(), v.null())),
    runId: v.id("chefRuns"),
    limit: v.optional(v.number()),
  },
  returns: v.array(
    v.object({ _id: v.id("chefInference"), _creationTime: v.number(), ...chefInferenceFields }),
  ),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return [];
    const limit = Math.min(500, Math.max(1, Math.floor(args.limit ?? 100) || 100));
    return await ctx.db
      .query("chefInference")
      .withIndex("by_runId", (q) => q.eq("runId", args.runId as Id<"chefRuns">))
      .order("desc")
      .take(limit);
  },
});
