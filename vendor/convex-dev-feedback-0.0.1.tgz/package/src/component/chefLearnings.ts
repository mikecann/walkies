// What Chef learned about this app, so the next build is cheaper
// (docs/chef-pipeline.md, "Learnings"; src/chef/learnings.ts).
//
// POST /chef-agent/learnings: once per run, the runner reports what it saw
// (how the app installs, its gates and their baseline, how the frontend
// builds, the files the run changed, each phase's time) and the agent's own
// notes about the repo, which it read after the agent was dead. Run
// credential, `run.report`, the run's phase checked, one audit row, every
// string scrubbed again with the presented credential.
//
// What is kept is one row per key, newest wins; a failed run adds its
// failure's reason (chefRuns.finishRun). GET /chef-agent/run hands the next
// runner `forRun`: the brief for the agent (src/chef/learnings.ts
// buildBrief, at most ~2,000 tokens) and the cached baselines. Only
// runner-reported rows carry a baseline; the agent's notes are text, never
// read as config. Admins see everything with `list` and delete with `forget`.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { MutationCtx, QueryCtx } from "./_generated/server.js";
import type { Doc } from "./_generated/dataModel.js";
import { auditOk, authorize, refuseAuthorized, scrubFor, type RunPhase } from "./chefAgent.js";
import { requireAdminUser, isAdminUser } from "./access.js";
import { userActor, writeAudit } from "./chefAudit.js";
import { sha256Hex } from "./chefShared.js";
import {
  LEARNING_LIMITS,
  NOTE_TOPICS,
  TIMING_KEYS,
  buildBrief,
  expired,
  repoNoteEntry,
  type RepoNote,
} from "../chef/learnings.js";
import type { FailureInfo } from "../chef/failures.js";

// chefAgent.ts's vRefusal, defined here: chefRuns imports this module, and
// chefAgent imports chefRuns, so its validators aren't there yet at load time.
const vRefusal = v.object({ ok: v.literal(false), status: v.number(), error: v.string() });

const LEARNING_PHASES: RunPhase[] = [
  "launched", "ready", "cloning", "cloned", "agent", "gates", "guards", "committed", "pushing", "pushed", "previewing",
];
const MAX_ROWS = 200;

type Source = Doc<"chefLearnings">["source"];
type Row = { key: string; source: Source; topic: string; text: string; items?: string[]; baseline?: Doc<"chefLearnings">["baseline"] };

const oneLine = (s: string, max: number) => s.replace(/\s+/g, " ").trim().slice(0, max);

/** Insert or refresh one row by key: newest text wins, the count goes up. */
async function upsert(ctx: MutationCtx, row: Row, seq: number): Promise<void> {
  const now = Date.now();
  const existing = await ctx.db
    .query("chefLearnings")
    .withIndex("by_key", (q) => q.eq("key", row.key))
    .unique();
  if (existing) {
    await ctx.db.patch("chefLearnings", existing._id, {
      text: row.text,
      topic: row.topic,
      ...(row.items ? { items: row.items } : {}),
      ...(row.baseline ? { baseline: row.baseline } : {}),
      lastRunSeq: Math.max(existing.lastRunSeq, seq),
      seenCount: existing.seenCount + 1,
      updatedAt: now,
    });
  } else {
    await ctx.db.insert("chefLearnings", {
      ...row,
      firstRunSeq: seq,
      lastRunSeq: seq,
      seenCount: 1,
      createdAt: now,
      updatedAt: now,
    });
  }
}

/** A failed run's reason and fix, as a learning the next agent reads. Called by chefRuns.finishRun. */
export async function recordFailureLearning(ctx: MutationCtx, seq: number, f: FailureInfo): Promise<void> {
  // Platform hiccups, and the Convex team being out of room, say nothing about the app.
  if (f.kind === "transient" || f.kind === "environmental") return;
  await upsert(ctx, { key: `failure:${f.code}`, source: "failure", topic: f.code, text: oneLine(`${f.reason} ${f.action}`, 400) }, seq);
}

/** Drops rows past their TTL, a bounded number per call. */
async function expire(ctx: MutationCtx, seq: number): Promise<number> {
  let n = 0;
  for (const source of ["agent", "runner", "failure"] as const) {
    const old = await ctx.db
      .query("chefLearnings")
      .withIndex("by_source_and_lastRunSeq", (q) =>
        q.eq("source", source).lt("lastRunSeq", seq - LEARNING_LIMITS.ttlRuns[source]),
      )
      .take(25);
    for (const r of old) {
      await ctx.db.delete("chefLearnings", r._id);
      n++;
    }
  }
  return n;
}

const vOutcome = v.union(v.literal("pass"), v.literal("fail"));
const vObserved = v.object({
  install: v.optional(v.string()),
  scripts: v.optional(v.array(v.string())),
  gates: v.optional(
    v.array(
      v.object({
        command: v.string(),
        baseline: v.union(vOutcome, v.literal("none")),
        result: v.optional(vOutcome),
      }),
    ),
  ),
  baseline: v.optional(
    v.object({
      tree: v.string(),
      lockfileHash: v.optional(v.string()),
      gates: v.array(v.object({ command: v.string(), outcome: vOutcome })),
    }),
  ),
  frontend: v.optional(v.string()),
  filesChanged: v.optional(v.array(v.string())),
  fixRounds: v.optional(v.number()),
  // Whether the agent used the Convex plugin: one line of counts.
  pluginUsage: v.optional(v.string()),
});

const HEX = /^[0-9a-f]{40,64}$/;

/**
 * POST /chef-agent/learnings. Stored once per run: a repeat is a no-op.
 * Every string is scrubbed with the presented credential and cut; the
 * agent's notes go through repoNoteEntry (a fixed set of topics, one line
 * each) and stay plain text.
 */
export const report = mutation({
  args: {
    token: v.string(),
    observed: vObserved,
    timings: v.record(v.string(), v.number()),
    notes: v.array(v.object({ topic: v.string(), note: v.string() })),
    // What the agent tried: its summary and the diff stat, kept on the run even when it fails.
    attempt: v.optional(v.object({ summary: v.string(), diffStat: v.string() })),
  },
  returns: v.union(vRefusal, v.object({ ok: v.literal(true), applied: v.boolean(), notes: v.number() })),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, { route: "learnings", scope: "run.report", phases: LEARNING_PHASES });
    if (!a.ok) return a;
    const run = a.run;
    if (run.learningsAt !== undefined) {
      await auditOk(ctx, a, "learnings", { applied: false });
      return { ok: true as const, applied: false, notes: 0 };
    }
    const clean = scrubFor(args.token);
    const o = args.observed;
    const big =
      (o.scripts?.length ?? 0) > 100 ||
      (o.gates?.length ?? 0) > 20 ||
      (o.baseline?.gates.length ?? 0) > 20 ||
      (o.filesChanged?.length ?? 0) > 200 ||
      args.notes.length > 50 ||
      Object.keys(args.timings).length > 20;
    if (big) return await refuseAuthorized(ctx, a, "learnings", 400, "Too much in one report");
    if (o.baseline && (!HEX.test(o.baseline.tree) || (o.baseline.lockfileHash !== undefined && !HEX.test(o.baseline.lockfileHash)))) {
      return await refuseAuthorized(ctx, a, "learnings", 400, "baseline tree and lockfileHash must be hex");
    }
    const seq = run.seq;
    const cut = (s: string, n = 300) => oneLine(clean(s), n);

    // The runner's facts.
    if (o.install) await upsert(ctx, { key: "install", source: "runner", topic: "install", text: `Installs with ${cut(o.install, 200)}.` }, seq);
    if (o.pluginUsage) {
      await upsert(ctx, { key: "pluginUsage", source: "runner", topic: "tools", text: `The last build's agent and the Convex plugin: ${cut(o.pluginUsage, 300)}.` }, seq);
    }
    if (o.scripts && o.scripts.length > 0) {
      await upsert(ctx, { key: "scripts", source: "runner", topic: "scripts", text: `package.json scripts: ${cut(o.scripts.join(", "), 400)}.` }, seq);
    }
    if (o.gates && o.gates.length > 0) {
      const text = o.gates
        .map((g) => {
          const base = g.baseline === "fail" ? "fails on the base already (doesn't block)" : g.baseline === "pass" ? "passes on the base" : "no baseline";
          return `\`${cut(g.command, 120)}\` ${base}`;
        })
        .join("; ");
      await upsert(ctx, { key: "gates", source: "runner", topic: "gates", text: `The checks Chef runs: ${text}.` }, seq);
    }
    if (o.frontend) await upsert(ctx, { key: "frontend", source: "runner", topic: "frontend", text: `The frontend builds with ${cut(o.frontend, 200)}.` }, seq);
    if (o.filesChanged && o.filesChanged.length > 0) {
      const prev = await ctx.db
        .query("chefLearnings")
        .withIndex("by_key", (q) => q.eq("key", "files"))
        .unique();
      const items = [...new Set([...o.filesChanged.map((f) => cut(f, 200)), ...(prev?.items ?? [])])].slice(0, LEARNING_LIMITS.files);
      await upsert(ctx, { key: "files", source: "runner", topic: "files", items, text: `Files recent builds changed: ${items.join(", ")}.` }, seq);
    }
    if (o.baseline && o.baseline.gates.length > 0) {
      const b = {
        tree: o.baseline.tree,
        ...(o.baseline.lockfileHash ? { lockfileHash: o.baseline.lockfileHash } : {}),
        gates: o.baseline.gates.map((g) => ({ command: clean(g.command).slice(0, 500), outcome: g.outcome })),
      };
      await upsert(
        ctx,
        {
          key: `baseline:${b.tree}:${b.lockfileHash ?? "none"}`,
          source: "runner",
          topic: "baseline",
          text: `Baseline on tree ${b.tree.slice(0, 12)}: ${b.gates.map((g) => `${g.command} ${g.outcome}`).join(", ")}`.slice(0, 600),
          baseline: b,
        },
        seq,
      );
      // Only the newest few.
      const all = await ctx.db
        .query("chefLearnings")
        .withIndex("by_source_and_lastRunSeq", (q) => q.eq("source", "runner"))
        .order("desc")
        .take(MAX_ROWS);
      const baselines = all.filter((r) => r.key.startsWith("baseline:"));
      for (const r of baselines.slice(LEARNING_LIMITS.baselines)) await ctx.db.delete("chefLearnings", r._id);
    }

    // The agent's notes: newest run wins a topic.
    const notes: RepoNote[] = [];
    for (const raw of args.notes) {
      const e = repoNoteEntry(raw, clean);
      if (e && notes.length < LEARNING_LIMITS.notesPerRun) notes.push(e);
    }
    for (const topic of NOTE_TOPICS) {
      const mine = notes.filter((n) => n.topic === topic).slice(0, LEARNING_LIMITS.notesPerTopic);
      if (mine.length === 0) continue;
      const old = await ctx.db
        .query("chefLearnings")
        .withIndex("by_source_and_lastRunSeq", (q) => q.eq("source", "agent"))
        .take(MAX_ROWS);
      for (const r of old) if (r.topic === topic) await ctx.db.delete("chefLearnings", r._id);
      for (const n of mine) {
        const h = (await sha256Hex(`${topic}\n${n.note}`)).slice(0, 16);
        await upsert(ctx, { key: `agent:${topic}:${h}`, source: "agent", topic, text: n.note }, seq);
      }
    }

    const phaseMs: Record<string, number> = {};
    for (const k of TIMING_KEYS) {
      const t = args.timings[k];
      if (typeof t === "number" && Number.isFinite(t) && t >= 0 && t < 24 * 3600_000) phaseMs[k] = Math.round(t);
    }
    await ctx.db.patch("chefRuns", run._id, {
      learningsAt: Date.now(),
      phaseMs,
      ...(args.attempt
        ? {
            summary: clean(args.attempt.summary.slice(0, 16_000)).slice(0, 4000),
            diffStat: clean(args.attempt.diffStat.slice(-16_000)).slice(-4000),
          }
        : {}),
    });
    const expiredRows = await expire(ctx, seq);
    await auditOk(ctx, a, "learnings", { applied: true, notes: notes.length, expired: expiredRows });
    return { ok: true as const, applied: true, notes: notes.length };
  },
});

async function rowsFor(ctx: QueryCtx): Promise<Doc<"chefLearnings">[]> {
  return await ctx.db.query("chefLearnings").withIndex("by_key").take(MAX_ROWS);
}

async function currentSeq(ctx: QueryCtx): Promise<number> {
  const last = await ctx.db.query("chefRuns").order("desc").first();
  return last?.seq ?? 0;
}

/**
 * For GET /chef-agent/run: the brief for the agent and the cached
 * baselines, newest first. The baselines come only from runner reports.
 */
export const forRun = query({
  args: {},
  returns: v.object({
    brief: v.string(),
    baselines: v.array(
      v.object({
        tree: v.string(),
        lockfileHash: v.optional(v.string()),
        gates: v.array(v.object({ command: v.string(), outcome: vOutcome })),
      }),
    ),
  }),
  handler: async (ctx) => {
    const rows = await rowsFor(ctx);
    const seq = await currentSeq(ctx);
    const brief = buildBrief(
      rows.map((r) => ({ key: r.key, source: r.source, topic: r.topic, text: r.text, lastRunSeq: r.lastRunSeq, seenCount: r.seenCount })),
      seq,
    );
    const baselines = rows
      .filter((r) => r.source === "runner" && r.baseline && !expired(r, seq))
      .sort((a, b) => b.lastRunSeq - a.lastRunSeq)
      .slice(0, LEARNING_LIMITS.baselines)
      .map((r) => r.baseline!);
    return { brief, baselines };
  },
});

const vLearning = v.object({
  id: v.id("chefLearnings"),
  source: v.union(v.literal("runner"), v.literal("agent"), v.literal("failure")),
  topic: v.string(),
  text: v.string(),
  firstRunSeq: v.number(),
  lastRunSeq: v.number(),
  seenCount: v.number(),
  expired: v.boolean(),
  updatedAt: v.number(),
});

/** Everything Chef knows about the app, newest first, and the brief the next agent gets. Admins only. */
export const list = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())) },
  returns: v.object({ entries: v.array(vLearning), brief: v.string() }),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return { entries: [], brief: "" };
    const rows = await rowsFor(ctx);
    const seq = await currentSeq(ctx);
    const entries = rows
      .sort((a, b) => b.lastRunSeq - a.lastRunSeq || b.updatedAt - a.updatedAt)
      .map((r) => ({
        id: r._id,
        source: r.source,
        topic: r.topic,
        text: r.text,
        firstRunSeq: r.firstRunSeq,
        lastRunSeq: r.lastRunSeq,
        seenCount: r.seenCount,
        expired: expired(r, seq),
        updatedAt: r.updatedAt,
      }));
    const brief = buildBrief(
      rows.map((r) => ({ key: r.key, source: r.source, topic: r.topic, text: r.text, lastRunSeq: r.lastRunSeq, seenCount: r.seenCount })),
      seq,
    );
    return { entries, brief };
  },
});

/** An admin deletes one entry (a wrong note, a stale fact, a cached baseline). Audited. */
export const forget = mutation({
  args: { id: v.string(), adminUserId: v.string() },
  returns: v.boolean(),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    const id = ctx.db.normalizeId("chefLearnings", args.id);
    const row = id ? await ctx.db.get("chefLearnings", id) : null;
    if (!row) return false;
    await ctx.db.delete("chefLearnings", row._id);
    await writeAudit(ctx, {
      actor: userActor(args.adminUserId),
      action: "learning.forgotten",
      target: row.key.slice(0, 200),
      outcome: "ok",
      detail: { source: row.source, topic: row.topic },
    });
    return true;
  },
});
