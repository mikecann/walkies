// Repair commits (docs/chef-pipeline.md, "Repair commits"; src/chef/recovery.ts,
// appFixable): when a run fails on a repo problem Chef can fix mechanically
// (an out-of-date lockfile, tracked symlinks or env files), the host makes
// the fix in a repair sandbox with no agent (runner/chef-repair.mjs) on a
// chef-repair/* branch, and the panel offers it: "Chef can fix this: ...
// [Apply]". Apply is an admin's decision, like Ship it: it schedules the
// host's applier, which moves main to the repair (a compare-and-swap from
// the main it was made on), and then the failed request builds again.
// Never applied on its own.
//
// Who can do what: forRun (admins; null for everyone else), apply and
// decline (an app admin); begin, offer, fail, info, applied, setApplier
// (the host; component functions are never public).
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { MutationCtx, QueryCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import type { FunctionHandle } from "convex/server";
import { hasAppAdminUser, isAdminUser, requireAdminUser } from "./access.js";
import { operatorActor } from "./chefReleases.js";
import { userActor, writeAudit } from "./chefAudit.js";
import { retryRequest } from "./chefSnapshots.js";
import { runItemIds } from "./chefRuns.js";

const vKind = v.union(v.literal("lockfile"), v.literal("symlinks"), v.literal("envFiles"));
const vStatus = v.union(
  v.literal("making"),
  v.literal("offered"),
  v.literal("applying"),
  v.literal("applied"),
  v.literal("failed"),
  v.literal("declined"),
);
const vFile = v.object({ path: v.string(), how: v.string() });
type RepairKind = "lockfile" | "symlinks" | "envFiles";
export const vRepair = v.object({
  repairId: v.id("chefRepairs"),
  runId: v.id("chefRuns"),
  itemId: v.id("items"),
  kind: vKind,
  status: vStatus,
  summary: v.union(v.string(), v.null()),
  files: v.array(vFile),
  branch: v.union(v.string(), v.null()),
  sha: v.union(v.string(), v.null()),
  baseSha: v.union(v.string(), v.null()),
  error: v.union(v.string(), v.null()),
  updatedAt: v.number(),
});

const SHA40 = /^[0-9a-f]{40}$/;
const BRANCH = /^chef-repair\/[a-z0-9][a-z0-9-]{0,62}$/;

function view(r: Doc<"chefRepairs">) {
  return {
    repairId: r._id,
    runId: r.runId,
    itemId: r.itemId,
    kind: r.kind,
    status: r.status,
    summary: r.summary ?? null,
    files: r.files ?? [],
    branch: r.branch ?? null,
    sha: r.sha ?? null,
    baseSha: r.baseSha ?? null,
    error: r.error ?? null,
    updatedAt: r.updatedAt,
  };
}

async function byRun(ctx: QueryCtx, runId: Id<"chefRuns">) {
  return await ctx.db
    .query("chefRepairs")
    .withIndex("by_runId", (q) => q.eq("runId", runId))
    .first();
}

async function mustGet(ctx: QueryCtx, id: Id<"chefRepairs">) {
  const r = await ctx.db.get("chefRepairs", id);
  if (!r) throw new Error("Repair not found");
  return r;
}

async function state(ctx: QueryCtx) {
  return await ctx.db
    .query("chefState")
    .withIndex("by_key", (q) => q.eq("key", "singleton"))
    .unique();
}

/**
 * The host starts a repair for a failed run whose recovery says repair
 * (chefRuns.recovery): one per run. Returns the row, `created` when it is
 * new (the host then makes it), and null when the run wants none.
 */
export const begin = mutation({
  args: { operator: v.string(), runId: v.id("chefRuns") },
  returns: v.union(v.null(), v.object({ repairId: v.id("chefRepairs"), kind: vKind, status: vStatus, created: v.boolean() })),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    const want = run?.recovery?.action === "repair" ? run.recovery.repair : undefined;
    const kind: RepairKind | null = want === "lockfile" || want === "symlinks" || want === "envFiles" ? want : null;
    if (!run || run.status !== "failed" || kind === null) return null;
    const prior = await byRun(ctx, run._id);
    if (prior) return { repairId: prior._id, kind: prior.kind, status: prior.status, created: false };
    const now = Date.now();
    const repairId = await ctx.db.insert("chefRepairs", { runId: run._id, itemId: run.itemId, kind, status: "making", createdAt: now, updatedAt: now });
    await writeAudit(ctx, { actor: operatorActor(args.operator), action: "repair.making", runId: run._id, target: repairId, outcome: "ok", detail: { kind } });
    return { repairId, kind, status: "making" as const, created: true };
  },
});

/** The host made the repair commit: offer it. */
export const offer = mutation({
  args: {
    operator: v.string(),
    repairId: v.id("chefRepairs"),
    branch: v.string(),
    sha: v.string(),
    baseSha: v.string(),
    summary: v.string(),
    files: v.array(vFile),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const r = await mustGet(ctx, args.repairId);
    if (r.status !== "making") return null;
    if (!BRANCH.test(args.branch) || !SHA40.test(args.sha) || !SHA40.test(args.baseSha)) throw new Error("Bad repair commit");
    const summary = args.summary.replace(/[\r\n]+/g, " ").slice(0, 300);
    const files = args.files.slice(0, 50).map((f) => ({ path: f.path.slice(0, 300), how: f.how.slice(0, 200) }));
    await ctx.db.patch("chefRepairs", r._id, { status: "offered", branch: args.branch, sha: args.sha, baseSha: args.baseSha, summary, files, updatedAt: Date.now() });
    await ctx.db.insert("devLogs", { itemId: r.itemId, authorId: "chef", message: `Chef can fix this: ${summary}. An admin can apply it from the build.`, stamp: Date.now() });
    await writeAudit(ctx, {
      actor: operatorActor(args.operator),
      action: "repair.offered",
      runId: r.runId,
      target: r._id,
      outcome: "ok",
      detail: { kind: r.kind, branch: args.branch, sha: args.sha, base: args.baseSha, files: files.length },
    });
    return null;
  },
});

/** The host couldn't make, or apply, the repair: why. */
export const fail = mutation({
  args: { operator: v.string(), repairId: v.id("chefRepairs"), error: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    const r = await mustGet(ctx, args.repairId);
    if (r.status === "applied" || r.status === "declined") return null;
    const error = args.error.replace(/[\r\n]+/g, " ").slice(0, 500);
    await ctx.db.patch("chefRepairs", r._id, { status: "failed", error, updatedAt: Date.now() });
    await writeAudit(ctx, { actor: operatorActor(args.operator), action: "repair.failed", runId: r.runId, target: r._id, outcome: "error", reason: error });
    return null;
  },
});

/** One run's repair, for the panel. Admins only: null for everyone else. */
export const forRun = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())), runId: v.string() },
  returns: v.union(v.null(), vRepair),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    const runId = ctx.db.normalizeId("chefRuns", args.runId);
    const r = runId ? await byRun(ctx, runId) : null;
    return r ? view(r) : null;
  },
});

/** What the host's applier needs. Host-only. */
export const info = query({
  args: { repairId: v.id("chefRepairs") },
  returns: v.union(v.null(), vRepair),
  handler: async (ctx, args) => {
    const r = await ctx.db.get("chefRepairs", args.repairId);
    return r ? view(r) : null;
  },
});

async function decided(ctx: MutationCtx, adminUserId: string) {
  await requireAdminUser(ctx, adminUserId);
  // Like Ship it: a person's decision, never the CLI's operator identity.
  if (adminUserId.startsWith("operator:") || !(await hasAppAdminUser(ctx))) {
    throw new Error("Applying a repair needs an app admin: run chefSetAdmin (npx chef init --admin <userId>) first.");
  }
}

/**
 * "Apply": an admin approves the repair commit they were shown (by its
 * sha). The host's applier then moves main to it and the request builds
 * again. Audited; refused for anything but an offered repair.
 */
export const apply = mutation({
  args: { adminUserId: v.string(), repairId: v.id("chefRepairs"), sha: v.string() },
  returns: v.object({ applying: v.boolean(), reason: v.optional(v.string()) }),
  handler: async (ctx, args) => {
    await decided(ctx, args.adminUserId);
    const r = await mustGet(ctx, args.repairId);
    const actor = userActor(args.adminUserId);
    const refuse = async (reason: string) => {
      await writeAudit(ctx, { actor, action: "repair.approve", runId: r.runId, target: r._id, outcome: "refused", reason });
      return { applying: false, reason };
    };
    if (r.status !== "offered") return await refuse(`the repair is ${r.status}`);
    if (r.sha !== args.sha) return await refuse("that isn't the repair commit shown");
    const handle = (await state(ctx))?.repairApplierHandle;
    if (!handle) return await refuse("the app doesn't apply repairs yet: export chefRepairApply from chefCloud and run chefSetup");
    await ctx.db.patch("chefRepairs", r._id, { status: "applying", decidedBy: args.adminUserId, error: undefined, updatedAt: Date.now() });
    await ctx.scheduler.runAfter(0, handle as FunctionHandle<"action">, { repairId: r._id });
    await writeAudit(ctx, { actor, action: "repair.approve", runId: r.runId, target: r._id, outcome: "ok", detail: { kind: r.kind, sha: r.sha ?? null } });
    return { applying: true };
  },
});

/** "Not now": the repair stays on its branch, unapplied. */
export const decline = mutation({
  args: { adminUserId: v.string(), repairId: v.id("chefRepairs") },
  returns: v.null(),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    const r = await mustGet(ctx, args.repairId);
    if (r.status !== "offered" && r.status !== "failed") return null;
    await ctx.db.patch("chefRepairs", r._id, { status: "declined", decidedBy: args.adminUserId, updatedAt: Date.now() });
    await writeAudit(ctx, { actor: userActor(args.adminUserId), action: "repair.declined", runId: r.runId, target: r._id, outcome: "ok" });
    return null;
  },
});

/**
 * The host moved main to the repair: record it, and build the request
 * again as the admin who applied it ("Try again", chefSnapshots.retryRequest).
 */
export const applied = mutation({
  args: { operator: v.string(), repairId: v.id("chefRepairs"), mainSha: v.string() },
  returns: v.object({ retry: v.string() }),
  handler: async (ctx, args) => {
    const r = await mustGet(ctx, args.repairId);
    if (r.status !== "applying" || !r.decidedBy) return { retry: "skipped" };
    if (args.mainSha !== r.sha) throw new Error("main isn't at the repair commit");
    await ctx.db.patch("chefRepairs", r._id, { status: "applied", updatedAt: Date.now() });
    await writeAudit(ctx, { actor: operatorActor(args.operator), action: "repair.applied", runId: r.runId, target: r._id, outcome: "ok", detail: { mainSha: args.mainSha } });
    // A batch's failed build: every request it built goes again (each
    // approval, as Try again; the planner may group them again).
    const run = await ctx.db.get("chefRuns", r.runId);
    const itemIds = run ? runItemIds(run) : [r.itemId];
    const outcomes: string[] = [];
    for (const itemId of itemIds) {
      try {
        const again = await retryRequest(ctx, { itemId, adminUserId: r.decidedBy });
        outcomes.push(again.outcome === "started" ? `started:${again.claim}` : again.outcome);
      } catch (e) {
        outcomes.push(`refused: ${(e instanceof Error ? e.message : String(e)).slice(0, 200)}`);
      }
    }
    return { retry: outcomes.join(", ") };
  },
});

/** Register the host's repair applier (an action handle taking { repairId }). Host-only. */
export const setApplier = mutation({
  args: { handle: v.union(v.string(), v.null()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    const row = await state(ctx);
    const patch = { repairApplierHandle: args.handle ?? undefined };
    if (row) await ctx.db.patch("chefState", row._id, patch);
    else await ctx.db.insert("chefState", { key: "singleton", nextSeq: 1, ...patch });
    return null;
  },
});
