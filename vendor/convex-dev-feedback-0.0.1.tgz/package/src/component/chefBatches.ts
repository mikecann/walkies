// Batching (docs/chef-pipeline.md, "Batching"): approved requests that touch
// the same part of the app are built together, in one run.
//
// Nothing here polls. The claim (chefRuns.claimNextBuild) is where it
// starts: when it would build and more than one approved request is waiting,
// at least one of them new since the last plan, it holds the claim
// ("planning"), schedules the host's planner (chef-cloud's chefPlanBatches:
// one cheap model call through the AI gateway) and one timeout check. The
// planner answers with applyPlan, which writes the batches and makes the
// claim it stood in for; a planner that fails answers with no batches, and
// one that never answers is given up on by its timeout check. Either way,
// every request then builds alone, as before.
//
// A planned batch waits in the queue like its oldest request; until its
// build starts an admin can split a request out (`split`). When the claim
// reaches it, the whole batch becomes one run (chefRuns.claimNextBuild); its
// requests move together, and finishRun moves them on together. A failed
// batch goes through batchFailurePolicy (src/chef/batching.ts): released,
// tried once more together, or split into single builds (`requeueAfterFailure`).
import { v } from "convex/values";
import { internalMutation, mutation, query } from "./_generated/server.js";
import type { MutationCtx, QueryCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import type { FunctionHandle } from "convex/server";
import { internal } from "./_generated/api.js";
import { vBatchView, vClaimResult } from "./schema.js";
import { isAdminUser, requireAdminUser } from "./access.js";
import { userActor, writeAudit } from "./chefAudit.js";
import { readChefSettings } from "./chefSettings.js";
import { buildableSnapshot, claimNextBuild, newestRunOf, type ClaimResult, type RunVia } from "./chefRuns.js";
import {
  MAX_BATCH,
  MAX_PLAN_REQUESTS,
  PLAN_TIMEOUT_MS,
  numberList,
  planRequestOf,
  type PlanRequest,
} from "../chef/batching.js";
import { singleLine } from "../chef/text.js";

// How far the planner's scan looks down the queue (entries a claim would skip included).
const PLAN_SCAN = 60;

async function stateRow(ctx: QueryCtx) {
  return await ctx.db
    .query("chefState")
    .withIndex("by_key", (q) => q.eq("key", "singleton"))
    .unique();
}

/**
 * Whether a queued item's build may be planned with others: an ordinary
 * approval (not Chef's own retry, follow-up or merge-only copy, not a "Try
 * again" continuing a failed run's work), not in a batch, not split out.
 */
function batchable(item: Doc<"items">, snapshot: Doc<"chefSnapshots">): boolean {
  return (
    item.batchId === undefined &&
    item.batchAlone !== true &&
    item.continueFrom === undefined &&
    item.kind !== "refinement" &&
    !snapshot.retry &&
    !snapshot.refresh &&
    !snapshot.followUp
  );
}

/** The waiting requests a plan may group, oldest first, at most MAX_PLAN_REQUESTS. */
async function planCandidates(ctx: QueryCtx): Promise<Array<{ item: Doc<"items">; snapshot: Doc<"chefSnapshots"> }>> {
  const queued = await ctx.db
    .query("items")
    .withIndex("by_cloudQueuedAt", (q) => q.gt("cloudQueuedAt", 0))
    .take(PLAN_SCAN);
  const out: Array<{ item: Doc<"items">; snapshot: Doc<"chefSnapshots"> }> = [];
  for (const item of queued) {
    if (out.length >= MAX_PLAN_REQUESTS) break;
    const snapshot = await buildableSnapshot(ctx, item);
    if (snapshot && batchable(item, snapshot)) out.push({ item, snapshot });
  }
  return out;
}

/**
 * The claim's planning step. Null when there is nothing to plan (batching
 * off, no planner, fewer than two waiting, or nothing new since the last
 * plan): the claim goes on. Otherwise the claim is held: the planner and
 * its timeout check are scheduled, and the claim says "planning".
 */
export async function maybeStartPlanning(
  ctx: MutationCtx,
  state: Doc<"chefState">,
  opts: { via: RunVia; actor: string; startedBy?: string; adminRequestsOnly?: boolean },
  now: number,
): Promise<ClaimResult | null> {
  // A local worker's claim builds what it finds; batches already planned
  // still build together (claimNextBuild), but a worker doesn't plan.
  if (opts.via === "enroll" || opts.adminRequestsOnly) return null;
  if (!state.plannerHandle) return null;
  if (!(await readChefSettings(ctx)).cloudBatching) return null;
  const candidates = await planCandidates(ctx);
  if (candidates.length < 2) return null;
  // Planned already, and nothing queued since: the answer would be the same.
  if (candidates.every((c) => (c.item.batchConsideredAt ?? 0) >= (c.item.cloudQueuedAt ?? 0))) return null;
  const id = `plan-${now.toString(36)}-${state.nextSeq}`;
  await ctx.db.patch("chefState", state._id, {
    planning: {
      id,
      startedAt: now,
      via: opts.via,
      actor: opts.actor,
      ...(opts.startedBy !== undefined ? { startedBy: opts.startedBy } : {}),
      itemIds: candidates.map((c) => c.item._id),
    },
  });
  const requests: PlanRequest[] = [];
  for (const c of candidates) {
    await ctx.db.patch("items", c.item._id, { batchConsideredAt: now });
    requests.push(
      planRequestOf({
        number: c.item.number,
        title: c.snapshot.title,
        description: c.snapshot.description,
        votes: c.item.supporterCount ?? c.item.totalAmount ?? 0,
        screenshots: c.snapshot.attachments.filter((a) => a.kind === "screenshot").length,
      }),
    );
  }
  await ctx.scheduler.runAfter(0, state.plannerHandle as FunctionHandle<"action">, { planId: id, requests, maxBatch: MAX_BATCH });
  // Its one timeout check: a planner that never answers holds nothing for long.
  await ctx.scheduler.runAfter(PLAN_TIMEOUT_MS, internal.chefBatches.planTimeout, { planId: id });
  await writeAudit(ctx, {
    actor: opts.actor,
    action: "batch.planning",
    outcome: "ok",
    detail: { planId: id, requests: requests.length, via: opts.via },
  });
  return { outcome: "planning" };
}

/** Whether a planning call holds the claim right now (not timed out). */
export function planningHolds(state: Doc<"chefState">, now: number): boolean {
  return !!state.planning && now - state.planning.startedAt < PLAN_TIMEOUT_MS;
}

/**
 * Take an item out of its batch (it builds alone from now on when `alone`).
 * A batch left with one request is dissolved: that one builds alone too.
 */
export async function leaveBatch(ctx: MutationCtx, itemId: Id<"items">, opts: { alone: boolean }): Promise<Doc<"chefBatches"> | null> {
  const item = await ctx.db.get("items", itemId);
  if (!item?.batchId) return null;
  const batch = await ctx.db.get("chefBatches", item.batchId);
  await ctx.db.patch("items", itemId, { batchId: undefined, ...(opts.alone ? { batchAlone: true } : {}) });
  // Only a waiting batch changes; one that built, or ended, keeps its record.
  if (!batch || batch.status !== "planned") return batch;
  const rest = batch.itemIds.filter((id) => id !== itemId);
  const now = Date.now();
  if (rest.length <= 1) {
    for (const id of rest) await ctx.db.patch("items", id, { batchId: undefined });
    await ctx.db.patch("chefBatches", batch._id, { status: "dissolved", itemIds: rest, updatedAt: now });
  } else {
    await ctx.db.patch("chefBatches", batch._id, { itemIds: rest, updatedAt: now });
  }
  return await ctx.db.get("chefBatches", batch._id);
}

/** End a batch: every request in it builds alone from now on (not split out: the planner may group it again). */
export async function dissolveBatch(ctx: MutationCtx, batchId: Id<"chefBatches">, status: "dissolved" | "split" | "built" = "dissolved") {
  const batch = await ctx.db.get("chefBatches", batchId);
  if (!batch) return;
  for (const id of batch.itemIds) {
    const item = await ctx.db.get("items", id);
    if (item?.batchId === batchId) await ctx.db.patch("items", id, { batchId: undefined });
  }
  await ctx.db.patch("chefBatches", batchId, { status, updatedAt: Date.now() });
}

// --------------------------------------------------------- the planner

/**
 * Register the host's planner (a function handle from createFunctionHandle,
 * to an action taking `{ planId, requests, maxBatch }` that answers with
 * applyPlan; chef-cloud's chefPlanBatches). Null unregisters: no planning,
 * every request builds alone. Host-only.
 */
export const setPlanner = mutation({
  args: { handle: v.union(v.string(), v.null()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    const state = await stateRow(ctx);
    const patch = { plannerHandle: args.handle ?? undefined };
    if (state) {
      if (state.plannerHandle === patch.plannerHandle) return null;
      await ctx.db.patch("chefState", state._id, patch);
    } else await ctx.db.insert("chefState", { key: "singleton", nextSeq: 1, ...patch });
    await writeAudit(ctx, {
      actor: "system:host",
      action: "planner.set",
      outcome: "ok",
      detail: { registered: args.handle !== null },
    });
    return null;
  },
});

const vPlanned = v.object({ numbers: v.array(v.number()), title: v.string(), reason: v.string() });

/**
 * End the planning call `planId` and make the claim it stood in for. Called
 * once by the planner: with its batches, or with `batches: null` (and why)
 * when the call failed, and every request builds alone. Its groups are
 * checked again here: numbers it was given, still waiting and not in a
 * batch, each once, 2 to MAX_BATCH to a batch. Null for a plan that isn't
 * the one in flight (it timed out, or already answered). Host-only.
 */
export const applyPlan = mutation({
  args: {
    planId: v.string(),
    batches: v.union(v.null(), v.array(vPlanned)),
    model: v.optional(v.string()),
    costUsd: v.optional(v.number()),
    error: v.optional(v.string()),
  },
  returns: v.union(vClaimResult, v.null()),
  handler: async (ctx, args) => {
    const state = await stateRow(ctx);
    const p = state?.planning;
    if (!state || !p || p.id !== args.planId) {
      await writeAudit(ctx, {
        actor: "system:planner",
        action: "batch.planned",
        outcome: "refused",
        reason: "not the planning call in flight (it timed out, or already answered)",
        detail: { planId: args.planId.slice(0, 64) },
      });
      return null;
    }
    await ctx.db.patch("chefState", state._id, { planning: undefined });
    const made = args.batches ? await writeBatches(ctx, p.itemIds, args.batches, args.model) : [];
    await writeAudit(ctx, {
      actor: "system:planner",
      action: "batch.planned",
      outcome: args.batches ? "ok" : "error",
      ...(args.error !== undefined ? { reason: args.error.slice(0, 500) } : {}),
      detail: {
        planId: p.id,
        requests: p.itemIds.length,
        batches: made.length,
        batched: made.reduce((n, b) => n + b.length, 0),
        model: args.model ?? null,
        costUsd: typeof args.costUsd === "number" && Number.isFinite(args.costUsd) ? args.costUsd : null,
        fallback: args.batches === null,
      },
    });
    return await claimNextBuild(ctx, {
      via: p.via,
      actor: p.actor,
      ...(p.startedBy !== undefined ? { startedBy: p.startedBy } : {}),
    });
  },
});

/** Write the planner's batches; the item ids of each one made. */
async function writeBatches(
  ctx: MutationCtx,
  given: Id<"items">[],
  batches: Array<{ numbers: number[]; title: string; reason: string }>,
  model: string | undefined,
): Promise<Id<"items">[][]> {
  const byNumber = new Map<number, Doc<"items">>();
  for (const id of given) {
    const item = await ctx.db.get("items", id);
    if (!item) continue;
    const snapshot = await buildableSnapshot(ctx, item);
    if (snapshot && batchable(item, snapshot)) byNumber.set(item.number, item);
  }
  const used = new Set<number>();
  const made: Id<"items">[][] = [];
  const now = Date.now();
  for (const b of batches.slice(0, MAX_PLAN_REQUESTS)) {
    const items: Doc<"items">[] = [];
    for (const n of b.numbers) {
      const item = byNumber.get(n);
      if (!item || used.has(n) || items.length >= MAX_BATCH) continue;
      items.push(item);
      used.add(n);
    }
    if (items.length < 2) {
      for (const i of items) used.delete(i.number);
      continue;
    }
    // Queue order: the batch builds when its oldest request's turn comes.
    items.sort((a, c) => (a.cloudQueuedAt ?? 0) - (c.cloudQueuedAt ?? 0));
    const batchId = await ctx.db.insert("chefBatches", {
      status: "planned",
      itemIds: items.map((i) => i._id),
      title: singleLine(b.title, 120) || `Requests ${numberList(items.map((i) => i.number))}`,
      reason: singleLine(b.reason, 200),
      runIds: [],
      failures: 0,
      ...(model ? { model: model.slice(0, 64) } : {}),
      createdAt: now,
      updatedAt: now,
    });
    for (const i of items) {
      await ctx.db.patch("items", i._id, { batchId });
      const others = items.filter((o) => o._id !== i._id).map((o) => o.number);
      await ctx.db.insert("devLogs", {
        itemId: i._id,
        authorId: "chef",
        message: `Chef will build this together with ${numberList(others)}: they touch the same part of the app.`,
        stamp: now,
      });
    }
    made.push(items.map((i) => i._id));
  }
  return made;
}

/** A planning call that hasn't answered by now is given up on: every request builds alone, and the claim goes on. */
export const planTimeout = internalMutation({
  args: { planId: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    const state = await stateRow(ctx);
    const p = state?.planning;
    if (!state || !p || p.id !== args.planId) return null;
    await ctx.db.patch("chefState", state._id, { planning: undefined });
    await writeAudit(ctx, {
      actor: "system:planner",
      action: "batch.planTimeout",
      outcome: "error",
      reason: "the planner didn't answer in time; every request builds alone",
      detail: { planId: p.id },
    });
    await claimNextBuild(ctx, { via: p.via, actor: p.actor, ...(p.startedBy !== undefined ? { startedBy: p.startedBy } : {}) });
    return null;
  },
});

/** The batch's planned requests, for a claim: the others still buildable (those that aren't leave the batch). */
export async function gatherBatch(
  ctx: MutationCtx,
  lead: Doc<"items">,
  opts: { adminRequestsOnly?: boolean },
): Promise<{ batch: Doc<"chefBatches">; members: Array<{ item: Doc<"items">; snapshot: Doc<"chefSnapshots"> }> } | null> {
  if (!lead.batchId) return null;
  const batch = await ctx.db.get("chefBatches", lead.batchId);
  if (!batch || batch.status !== "planned" || !batch.itemIds.includes(lead._id)) {
    await ctx.db.patch("items", lead._id, { batchId: undefined });
    return null;
  }
  const members: Array<{ item: Doc<"items">; snapshot: Doc<"chefSnapshots"> }> = [];
  for (const id of batch.itemIds) {
    if (id === lead._id) continue;
    const item = await ctx.db.get("items", id);
    const snapshot = item && item.batchId === batch._id ? await buildableSnapshot(ctx, item) : null;
    const ok = item && snapshot && (!opts.adminRequestsOnly || (await isAdminUser(ctx, item.createdBy)));
    if (ok) members.push({ item, snapshot });
    else if (item?.batchId === batch._id) await ctx.db.patch("items", id, { batchId: undefined });
  }
  if (members.length === 0) {
    await ctx.db.patch("items", lead._id, { batchId: undefined });
    await ctx.db.patch("chefBatches", batch._id, { status: "dissolved", itemIds: [lead._id], updatedAt: Date.now() });
    return null;
  }
  const itemIds = [lead._id, ...members.map((m) => m.item._id)];
  if (itemIds.length !== batch.itemIds.length) await ctx.db.patch("chefBatches", batch._id, { itemIds, updatedAt: Date.now() });
  return { batch: { ...batch, itemIds }, members };
}

// ------------------------------------------------------------- admins

/**
 * An admin splits a request out of a batch that hasn't started building: it
 * goes back to the queue alone, where it was, and the planner leaves it
 * alone until it is approved again. A batch left with one request builds
 * that one alone too. Audited.
 */
export const split = mutation({
  args: { adminUserId: v.string(), itemId: v.id("items") },
  returns: v.object({ batchId: v.id("chefBatches"), remaining: v.number() }),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    const item = await ctx.db.get("items", args.itemId);
    if (!item) throw new Error("Request not found");
    if (!item.batchId) throw new Error(`Request #${item.number} isn't in a batch`);
    const batch = await ctx.db.get("chefBatches", item.batchId);
    if (!batch) throw new Error(`Request #${item.number} isn't in a batch`);
    if (batch.status !== "planned") {
      throw new Error(`Request #${item.number}'s batch is already ${batch.status}: cancel the build to change it`);
    }
    const after = await leaveBatch(ctx, item._id, { alone: true });
    await ctx.db.insert("devLogs", {
      itemId: item._id,
      authorId: "chef",
      message: "Split out of its batch by an admin: Chef builds it on its own.",
      stamp: Date.now(),
    });
    await writeAudit(ctx, {
      actor: userActor(args.adminUserId),
      action: "batch.split",
      target: item._id,
      outcome: "ok",
      detail: { batchId: batch._id, remaining: after && after.status === "planned" ? after.itemIds.length : 0 },
    });
    return { batchId: batch._id, remaining: after && after.status === "planned" ? after.itemIds.length : 0 };
  },
});

// ---------------------------------------------------- when one fails

/**
 * After a batch's build failed (finishRun scheduled this, at once or after
 * a transient failure's backoff): build its requests again, together
 * (`retryBatch`) or each alone (`split`), from fresh copies of their
 * approved snapshots (the same bytes, hash and approval, marked `retry`
 * with the spend so far), queued at the front, and claim. A request that
 * moved on since (edited, approved again, dropped, built again) is left
 * out. Audited.
 */
export const requeueAfterFailure = internalMutation({
  args: { runId: v.id("chefRuns"), mode: v.union(v.literal("retryBatch"), v.literal("split")) },
  returns: v.union(vClaimResult, v.null()),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run?.batch || run.status !== "failed") return null;
    const batch = await ctx.db.get("chefBatches", run.batch.batchId);
    if (!batch) return null;
    if (run.retryAt !== undefined) await ctx.db.patch("chefRuns", run._id, { retryAt: undefined });
    const now = Date.now();
    const attempt = (run.attempt ?? 1) + 1;
    const priorSpendUsd = (run.priorSpendUsd ?? 0) + (run.spendUsd ?? 0);
    const followUp =
      run.recovery?.action === "fixRound"
        ? { ofRunId: run._id, reason: (run.failure?.reason ?? run.error ?? "the preview deploy failed").slice(0, 2000) }
        : null;
    const kept: Doc<"items">[] = [];
    for (const m of run.batch.items) {
      const item = await ctx.db.get("items", m.itemId);
      const snapshot = await ctx.db.get("chefSnapshots", m.snapshotId);
      const newest = item ? await newestRunOf(ctx, item._id) : null;
      const unchanged =
        item &&
        snapshot &&
        snapshot.approvedAt !== undefined &&
        snapshot.approvedBy !== undefined &&
        item.state === "requested" &&
        !item.mergedInto &&
        item.snapshotId === m.snapshotId &&
        newest?._id === run._id;
      if (!unchanged) {
        if (item?.batchId === batch._id) await ctx.db.patch("items", item._id, { batchId: undefined });
        continue;
      }
      const copyId = await ctx.db.insert("chefSnapshots", {
        itemId: snapshot.itemId,
        title: snapshot.title,
        description: snapshot.description,
        transcript: snapshot.transcript,
        attachments: snapshot.attachments,
        contentHash: snapshot.contentHash,
        itemUpdatedAt: snapshot.itemUpdatedAt,
        createdBy: "system:batch",
        createdAt: now,
        approvedBy: snapshot.approvedBy,
        approvedAt: snapshot.approvedAt,
        retry: { ofRunId: run._id, attempt, priorSpendUsd },
        ...(followUp ? { followUp } : {}),
      });
      await ctx.db.patch("items", item._id, { snapshotId: copyId, cloudQueuedAt: 1 });
      kept.push(item);
    }
    const together = args.mode === "retryBatch" && kept.length >= 2;
    if (together) {
      await ctx.db.patch("chefBatches", batch._id, { status: "planned", itemIds: kept.map((i) => i._id), updatedAt: now });
      for (const i of kept) await ctx.db.patch("items", i._id, { batchId: batch._id });
    } else {
      await ctx.db.patch("chefBatches", batch._id, { status: "split", updatedAt: now });
      for (const i of kept) await ctx.db.patch("items", i._id, { batchId: undefined, batchAlone: true });
    }
    for (const i of kept) {
      const others = kept.filter((o) => o._id !== i._id).map((o) => o.number);
      await ctx.db.insert("devLogs", {
        itemId: i._id,
        authorId: "chef",
        message: together
          ? `Chef builds it again together with ${numberList(others)} (its batch's try ${attempt}).`
          : "Its batch failed again, so Chef builds it on its own.",
        stamp: now,
      });
    }
    const claim = await claimNextBuild(ctx, { via: "retry", actor: "system:batch" });
    await writeAudit(ctx, {
      actor: "system:batch",
      action: together ? "batch.retry" : "batch.split",
      runId: run._id,
      target: batch._id,
      outcome: "ok",
      detail: { requests: kept.length, attempt, claim: claim.outcome, failures: batch.failures },
    });
    return claim;
  },
});

// -------------------------------------------------------------- reads

export async function batchView(ctx: QueryCtx, batch: Doc<"chefBatches">) {
  const items = [];
  for (const id of batch.itemIds) {
    const item = await ctx.db.get("items", id);
    if (item) items.push({ itemId: item._id, number: item.number, title: item.title, state: item.state });
  }
  return {
    batchId: batch._id,
    status: batch.status,
    title: batch.title,
    reason: batch.reason,
    failures: batch.failures,
    runId: batch.runIds.length ? batch.runIds[batch.runIds.length - 1] : null,
    items,
  };
}

/** Batches still to build, being built or built lately (not yet shipped), at most 10, newest first. */
export async function liveBatches(ctx: QueryCtx) {
  const out: Doc<"chefBatches">[] = [];
  for (const status of ["planned", "building", "built"] as const) {
    out.push(...(await ctx.db.query("chefBatches").withIndex("by_status", (q) => q.eq("status", status)).order("desc").take(10)));
  }
  out.sort((a, b) => b.createdAt - a.createdAt);
  const views = [];
  for (const b of out.slice(0, 10)) {
    const view = await batchView(ctx, b);
    // A built batch drops off once all of it shipped (or left).
    if (b.status === "built" && !view.items.some((i) => i.state === "inProgress")) continue;
    views.push(view);
  }
  return views;
}

/** The batches the panel shows (waiting, building, built and not shipped), and whether a plan is being made. Admins only. */
export const list = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())) },
  returns: v.union(v.null(), v.object({ planning: v.boolean(), batches: v.array(vBatchView) })),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    const state = await stateRow(ctx);
    return { planning: !!state && planningHolds(state, Date.now()), batches: await liveBatches(ctx) };
  },
});
