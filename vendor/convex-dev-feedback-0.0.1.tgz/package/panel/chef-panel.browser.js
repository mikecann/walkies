// chef-panel.browser.js — the floating "Chef" feedback panel, as a dependency-free
// web component. Ships in @convex-dev/feedback (`@convex-dev/feedback/panel`).
//
//   <script type="module" src=".../chef-panel.browser.js"></script>
//   <chef-panel convex-url="https://<deployment>.convex.cloud" prefix="chef"></chef-panel>
//   <script>document.querySelector("chef-panel").setAuth(fetchToken)</script>
//
// It calls the functions `exposeChefApi` creates (see src/client/chef.ts), under the
// module named by `prefix` (default "chef" → convex/chef.ts). Tap the bubble to
// open the panel; LONG-PRESS (or right-click) it to snapshot the page and send a
// screenshot + voice-note request.
//
// Two faces, chosen by the server's `amAdmin`:
//   - admins see Chef: the Chef brand, build status, Chef's questions, the
//     "Waiting for your approval" queue (Approve snapshots the request and
//     shows it in full, hidden characters as markers; "Approve and build"
//     approves that snapshot's hash), their cloud builds (phases, preview and
//     its one-time sign-in link, screenshots, skill notes, spend approvals,
//     the run log; "Build in cloud" only while cloud builds are on, from
//     `buildState`), "Ship it" (the plain-language card first, from
//     `buildCard`: what changed, what to try, screenshots and risk flags; the
//     whole diff main..chef under "Details"; the requests it ships, and "Ship
//     to live", which approves that diff's hash), and every
//     request;
//   - everyone else (members, signed-out visitors) sees a neutral lightbulb
//     "Suggest a feature" button (override with `member-label="Feedback"`), and
//     only "Request a feature" plus their own requests. No Chef branding.
//
// What's new: once per page load the panel asks `<prefix>:whatsNew({ since })` for
// changelogs shipped since this browser last looked (localStorage
// "chef-whatsnew-seen:<prefix>"; a first visit just records "now") and, if there are
// any, shows a small "What's new" card above the launcher. `whats-new="off"` disables it.
//
// Auth: hand the panel a token fetcher with `panel.setAuth(fetchToken)` — same
// signature as ConvexClient.setAuth: ({ forceRefreshToken }) => Promise<string|null>.
// Without it the panel is read-only (sending requires a signed-in user).
//
// File name: the multiple dots are deliberate. This file lives inside the
// component's directory, and Convex's bundler skips files whose names contain
// more than one dot — otherwise it would try to deploy this browser script as
// a component module (and reject the hyphen) on every push.

// Convex's browser client: the app's own copy when its bundle handed one over
// (ChefPanelMount sets globalThis.__chefConvexLib before loading this file), else
// loaded at runtime from esm.sh, so this file has no bare imports: it works from
// a plain <script type="module"> and is left alone by app bundlers
// (webpackIgnore / turbopackIgnore / @vite-ignore). The app's copy matters where
// esm.sh can't be reached: Chef's demo sandbox allows only the app's own hosts,
// and every Makeabook demo stopped there with the panel unloaded.
const CONVEX_VERSION = "1.35.1";
const CONVEX_BROWSER = `https://esm.sh/convex@${CONVEX_VERSION}/browser`;
const CONVEX_SERVER = `https://esm.sh/convex@${CONVEX_VERSION}/server`;
let convexLib = null;
function loadConvex() {
  const own = globalThis.__chefConvexLib;
  if (!convexLib && own && typeof own.ConvexClient === "function" && typeof own.makeFunctionReference === "function") {
    convexLib = Promise.resolve({ ConvexClient: own.ConvexClient, makeFunctionReference: own.makeFunctionReference });
  }
  convexLib = convexLib || Promise.all([
    import(/* webpackIgnore: true */ /* turbopackIgnore: true */ /* @vite-ignore */ CONVEX_BROWSER),
    import(/* webpackIgnore: true */ /* turbopackIgnore: true */ /* @vite-ignore */ CONVEX_SERVER),
  ]).then(([browser, server]) => ({ ConvexClient: browser.ConvexClient, makeFunctionReference: server.makeFunctionReference }));
  return convexLib;
}

// Official Chef brand mark (toque + "Chef" wordmark).
const BRAND_SRC = "https://chef.convex.dev/chef.svg";
const BRAND = `<img class="brand" src="${BRAND_SRC}" alt="Chef" />`;
// Neutral mark for everyone who isn't an admin.
const BULB = `<svg class="bulb" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18h6M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.2 1 2V17h6v-.3c0-.8.4-1.5 1-2A7 7 0 0 0 12 2z"/></svg>`;
const SPARK = `<svg class="spark" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/></svg>`;
const DEFAULT_MEMBER_LABEL = "Suggest a feature";

// Screenshot lib: loaded lazily (first capture) from a CDN, pinned.
const SHOT_LIB = "https://cdn.jsdelivr.net/npm/modern-screenshot@4.7.0/+esm";
const LONG_PRESS_MS = 500;
const MAX_SHOTS = 4;
const MAX_SHOT_BYTES = 10 * 1024 * 1024;
const MAX_AUDIO_BYTES = 25 * 1024 * 1024;
const MAX_REC_MS = 5 * 60 * 1000;

// A request's state as a chip: [label, kind]. Admins see the build lifecycle.
// `inProgress` covers both a request being built and one built and waiting for
// Ship it; `built` is the panel's own name for the second (see buildingIds).
const STATE_LABEL = {
  submitted: ["Needs approval", "warn"],
  requested: ["Queued", "plain"],
  planned: ["Queued", "plain"],
  inProgress: ["Building", "busy"],
  built: ["Ready to ship", "ok"],
  completed: ["Shipped", "ok"],
  rejected: ["Declined", "plain"],
};
// Members: friendly words for "Your requests".
const MEMBER_STATE_LABEL = {
  submitted: ["Waiting for approval", "warn"],
  requested: ["Planned", "info"],
  planned: ["Planned", "info"],
  inProgress: ["In progress", "busy"],
  completed: ["Done", "ok"],
  rejected: ["Declined", "plain"],
};
// How "Your requests" groups for admins, in this order.
const REQUEST_GROUPS = [
  ["inProgress", "Building"],
  ["built", "Built, ready to ship"],
  ["queued", "Waiting to build"],
  ["submitted", "Needs approval"],
  ["completed", "Shipped"],
  ["rejected", "Declined"],
];

const CSS = `
  :host { all: initial; --chef-right: 24px; --chef-bottom: 24px;
    --ink: #1f2328; --ink2: #4b5563; --muted: #6b7280; --faint: #9ca3af;
    --line: #ececee; --soft: #f6f6f7; --bg: #fff;
    --accent: #ea580c; --accent-ink: #c2410c; --accent-soft: #fff4ec; --accent-line: #fed7aa;
    --ok: #15803d; --ok-soft: #ecfdf3; --ok-line: #bbf7d0;
    --bad: #b91c1c; --bad-soft: #fef2f2; --bad-line: #fecaca;
    --warn: #b45309; --warn-soft: #fffbeb; --warn-line: #fde68a;
    --info: #1d4ed8; --info-soft: #eff6ff;
    --font: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    --mono: ui-monospace, SFMono-Regular, Menlo, monospace; }
  * { box-sizing: border-box; }
  a { color: var(--accent-ink); }

  /* ---- minimized: the Chef pill ---- */
  .fab { position: fixed; right: var(--chef-right); bottom: var(--chef-bottom); z-index: 2147483000;
    height: 50px; padding: 0 18px; border-radius: 999px; border: 1px solid var(--accent-line); cursor: pointer;
    display: inline-flex; align-items: center; gap: 10px; background: #fff;
    box-shadow: 0 8px 24px rgba(0,0,0,.14), 0 2px 6px rgba(0,0,0,.08);
    transition: transform 120ms ease, box-shadow 120ms ease;
    -webkit-touch-callout: none; user-select: none; -webkit-user-select: none; touch-action: manipulation; }
  .fab:hover { transform: translateY(-1px); box-shadow: 0 12px 30px rgba(0,0,0,.18), 0 3px 8px rgba(0,0,0,.10); }
  .fab.pressing { transform: scale(.96); box-shadow: 0 0 0 6px rgba(234,88,12,.18), 0 8px 24px rgba(0,0,0,.14); }
  .fab .brand { display: block; height: 24px; width: auto; }
  .fab .spin { width: 14px; height: 14px; }
  .fab .mic { position: absolute; left: -6px; bottom: -6px; width: 24px; height: 24px; border-radius: 999px;
    display: inline-flex; align-items: center; justify-content: center; background: var(--accent); color: #fff;
    box-shadow: 0 2px 6px rgba(0,0,0,.25); }
  .fab .mic:hover { background: var(--accent-ink); }
  .fab .mic svg { width: 13px; height: 13px; }
  .fab .dot { position: absolute; top: -4px; right: -4px; min-width: 20px; height: 20px; padding: 0 5px;
    border-radius: 999px; background: var(--accent); color: #fff; border: 2px solid #fff;
    font: 700 11px/1 var(--font); display: inline-flex; align-items: center; justify-content: center; }
  .fab.member { border-color: #e5e7eb; width: 48px; height: 48px; padding: 0; justify-content: center; gap: 0; }
  .fab.member .lab { display: none; }
  .fab.member:hover, .fab.member:focus-visible { width: auto; padding: 0 16px; gap: 8px; }
  .fab.member:hover .lab, .fab.member:focus-visible .lab { display: inline; }
  .fab .bulb { width: 20px; height: 20px; color: var(--accent); flex-shrink: 0; }
  .fab .lab { font: 600 14px/1 var(--font); color: var(--ink); white-space: nowrap; }

  /* ---- the open panel ---- */
  .bubble, .comp { position: fixed; right: var(--chef-right); bottom: var(--chef-bottom); z-index: 2147483000;
    width: 400px; max-width: calc(100vw - 32px); max-height: min(700px, calc(100vh - 48px));
    display: flex; flex-direction: column; overflow: hidden;
    font: 13px/1.45 var(--font); color: var(--ink); background: var(--bg);
    border: 1px solid var(--line); border-radius: 16px;
    box-shadow: 0 24px 60px rgba(0,0,0,.18), 0 6px 14px rgba(0,0,0,.08); }
  .comp { z-index: 2147483001; }
  /* Phones: a sheet across the bottom of the screen. */
  @media (max-width: 520px) {
    .bubble, .comp { left: 8px; right: 8px; bottom: max(8px, env(safe-area-inset-bottom)); width: auto; max-width: none;
      max-height: calc(100dvh - 24px); border-radius: 14px; }
  }

  .hdr { display: flex; align-items: center; gap: 10px; padding: 12px 12px 10px 14px; background: var(--bg); }
  .hdr .brand { height: 26px; width: auto; flex-shrink: 0; display: block; }
  .hdr .bulb { width: 24px; height: 24px; color: var(--accent); flex-shrink: 0; }
  .hdr .ttl { flex: 1; min-width: 0; }
  .hdr .ttl b { display: block; font-weight: 650; font-size: 14px; color: var(--ink);
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .hdr .ttl > span { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--muted);
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .min { flex-shrink: 0; width: 30px; height: 30px; border: 0; border-radius: 8px; cursor: pointer;
    background: var(--soft); color: var(--ink2); font-size: 15px; line-height: 1; display: grid; place-items: center; }
  .min:hover { background: #ececee; }

  .tabs { display: flex; gap: 2px; padding: 0 10px; border-bottom: 1px solid var(--line); background: var(--bg); }
  .tab { all: unset; cursor: pointer; padding: 8px 10px 9px; font: 600 13px/1 var(--font); color: var(--muted);
    border-bottom: 2px solid transparent; margin-bottom: -1px; display: inline-flex; align-items: center; gap: 6px; }
  .tab:hover { color: var(--ink); }
  .tab[aria-selected="true"] { color: var(--ink); border-bottom-color: var(--accent); }
  .tab:focus-visible { outline: 2px solid var(--accent); outline-offset: -2px; border-radius: 4px; }
  .tab .n { min-width: 18px; height: 18px; padding: 0 5px; border-radius: 999px; font-size: 11px; font-weight: 700;
    display: inline-flex; align-items: center; justify-content: center; background: var(--soft); color: var(--ink2); }
  .tab .n.hot { background: var(--accent); color: #fff; }
  .tab .spin { width: 10px; height: 10px; }

  /* minmax(0,1fr): a grid column otherwise grows to its widest nowrap line and the body scrolls sideways */
  .body { overflow-y: auto; overflow-x: hidden; padding: 14px; background: var(--bg); flex: 1; min-height: 120px;
    display: grid; grid-template-columns: minmax(0, 1fr); align-content: start; gap: 18px; }
  section { display: grid; gap: 8px; min-width: 0; }
  .lbl { font-size: 12px; font-weight: 650; color: var(--ink2); display: flex; align-items: center; gap: 6px; }
  .lbl .n { font-weight: 500; color: var(--faint); }
  .lbl .spin { width: 10px; height: 10px; }
  .muted { font-size: 13px; color: var(--muted); margin: 0; }
  .small { font-size: 12px; color: var(--muted); }
  p.small { margin: 0; }
  .divider { display: none; }
  .empty { text-align: center; padding: 18px 8px; color: var(--muted); display: grid; gap: 6px; justify-items: center; }
  .empty b { color: var(--ink); font-weight: 600; font-size: 14px; }

  .spin { display: inline-block; width: 11px; height: 11px; flex-shrink: 0; border: 2px solid rgba(234,88,12,.25);
    border-top-color: var(--accent); border-radius: 50%; animation: chef-spin .8s linear infinite; }

  .chip { display: inline-flex; align-items: center; gap: 4px; flex-shrink: 0; height: 20px; padding: 0 7px;
    border-radius: 999px; font: 600 11px/1 var(--font); white-space: nowrap; background: var(--soft); color: var(--ink2); }
  .chip.ok { background: var(--ok-soft); color: var(--ok); }
  .chip.bad { background: var(--bad-soft); color: var(--bad); }
  .chip.warn { background: var(--warn-soft); color: var(--warn); }
  .chip.busy { background: var(--accent-soft); color: var(--accent-ink); }
  .chip.info { background: var(--info-soft); color: var(--info); }

  /* buttons */
  textarea, input:not([type]), input[type="text"] { width: 100%; background: #fff; color: var(--ink);
    border: 1px solid #dcdce0; border-radius: 10px; padding: 8px 10px; font: inherit; font-size: 14px; margin: 0; }
  textarea { resize: none; min-height: 40px; }
  textarea:focus, input:focus { outline: 2px solid rgba(234,88,12,.35); outline-offset: 0; border-color: var(--accent); }
  .row-btns { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
  button.act, a.act { background: var(--accent); color: #fff; border: 0; border-radius: 9px; padding: 8px 14px;
    font: inherit; font-weight: 600; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; justify-content: center; gap: 6px; }
  button.act:hover, a.act:hover { background: var(--accent-ink); }
  button.act:disabled { opacity: .45; cursor: not-allowed; }
  button.ghost, a.ghost { background: #fff; color: var(--ink); border: 1px solid #dcdce0; border-radius: 9px;
    padding: 7px 12px; font: inherit; font-weight: 600; cursor: pointer; text-decoration: none;
    display: inline-flex; align-items: center; justify-content: center; gap: 6px; }
  button.ghost:hover, a.ghost:hover { background: var(--soft); }
  button.ghost:disabled { opacity: .5; cursor: not-allowed; }
  button.link { all: unset; cursor: pointer; color: var(--accent-ink); font-weight: 600; font-size: 12px; }
  button.link:hover { text-decoration: underline; }
  button.no { background: #fff; color: var(--bad); border: 1px solid var(--bad-line); border-radius: 9px; padding: 8px 14px;
    font: inherit; font-weight: 600; cursor: pointer; }
  button.no:hover { background: var(--bad-soft); }

  /* a list of rows in one bordered box */
  .list { border: 1px solid var(--line); border-radius: 12px; overflow: hidden; background: #fff; }
  .list > * + * { border-top: 1px solid var(--line); }
  .row { display: flex; gap: 10px; align-items: flex-start; padding: 10px 12px; min-width: 0; }
  .row .main { flex: 1; min-width: 0; display: grid; gap: 3px; }
  .row .rt { font-weight: 550; font-size: 13px; color: var(--ink); line-height: 1.35; overflow-wrap: anywhere;
    display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .row .meta { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; font-size: 12px; color: var(--muted); }
  .row .pos { flex-shrink: 0; width: 20px; height: 20px; border-radius: 999px; background: var(--soft); color: var(--ink2);
    font: 700 11px/20px var(--font); text-align: center; margin-top: 1px; }
  .row .pos.next { background: var(--accent); color: #fff; }
  .row.batch .breqs { margin: 4px 0 0; padding-left: 16px; display: grid; gap: 2px; }
  .row.batch .breqs .link { margin-left: 4px; }
  .btogether { color: var(--ink2); }

  /* the composer pinned under the body */
  .foot { border-top: 1px solid var(--line); padding: 10px 12px 12px; background: var(--bg); display: grid; gap: 8px; }
  .foot .bar { display: flex; gap: 8px; align-items: flex-end; }
  .foot textarea { flex: 1; min-height: 40px; max-height: 140px; }
  .foot .act { height: 40px; flex-shrink: 0; }
  .foot button.iconbtn { width: 40px; height: 40px; flex-shrink: 0; padding: 0; border-radius: 10px; border: 1px solid #dcdce0;
    background: #fff; color: var(--ink2); cursor: pointer; display: grid; place-items: center; }
  .foot button.iconbtn:hover { background: var(--soft); color: var(--accent-ink); }
  .foot button.iconbtn svg { width: 18px; height: 18px; }
  .foot .hint { font-size: 11px; color: var(--faint); }
  .flash { font-size: 12px; color: var(--bad); background: var(--bad-soft); border: 1px solid var(--bad-line); border-radius: 10px; padding: 8px 10px; }

  /* the local agent's plan */
  .todo { display: flex; gap: 10px; align-items: flex-start; font-size: 13px; color: var(--ink); }
  .todo.done { color: var(--muted); }
  .todo .t { flex: 1; min-width: 0; line-height: 1.4; overflow-wrap: anywhere; }
  .todo.done .t { text-decoration: line-through; }
  .tdot { flex-shrink: 0; width: 18px; height: 18px; border-radius: 999px; display: inline-flex;
    align-items: center; justify-content: center; font-size: 10px; font-weight: 700; margin-top: 1px; }
  .tdot.done { color: var(--ok); background: var(--ok-soft); }
  .tdot.active { color: var(--accent); background: var(--accent-soft); animation: chef-pulse 1.4s ease-in-out infinite; }
  .tdot.pending { color: var(--faint); background: var(--soft); }
  .prog { display: flex; gap: 8px; align-items: flex-start; font-size: 12px; color: var(--ink2); }
  .prog.dim { opacity: .6; }
  .pdot { flex-shrink: 0; width: 16px; height: 16px; border-radius: 999px; display: inline-flex;
    align-items: center; justify-content: center; font-size: 10px; font-weight: 700; margin-top: 1px;
    color: var(--accent); background: var(--accent-soft); }
  .pdot.shipped { color: var(--ok); background: var(--ok-soft); }
  .pdot.note { color: var(--muted); background: var(--soft); }

  /* Chef's questions */
  .qcard { padding: 12px; border-radius: 12px; background: var(--accent-soft); border: 1px solid var(--accent-line); display: grid; gap: 10px; }
  .qcard .qt { font-size: 14px; color: var(--ink); line-height: 1.45; }
  .qcard.done { background: var(--ok-soft); border-color: var(--ok-line); color: var(--ok); }
  .upnext { font-size: 12px; color: var(--muted); line-height: 1.4; padding-left: 10px; border-left: 2px solid var(--accent-line); }

  /* "Your requests" */
  .req .vote { flex-shrink: 0; min-width: 34px; height: 26px; padding: 0 6px; border: 1px solid var(--line); border-radius: 8px;
    background: #fff; font: 700 11px/1 var(--font); color: var(--ink2); cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 3px; }
  .req .vote:hover { border-color: var(--accent-line); color: var(--accent-ink); }
  .att { display: flex; gap: 4px; align-items: center; }
  .att a { display: block; width: 36px; height: 26px; border-radius: 5px; overflow: hidden; border: 1px solid var(--line); }
  .att img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .att .mic { width: auto; height: auto; border: 0; font-size: 13px; text-decoration: none; }
  .myid { font-size: 11px; color: var(--muted); display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
  .myid code { font-size: 11px; background: var(--soft); padding: 1px 5px; border-radius: 4px; overflow-wrap: anywhere; user-select: all; }
  .myid button { font-size: 11px; padding: 2px 8px; }

  /* approvals */
  .appr { padding: 12px; border-radius: 12px; background: #fff; border: 1px solid var(--warn-line); display: grid; gap: 8px; }
  .appr .at { font-weight: 600; font-size: 14px; color: var(--ink); overflow-wrap: anywhere; }
  .appr .who { font-size: 12px; color: var(--muted); }
  .appr .ad { font-size: 13px; color: var(--ink2); white-space: pre-wrap; overflow-wrap: anywhere; max-height: 7.5em; overflow: auto; }
  .appr .ashots { display: flex; gap: 6px; flex-wrap: wrap; }
  .appr .ashots a { display: block; width: 72px; height: 50px; border-radius: 6px; overflow: hidden; border: 1px solid var(--line); }
  .appr .ashots img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .appr audio { width: 100%; height: 32px; }
  .appr .row-btns > button { flex: 1; }
  .snapbox { border-top: 1px solid var(--warn-line); padding-top: 8px; display: grid; gap: 8px; }
  .snap { display: grid; gap: 6px; unicode-bidi: isolate; }
  .snap .snapt { font-weight: 700; font-size: 14px; white-space: pre-wrap; overflow-wrap: anywhere; unicode-bidi: isolate; }
  .snap .snapd { font-size: 12px; white-space: pre-wrap; overflow-wrap: anywhere; unicode-bidi: isolate; }
  .snap .snapl { font-size: 11px; font-weight: 700; color: var(--warn); }
  .snap .snaph, .snap figcaption { font: 11px var(--mono); color: var(--muted); }
  .snap figure { margin: 0; }
  .snap figure img { max-width: 100%; border-radius: 6px; display: block; }
  .snap audio { width: 100%; height: 32px; }
  .snapwarn { font-size: 12px; background: var(--warn-soft); border: 1px solid var(--warn); border-radius: 6px; padding: 7px; }
  .hid { background: var(--warn-line); color: #7c2d12; border: 1px solid var(--warn); border-radius: 3px; padding: 0 2px; font: 11px var(--mono); }

  /* cloud builds */
  .stat { display: flex; gap: 16px; padding: 10px 12px; border-radius: 12px; background: var(--soft); }
  .stat div { display: grid; gap: 1px; }
  .stat b { font-size: 15px; font-weight: 650; color: var(--ink); font-variant-numeric: tabular-nums; }
  .stat span { font-size: 11px; color: var(--muted); }
  .run { min-width: 0; }
  .runhd { all: unset; box-sizing: border-box; cursor: pointer; display: flex; gap: 10px; width: 100%; align-items: flex-start; padding: 10px 12px; }
  .runhd:hover { background: #fafafa; }
  .runhd:focus-visible { outline: 2px solid var(--accent); outline-offset: -2px; }
  .runhd .main { flex: 1; min-width: 0; display: grid; gap: 4px; }
  .runhd .rt { font-weight: 550; font-size: 13px; line-height: 1.35; color: var(--ink); overflow-wrap: anywhere;
    display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .run.open .runhd .rt { -webkit-line-clamp: unset; display: block; }
  .runhd .meta { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; font-size: 12px; color: var(--muted); }
  .runhd .rcost { font-weight: 600; color: var(--ink2); font-variant-numeric: tabular-nums; }
  .runhd .chev { flex-shrink: 0; color: var(--faint); font-size: 12px; margin-top: 2px; transition: transform 120ms ease; }
  .run.open .runhd .chev { transform: rotate(90deg); }
  .rst { }
  .rst.built { background: var(--ok-soft); color: var(--ok); }
  .rst.failed { background: var(--bad-soft); color: var(--bad); }
  .rst.cancelled { background: var(--soft); color: var(--muted); }
  .rst.active, .rst.reconciling { background: var(--accent-soft); color: var(--accent-ink); }
  .runfail { font-size: 12px; color: var(--bad); margin: -4px 12px 10px 12px; line-height: 1.35;
    display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; overflow-wrap: anywhere; }
  .run > .card, .run > .build { padding: 0 12px 12px; }
  .bstatus { font-size: 13px; font-weight: 700; color: var(--accent-ink); }
  .bstatus.built { color: var(--ok); } .bstatus.failed { color: var(--bad); } .bstatus.cancelled { color: var(--muted); }
  .build { display: grid; gap: 10px; font-size: 12px; min-width: 0; }
  .build .links, .card .links { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
  .build a.act, .build a.ghost, .card a.act, .card a.ghost { font-size: 12px; padding: 6px 10px; }
  .berr { color: var(--bad); white-space: pre-wrap; overflow-wrap: anywhere; font: 11px var(--mono); margin: 0; max-height: 200px; overflow: auto; }
  .bfail { display: grid; gap: 6px; padding: 10px; border: 1px solid var(--bad-line); border-radius: 10px; background: var(--bad-soft); }
  .bfail .fr { font-weight: 650; color: var(--bad); font-size: 13px; }
  details > summary { font-size: 12px; color: var(--muted); cursor: pointer; }
  details > summary:hover { color: var(--ink); }
  .gates { border-collapse: collapse; font-size: 11px; }
  .gates td, .gates th { padding: 1px 8px 1px 0; text-align: left; }
  .gates .pass { color: var(--ok); } .gates .fail { color: var(--bad); } .gates .pre { color: var(--muted); }
  .phases { list-style: none; margin: 6px 0 0; padding: 0; display: grid; gap: 2px; }
  .ph { display: flex; gap: 6px; }
  .ph .pg { width: 14px; }
  .ph.done .pg { color: var(--ok); }
  .ph.now { font-weight: 700; } .ph.now .pg { color: var(--accent); }
  .ph.stopped .pg { color: var(--bad); }
  .ph.todo { color: var(--faint); }
  .facts { display: grid; grid-template-columns: auto 1fr; gap: 3px 12px; margin: 0; }
  .facts dt { color: var(--muted); } .facts dd { margin: 0; }
  .build code, .build pre { font: 11px var(--mono); }
  .bshots { display: flex; gap: 6px; flex-wrap: wrap; }
  .bshots img { width: 96px; height: 60px; object-fit: cover; border-radius: 6px; border: 1px solid var(--line); display: block; }
  .spend { border: 1px solid var(--warn-line); border-radius: 10px; padding: 10px; display: grid; gap: 4px; }
  .spend .at { font-weight: 600; }
  .spend pre { white-space: pre-wrap; overflow-wrap: anywhere; margin: 0; }
  .decided { font-weight: 600; color: var(--muted); } .decided.approved { color: var(--ok); }
  .runlog { font: 11px var(--mono); white-space: pre-wrap; overflow-wrap: anywhere;
    max-height: 240px; overflow-y: auto; background: var(--soft); border-radius: 8px; padding: 8px; }
  .repair { border: 1px solid var(--ok-line); background: var(--ok-soft); border-radius: 10px; padding: 8px 10px; display: grid; gap: 4px; color: #14532d; }
  .repair ul { margin: 0; padding-left: 18px; }
  /* settings at the bottom of Builds */
  .setting { display: flex; gap: 12px; align-items: flex-start; padding: 10px 12px; }
  .setting .main { flex: 1; min-width: 0; display: grid; gap: 2px; }
  .setting .main b { font-weight: 600; font-size: 13px; }
  .switch { position: relative; flex-shrink: 0; width: 36px; height: 22px; margin-top: 1px; }
  .switch input { position: absolute; inset: 0; opacity: 0; margin: 0; cursor: pointer; }
  .switch span { position: absolute; inset: 0; border-radius: 999px; background: #d4d4d8; transition: background 120ms ease; pointer-events: none; }
  .switch span::after { content: ""; position: absolute; top: 3px; left: 3px; width: 16px; height: 16px; border-radius: 999px; background: #fff;
    box-shadow: 0 1px 2px rgba(0,0,0,.2); transition: transform 120ms ease; }
  .switch input:checked + span { background: var(--accent); }
  .switch input:checked + span::after { transform: translateX(14px); }
  .switch input:focus-visible + span { outline: 2px solid var(--accent); outline-offset: 2px; }
  .switch input:disabled + span { opacity: .5; }
  .learn { display: grid; gap: 8px; padding: 10px 12px; }
  .learn li { display: flex; gap: 8px; font-size: 12px; align-items: flex-start; } .learn li.exp { opacity: .5; }
  .learn ul { list-style: none; margin: 0; padding: 0; display: grid; gap: 6px; }
  .learn li button { font-size: 11px; padding: 2px 8px; }
  .costbars { display: flex; align-items: flex-end; gap: 3px; height: 40px; }
  .costbars span { width: 9px; border-radius: 2px; background: var(--accent); } .costbars span.built { background: var(--ok); } .costbars span.failed { background: var(--bad); }
  .warm-rate { font-size: 11px; color: var(--muted); }

  /* shipping */
  .shipst { font-size: 13px; font-weight: 650; color: var(--accent-ink); }
  .shipst.ok { color: var(--ok); } .shipst.bad { color: var(--bad); }
  .shiprev { display: grid; gap: 8px; font-size: 12px; }
  .shipreqs { margin: 0; padding-left: 18px; }
  .shipdiff { font: 11px var(--mono); white-space: pre-wrap; overflow-wrap: anywhere;
    max-height: 300px; overflow-y: auto; background: var(--soft); border-radius: 8px; padding: 8px; margin: 0; }
  .shipfollow { display: grid; gap: 6px; }
  .shipmerged { font-size: 12px; background: var(--ok-soft); border: 1px solid var(--ok-line); border-radius: 8px; padding: 8px; }
  .shipdeps { color: var(--bad); display: flex; gap: 6px; align-items: center; }
  .shiprev code, .shipst code { font: 11px var(--mono); }
  .shipdetails { display: grid; gap: 6px; }
  .shipbox { border: 1px solid var(--line); border-radius: 12px; padding: 12px; display: grid; gap: 10px; }
  .card { display: grid; gap: 12px; font-size: 13px; overflow-wrap: anywhere; min-width: 0; }
  .card .ch { font-size: 12px; font-weight: 650; color: var(--ink2); margin: 0 0 4px; }
  .card ul, .card ol { margin: 0; padding-left: 20px; display: grid; gap: 3px; }
  .card .creq { font-size: 13px; font-weight: 600; margin-top: 4px; }
  .card .cshots { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 6px; }
  .card .cshots img { width: 100%; height: auto; border-radius: 6px; border: 1px solid var(--line); display: block; }
  .card .cvideo { display: grid; gap: 4px; }
  .card .cvideo video { width: 100%; max-height: 300px; border-radius: 10px; background: #111; display: block; object-fit: contain; }
  .card .cdemonote { font-size: 12px; color: var(--warn); background: var(--warn-soft); border-radius: 8px; padding: 6px 8px; }
  .card .cbeta { font-size: 12px; color: var(--ok); background: var(--ok-soft); border-radius: 8px; padding: 6px 8px; margin: 0; }
  .card .flags { list-style: none; padding: 0; gap: 6px; }
  .card .flag { background: var(--warn-soft); border: 1px solid var(--warn-line); border-radius: 8px; padding: 6px 8px; }
  .card .flag b { font-size: 13px; color: var(--warn); display: block; }
  .card .flag code { font: 11px var(--mono); color: var(--muted); }

  /* ---- screenshot + voice composer (long-press / right-click the bubble) ---- */
  .comp .cbody { overflow-y: auto; overflow-x: hidden; padding: 14px; display: grid; grid-template-columns: minmax(0, 1fr); gap: 12px; }
  .comp .hdr { border-bottom: 1px solid var(--line); }
  .shots { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
  .shot { position: relative; width: 84px; height: 60px; border-radius: 8px; overflow: hidden; border: 1px solid var(--line);
    background: #fff; cursor: zoom-in; padding: 0; }
  .shot img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .shot .x { position: absolute; top: 2px; right: 2px; width: 18px; height: 18px; border-radius: 999px; border: 0;
    background: rgba(17,24,39,.75); color: #fff; font-size: 11px; line-height: 18px; cursor: pointer; padding: 0; }
  .shot .pen { position: absolute; left: 3px; bottom: 3px; font-size: 10px; background: rgba(255,255,255,.9);
    color: var(--ink); border-radius: 4px; padding: 0 4px; font-weight: 600; }
  .addshot { width: 84px; height: 60px; border-radius: 8px; border: 1px dashed #c4c4ca; background: var(--soft);
    color: var(--ink2); font: inherit; font-size: 11px; font-weight: 600; cursor: pointer; }
  /* "Screenshot in 3…": never in the way of the page (pointer-events), never in the picture (the panel is filtered out) */
  .countdown { position: fixed; right: var(--chef-right); bottom: var(--chef-bottom); z-index: 2147483003; pointer-events: none;
    padding: 9px 14px; border-radius: 999px; background: rgba(17,24,39,.85); color: #fff; font: 600 13px/1.2 var(--font);
    font-variant-numeric: tabular-nums; box-shadow: 0 8px 24px rgba(0,0,0,.2); }
  .capturing { font-size: 12px; color: var(--muted); display: inline-flex; align-items: center; gap: 6px; }
  .rec { display: flex; align-items: center; gap: 8px; padding: 8px 10px; border-radius: 10px; background: var(--soft); }
  .rec .rdot { width: 10px; height: 10px; border-radius: 999px; background: #dc2626; flex-shrink: 0; animation: chef-pulse 1.2s ease-in-out infinite; }
  .rec .rdot.off { background: var(--faint); animation: none; }
  .rec canvas { flex: 1; min-width: 0; height: 28px; }
  .rec .tm { font-variant-numeric: tabular-nums; font-size: 12px; color: var(--muted); }
  .rec button { border: 1px solid #dcdce0; background: #fff; color: var(--ink); border-radius: 7px; padding: 4px 9px;
    font: inherit; font-size: 12px; font-weight: 600; cursor: pointer; }
  .rec audio { flex: 1; min-width: 0; height: 30px; }
  .err { font-size: 12px; color: var(--bad); }
  .note { font-size: 12px; color: var(--muted); }
  .ann { position: fixed; inset: 0; z-index: 2147483002; background: rgba(17,24,39,.82); display: flex; flex-direction: column;
    align-items: center; justify-content: center; gap: 10px; padding: 16px; font: 13px/1.45 var(--font); }
  .ann canvas { max-width: 100%; max-height: calc(100vh - 90px); background: #fff; border-radius: 6px; cursor: crosshair; touch-action: none; }
  .ann .bar { display: flex; gap: 8px; }
  .ann .bar button { border: 0; border-radius: 8px; padding: 8px 14px; font: inherit; font-weight: 600; cursor: pointer; background: #fff; color: var(--ink); }
  .ann .bar button.ok { background: var(--accent); color: #fff; }
  .ann .hint { color: #fed7aa; font-size: 12px; }

  .toast { position: fixed; right: var(--chef-right); bottom: calc(var(--chef-bottom) + 64px); z-index: 2147483003; padding: 9px 14px; border-radius: 10px;
    background: #111827; color: #fff; font: 600 13px/1.3 var(--font); max-width: calc(100vw - 32px);
    box-shadow: 0 8px 24px rgba(0,0,0,.2); animation: chef-in 160ms ease-out; }

  /* ---- "What's new" card (above the launcher; fixed, so the page never shifts) ---- */
  .wn { position: fixed; right: var(--chef-right); bottom: calc(var(--chef-bottom) + 64px); z-index: 2147483000;
    width: 320px; max-width: calc(100vw - 32px); max-height: min(420px, calc(100vh - var(--chef-bottom) - 96px));
    display: flex; flex-direction: column; overflow: hidden; font: 13px/1.45 var(--font);
    color: var(--ink); background: #fff; border: 1px solid #e5e7eb; border-radius: 14px;
    box-shadow: 0 16px 40px rgba(0,0,0,.16), 0 4px 10px rgba(0,0,0,.08); animation: chef-in 180ms ease-out; }
  .wn[hidden] { display: none; }
  .wn .wh { display: flex; align-items: center; gap: 8px; padding: 11px 12px 6px 14px; }
  .wn .wh .brand { height: 20px; width: auto; display: block; flex-shrink: 0; }
  .wn .wh .spark { width: 18px; height: 18px; color: var(--accent); flex-shrink: 0; }
  .wn .wh b { flex: 1; min-width: 0; font-size: 14px; font-weight: 700; color: #111827; }
  .wn .wx { flex-shrink: 0; width: 28px; height: 28px; border: 0; border-radius: 8px; cursor: pointer;
    background: transparent; color: var(--muted); font-size: 18px; line-height: 1; display: grid; place-items: center; }
  .wn .wx:hover { background: var(--soft); color: #111827; }
  .wn ul { list-style: none; margin: 0; padding: 2px 14px 4px; overflow-y: auto; display: grid; gap: 8px; }
  .wn li { display: grid; grid-template-columns: 8px minmax(0, 1fr); gap: 0 9px; }
  .wn li::before { content: ""; width: 6px; height: 6px; border-radius: 999px; background: var(--accent); margin-top: 7px; }
  .wn li .wt { color: var(--ink); overflow-wrap: anywhere; }
  .wn li .wd { grid-column: 2; font-size: 11px; color: var(--muted); }
  .wn .wm { padding: 2px 14px 0 31px; font-size: 12px; color: var(--muted); }
  .wn .wf { padding: 10px 14px 12px; }
  .wn .wf button.act { width: 100%; }

  @keyframes chef-spin { to { transform: rotate(360deg); } }
  @keyframes chef-pulse { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: .55; transform: scale(1.15); } }
  @keyframes chef-in { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }
  @media (prefers-reduced-motion: reduce) { .wn, .toast { animation: none; } .spin { animation-duration: 2s; } }
`;

const Base = typeof HTMLElement === "undefined" ? class {} : HTMLElement;

export class ChefPanelElement extends Base {
  connectedCallback() {
    this.applyOffsets();
    if (this.shadowRoot) {
      // Re-attached: keep state; reconnect if a real removal closed the client.
      const url = this.getAttribute("convex-url");
      if (!this.client && url) ChefPanelElement.loadConvex().then((lib) => this.connect(lib, url)).catch(() => {});
      return;
    }
    // NB: `this.prefix` is a read-only DOM getter on Element — use fnPrefix.
    this.fnPrefix = this.getAttribute("prefix") || "chef";
    this.open = this.getAttribute("open") === "1"; // start minimized by default
    this.snap = { todos: [], progress: [], refinements: [] };
    this.requests = [];
    this.mineList = [];
    this.pending = []; // awaiting approval (admins only; [] for everyone else)
    this.answered = {}; // qid -> answer (optimistic, until the agent resolves it)
    this.reviewed = {}; // id -> true (optimistic, until the list updates)
    this.attachments = {}; // itemId -> [{ kind, url, mimeType }]
    // Screenshot + voice requests need generateUploadUrl / submitRequestWithMedia /
    // listAttachments. null = unknown, true = present, false = missing.
    this.mediaOk = null;
    this.flash = "";
    this.draftKey = `chef-panel:draft:${this.fnPrefix}`;
    this.admin = false; // from the server's amAdmin; non-admins never see Chef chrome
    this.me = null; // from whoAmI: the caller's Chef user id, so an owner can make themselves admin
    // Snapshot approval in progress: { id, snapshotId, contentHash, snapshot, busy, error }.
    this.approving = null;
    // Cloud builds (admins only): the newest runs, and the one that's open.
    this.runs = [];
    this.build = null; // { runId, run, shots, notes, asks, logOpen, logPages: [{ cursor, data }], busy }
    this.loginUsed = {}; // runId -> true once its one-time preview sign-in link was opened
    // buildState (admins only): { cloudEnabled, workerKeys, autoBuild, queued, busy }, or null
    // when the host doesn't export it. "Build in cloud" shows only with cloudEnabled.
    this.buildState = null;
    this.buildBusy = false;
    // What Chef knows about this app (admins only): appLearnings and buildCosts, when the host exports them.
    this.learnings = null;
    this.costs = [];
    this.learnOpen = false;
    // previewDataMode (admins only, when the host exports it): { mode: "demo" | "admin-copy", mine }.
    this.previewData = null;
    this.previewDataBusy = false;
    this.briefOpen = false;
    // "Ship it" (admins only): the candidate, and the diff review once opened.
    // `card`: the plain-language Ship card (buildCard), shown first; the diff
    // loads only when its "Details" are opened.
    this.ship = { candidate: null, card: null, open: false, details: false, deps: false, busy: false, error: "", chunks: {}, unsubs: [] };
    this.memberLabel = this.getAttribute("member-label") || this.getAttribute("label") || DEFAULT_MEMBER_LABEL;
    this.tab = readTab(this.fnPrefix); // admins' open tab: "now" | "builds" | "requests"

    const root = this.attachShadow({ mode: "open" });
    root.innerHTML = `<style>${CSS}</style><div class="wrap"></div>`;
    this.$wrap = root.querySelector(".wrap");

    const url = this.getAttribute("convex-url");
    if (!url) { this.$wrap.textContent = "chef-panel: missing convex-url"; return; }
    this.render();
    ChefPanelElement.loadConvex().then((lib) => this.connect(lib, url)).catch((e) => {
      this.$wrap.textContent = `chef-panel: couldn't load Convex (${errMsg(e)})`;
    });
  }

  connect({ ConvexClient, makeFunctionReference }, url) {
    if (!this.isConnected || this.client) return;
    this._attKey = null;
    this.ref = (name) => makeFunctionReference(`${this.fnPrefix}:${name}`);
    this.client = new ConvexClient(url);
    if (this._fetchToken) this.client.setAuth(this._fetchToken);
    const watch = (name, args, onValue) =>
      this.client.onUpdate(this.ref(name), args, onValue, (e) => {
        if (!isMissingFn(e)) console.warn(`chef-panel: ${this.fnPrefix}:${name}`, e);
      });
    watch("agentState", {}, (s) => { this.snap = s || this.snap; this.render(); });
    watch("listPublicItems", {}, (r) => {
      this.requests = (r && r.page) || r || []; this.watchAttachments(); this.render();
    });
    watch("mine", {}, (r) => { this.mineList = r || []; this.render(); });
    watch("awaitingApproval", {}, (r) => { this.pending = r || []; this.render(); });
    watch("amAdmin", {}, (r) => { this.admin = r === true; this.watchRuns(); this.render(); });
    // Optional (hosts that don't export whoAmI just don't show the id).
    watch("whoAmI", {}, (r) => { this.me = (r && typeof r.userId === "string") ? r.userId : null; this.render(); });
    this.checkWhatsNew();
    // Feature-detect the media functions with a harmless query.
    this.client.query(this.ref("listAttachments"), { itemIds: [] })
      .then(() => { this.mediaOk = true; this.watchAttachments(); this.render(); })
      .catch((e) => { this.mediaOk = !isMissingFn(e); this.render(); });
  }

  // Subscribe and get back a plain unsubscribe function.
  sub(name, args, onValue) {
    const u = this.client.onUpdate(this.ref(name), args, onValue, (e) => {
      if (!isMissingFn(e)) console.warn(`chef-panel: ${this.fnPrefix}:${name}`, e);
    });
    return typeof u === "function" ? u : u && u.unsubscribe ? () => u.unsubscribe() : () => {};
  }

  // Cloud builds are admin chrome: only admins subscribe to them.
  watchRuns() {
    if (!this.client) return;
    if (this.admin && !this._runsUnsub) {
      this._runsUnsub = this.sub("recentRuns", { limit: 10 }, (r) => { this.runs = r || []; this.render(); });
      this._shipUnsub = this.sub("shipCandidate", {}, (c) => { this.ship.candidate = c || null; this.render(); });
      this._cardUnsub = this.sub("buildCard", {}, (c) => { this.ship.card = c || null; this.render(); });
      this._stateUnsub = this.sub("buildState", {}, (b) => { this.buildState = b || null; this.render(); });
      this._learnUnsub = this.sub("appLearnings", {}, (l) => { this.learnings = l || null; this.render(); });
      this._costUnsub = this.sub("buildCosts", { limit: 20 }, (c) => { this.costs = c || []; this.render(); });
      this._pdUnsub = this.sub("previewDataMode", {}, (m) => { this.previewData = m || null; this.render(); });
    } else if (!this.admin && this._runsUnsub) {
      this._runsUnsub(); this._runsUnsub = null; this.runs = []; this.closeBuild();
      if (this._learnUnsub) { this._learnUnsub(); this._learnUnsub = null; }
      if (this._costUnsub) { this._costUnsub(); this._costUnsub = null; }
      this.learnings = null; this.costs = [];
      if (this._pdUnsub) { this._pdUnsub(); this._pdUnsub = null; }
      this.previewData = null;
      if (this._stateUnsub) { this._stateUnsub(); this._stateUnsub = null; }
      this.buildState = null;
      if (this._shipUnsub) { this._shipUnsub(); this._shipUnsub = null; }
      if (this._cardUnsub) { this._cardUnsub(); this._cardUnsub = null; }
      this.closeShip(); this.ship.candidate = null; this.ship.card = null;
    }
  }

  openBuild(runId) {
    this.closeBuild();
    const b = { runId, run: undefined, card: null, shots: [], notes: [], asks: [], logOpen: false, logPages: [], unsubs: [], busy: null, error: "", retryBusy: false, retryNote: "" };
    this.build = b;
    const first = { numItems: 50, cursor: null };
    b.unsubs.push(
      this.sub("runStatus", { runId }, (r) => { b.run = r; this.render(); }),
      this.sub("runScreenshots", { runId }, (r) => { b.shots = r || []; this.render(); }),
      this.sub("skillFeedback", { runId, paginationOpts: first }, (r) => { b.notes = (r && r.page) || []; this.render(); }),
      this.sub("approvalRequests", { runId, paginationOpts: first }, (r) => { b.asks = (r && r.page) || []; this.render(); }),
      this.sub("buildCard", { runId }, (c) => { b.card = c || null; this.render(); }),
    );
    this.render();
  }

  closeBuild() {
    if (!this.build) return;
    for (const u of this.build.unsubs) u();
    for (const p of this.build.logPages) if (p.unsub) p.unsub();
    this.build = null;
  }

  // The run log, a page at a time; nothing is fetched until it's opened.
  loadLogPage(cursor) {
    const b = this.build;
    if (!b) return;
    const page = { cursor, data: undefined, unsub: null };
    b.logPages.push(page);
    page.unsub = this.sub("runLogs", { runId: b.runId, cursor }, (r) => { page.data = r; this.render(); });
    this.render();
  }

  toggleLog() {
    const b = this.build;
    if (!b) return;
    b.logOpen = !b.logOpen;
    if (b.logOpen) this.loadLogPage(null);
    else { for (const p of b.logPages) if (p.unsub) p.unsub(); b.logPages = []; this.render(); }
  }

  decideSpend(id, approve) {
    const b = this.build;
    if (!b) return;
    b.busy = id; b.error = ""; this.render();
    this.client.mutation(this.ref(approve ? "approveApprovalRequest" : "declineApprovalRequest"), { id })
      .catch((e) => { b.error = errMsg(e); })
      .finally(() => { b.busy = null; this.render(); });
  }

  // Approve: snapshot the request, show the snapshot in full, then approve its hash.
  startApproval(id) {
    this.cancelApproval();
    const a = { id, snapshotId: null, contentHash: null, snapshot: undefined, busy: true, error: "", unsub: null };
    this.approving = a; this.flash = ""; this.render();
    this.client.mutation(this.ref("prepareApproval"), { id }).then((r) => {
      if (this.approving !== a) return;
      a.snapshotId = r.snapshotId; a.contentHash = r.contentHash; a.busy = false;
      a.unsub = this.sub("approvalSnapshot", { snapshotId: r.snapshotId }, (snap) => { a.snapshot = snap; this.render(); });
      this.render();
    }).catch((e) => {
      if (this.approving !== a) return;
      a.busy = false; a.error = isUnauth(e) ? "Sign in to approve." : errMsg(e); this.render();
    });
  }

  cancelApproval() {
    if (this.approving && this.approving.unsub) this.approving.unsub();
    this.approving = null;
  }

  approveAndBuild() {
    const a = this.approving;
    if (!a || !a.snapshot || a.busy) return;
    a.busy = true; a.error = ""; this.render();
    // The hash of what was shown, not of the request as it is now.
    this.client.mutation(this.ref("approveSnapshot"), { snapshotId: a.snapshot.snapshotId, contentHash: a.snapshot.contentHash })
      .then(() => {
        this.reviewed[a.id] = true;
        this.cancelApproval();
        this.render();
        const st = this.buildState;
        this.showToast(st && !st.cloudEnabled
          ? (st.workerKeys ? "Approved. A local worker (npx chef work) will build it." : "Approved. Cloud builds are off; start npx chef work to build it.")
          : st && st.cloudEnabled && !st.autoBuild ? "Approved. Press Build in cloud to build it." : "Approved. Chef will build it.");
      })
      .catch((e) => { a.busy = false; a.error = errMsg(e); this.render(); });
  }

  // "Try again" on a failed build: the same approved text, re-approved and
  // built in one step; a changed request goes through the normal approval.
  retryRun() {
    const b = this.build;
    if (!b || !b.run || b.retryBusy) return;
    const itemId = b.run.itemId;
    b.retryBusy = true; b.retryNote = ""; this.render();
    this.client.mutation(this.ref("retryRun"), { itemId })
      .then((r) => {
        if (r && r.outcome === "needsApproval") {
          b.retryNote = "The request changed since you approved it: approve the new text.";
          this.startApproval(itemId);
        } else if (r && r.outcome === "started") {
          b.retryNote = r.claim === "claimed" ? "Started again." : r.claim === "planning" ? "Starting: Chef is grouping it with related requests."
            : "Queued: it starts when the current build finishes.";
          this.showToast(b.retryNote);
        } else b.retryNote = (r && r.reason) || "Not started.";
      })
      .catch((e) => { b.retryNote = errMsg(e); })
      .finally(() => { b.retryBusy = false; this.render(); });
  }

  forgetLearning(id) {
    this.client.mutation(this.ref("forgetLearning"), { id }).catch((e) => { this.flash = errMsg(e); this.render(); });
  }

  // "Build in cloud": claim the oldest approved request for a cloud build now.
  buildInCloud() {
    if (this.buildBusy) return;
    const next = this.upNext()[0];
    this.buildBusy = true; this.flash = ""; this.render();
    this.client.mutation(this.ref("buildInCloud"), {})
      .then((r) => {
        const o = r && r.outcome;
        this.showToast(o === "claimed" ? (next ? `Cloud build started: ${requestName(next)}.` : "Cloud build started.") : o === "busy" ? "A build is already running." : o === "reconciling" ? "The last build is still being cleaned up." : o === "empty" ? "Nothing approved is waiting." : o === "planning" ? "Chef is grouping related requests; the build starts in a moment." : `Not started: ${(r && r.reason) || o}`);
      })
      .catch((e) => { this.flash = errMsg(e); })
      .finally(() => { this.buildBusy = false; this.render(); });
  }

  // "Ship it": open the review, which loads the whole diff, chunk by chunk.
  openShip() {
    const c = this.ship.candidate;
    const run = c && c.run;
    if (!run || !run.diff) return;
    this.closeShip();
    this.ship.open = true; this.ship.deps = false; this.ship.error = "";
    this.render();
  }

  // "Details": the whole diff, chunk by chunk, fetched only once opened.
  toggleShipDetails() {
    const s = this.ship;
    const run = s.candidate && s.candidate.run;
    if (!run || !run.diff) return;
    s.details = !s.details;
    if (s.details) {
      for (let i = 0; i < run.diff.chunkCount; i++) {
        s.unsubs.push(this.sub("shipDiffChunk", { runId: run.runId, index: i }, (r) => {
          s.chunks[i] = r === undefined ? undefined : r; this.render();
        }));
      }
    } else {
      for (const u of s.unsubs) u();
      s.unsubs = []; s.chunks = {};
    }
    this.render();
  }

  closeShip() {
    for (const u of this.ship.unsubs) u();
    this.ship.unsubs = []; this.ship.chunks = {}; this.ship.open = false; this.ship.details = false;
  }

  // "Ship to live": approve exactly the diff shown, by its hash. Also "Try again".
  shipToLive(args) {
    const s = this.ship;
    if (s.busy) return;
    s.busy = true; s.error = ""; this.render();
    this.client.mutation(this.ref("shipApprove"), args)
      .then((r) => {
        if (!r || !r.approved) { s.error = (r && r.reason) || "Refused"; return; }
        if (r.started === false) { s.error = "Approved, but the app has no shipper set up (setShipper)."; return; }
        this.closeShip();
        this.showToast(`Shipping release #${r.seq}.`);
      })
      .catch((e) => { s.error = errMsg(e); })
      .finally(() => { s.busy = false; this.render(); });
  }

  // "Chef can fix this": apply a repair commit by the sha shown.
  applyRepair(repairId, sha) {
    const b = this.build;
    if (!b || b.busy) return;
    b.busy = repairId; b.error = ""; this.render();
    this.client.mutation(this.ref("applyRepair"), { repairId, sha })
      .then((r) => { if (r && !r.applying) b.error = r.reason || "Refused"; else this.showToast("Applying the fix, then building again."); })
      .catch((e) => { b.error = errMsg(e); })
      .finally(() => { b.busy = null; this.render(); });
  }

  // Main moved and merging it in failed: build the request again on the new main.
  shipRebuild(itemId) {
    const s = this.ship;
    if (s.busy) return;
    s.busy = true; s.error = ""; this.render();
    this.client.mutation(this.ref("retryRun"), { itemId })
      .then((r) => {
        if (!r || r.outcome === "refused") { s.error = (r && r.reason) || "Refused"; return; }
        this.showToast(r.outcome === "started" ? "Building it again on the new main." : "The request changed: approve it again.");
      })
      .catch((e) => { s.error = errMsg(e); })
      .finally(() => { s.busy = false; this.render(); });
  }

  disconnectedCallback() {
    // Only tear down if we're really gone (not just moved in the DOM).
    queueMicrotask(() => {
      if (this.isConnected) return;
      if (this.$comp) this.closeComposer();
      this.cancelApproval();
      this.closeBuild();
      this.closeShip();
      if (this._runsUnsub) { this._runsUnsub(); this._runsUnsub = null; }
      if (this._shipUnsub) { this._shipUnsub(); this._shipUnsub = null; }
      if (this._cardUnsub) { this._cardUnsub(); this._cardUnsub = null; }
      if (this._stateUnsub) { this._stateUnsub(); this._stateUnsub = null; }
      this.closeWhatsNew(false);
      if (this.client) { this.client.close(); this.client = null; }
    });
  }

  /**
   * Hand the panel a token fetcher so calls arrive authenticated (the server
   * then knows who is filing). Same signature as ConvexClient.setAuth:
   * ({ forceRefreshToken }) => Promise<string|null>. Safe to call any time.
   */
  setAuth(fetchToken) {
    this._fetchToken = fetchToken;
    if (this.client) this.client.setAuth(fetchToken);
  }

  /** Drop the auth token (signed out). */
  clearAuth() {
    this._fetchToken = null;
    if (this.client) this.client.setAuth(async () => null);
  }

  watchAttachments() {
    if (!this.mediaOk || !this.client) return;
    const ids = (this.requests || []).map((r) => r._id || r.id).filter(Boolean).slice(0, 50);
    const key = ids.join(",");
    if (key === this._attKey) return;
    this._attKey = key;
    if (this._attUnsub) { this._attUnsub(); this._attUnsub = null; }
    if (!ids.length) { this.attachments = {}; return; }
    const unsub = this.client.onUpdate(this.ref("listAttachments"), { itemIds: ids }, (rows) => {
      const m = {};
      for (const r of rows || []) m[r.itemId] = r.attachments || [];
      this.attachments = m;
      this.render();
    }, () => {});
    this._attUnsub = typeof unsub === "function" ? unsub : unsub && unsub.unsubscribe ? () => unsub.unsubscribe() : null;
  }

  static get observedAttributes() { return ["member-label", "label", "offset-bottom", "offset-right", "whats-new"]; }
  /** `offset-bottom` / `offset-right` (px): lift the button and panel clear of the host's own controls. */
  applyOffsets() {
    const px = (v) => (v && /^\d+(\.\d+)?$/.test(v) ? `${v}px` : v);
    const b = this.getAttribute("offset-bottom");
    const r = this.getAttribute("offset-right");
    if (b) this.style.setProperty("--chef-bottom", px(b)); else this.style.removeProperty("--chef-bottom");
    if (r) this.style.setProperty("--chef-right", px(r)); else this.style.removeProperty("--chef-right");
  }
  attributeChangedCallback() {
    this.applyOffsets();
    if (this.getAttribute("whats-new") === "off") this.closeWhatsNew(false);
    this.memberLabel = this.getAttribute("member-label") || this.getAttribute("label") || DEFAULT_MEMBER_LABEL;
    if (this.$wrap) this.render();
  }

  /** The brand mark: Chef for admins, a neutral lightbulb for everyone else. */
  mark() { return this.admin ? BRAND : BULB; }
  sentMessage() { return this.admin ? "Sent to Chef" : "Your request was sent"; }

  // ------------------------------------------------------------ what's new

  /**
   * Once per page load: compare what shipped against what this browser last saw.
   * First visit → just remember "now" (no backlog dump). Old backends without
   * `whatsNew` (or any failure) → silently skip.
   */
  checkWhatsNew() {
    if (this._wnChecked || this.getAttribute("whats-new") === "off") return;
    this._wnChecked = true;
    const key = `chef-whatsnew-seen:${this.fnPrefix}`;
    let since;
    try {
      const raw = localStorage.getItem(key);
      since = raw == null ? NaN : Number(raw);
      if (!Number.isFinite(since)) { localStorage.setItem(key, String(Date.now())); return; }
    } catch { return; } // storage blocked: we couldn't remember a dismissal, so never nag
    const fetchedAt = Date.now();
    this.client.query(this.ref("whatsNew"), { since })
      .then((rows) => {
        if (!Array.isArray(rows) || !rows.length || !this.isConnected || this.getAttribute("whats-new") === "off") return;
        this.showWhatsNew(rows, () => { try { localStorage.setItem(key, String(fetchedAt)); } catch { /* storage blocked: it shows again next time */ } });
      })
      .catch(() => {});
  }

  showWhatsNew(rows, markSeen) {
    if (!this.shadowRoot) return;
    this.closeWhatsNew(false);
    const MAX = 6;
    const shown = rows.slice(0, MAX);
    const more = rows.length - shown.length;
    const el = document.createElement("div");
    el.className = "wn";
    el.setAttribute("role", "region");
    el.setAttribute("aria-label", "What's new");
    el.setAttribute("aria-live", "polite");
    el.innerHTML = `
      <div class="wh"><span class="wmark"></span><b>What's new</b>
        <button class="wx" type="button" aria-label="Close what's new" title="Close">×</button></div>
      <ul>${shown.map((r) => `<li><span class="wt">${esc(r.text)}</span><span class="wd">${esc(relTime(r.at))}</span></li>`).join("")}</ul>
      ${more > 0 ? `<div class="wm">and ${more} more</div>` : ""}
      <div class="wf"><button class="act" type="button">Got it</button></div>`;
    this._wnSeen = markSeen;
    el.querySelector(".wx").onclick = () => this.closeWhatsNew(true);
    el.querySelector(".act").onclick = () => this.closeWhatsNew(true);
    this._wnKey = (e) => { if (e.key === "Escape" && this.$wn && !this.$wn.hidden && !this.$comp && !this.$ann) this.closeWhatsNew(true); };
    document.addEventListener("keydown", this._wnKey);
    this.shadowRoot.appendChild(el);
    this.$wn = el;
    this.syncWhatsNew();
  }

  /** Remove the card; `seen` records the dismissal so it won't come back. */
  closeWhatsNew(seen) {
    if (this._wnKey) { document.removeEventListener("keydown", this._wnKey); this._wnKey = null; }
    if (seen && this._wnSeen) this._wnSeen();
    this._wnSeen = null;
    if (this.$wn) { this.$wn.remove(); this.$wn = null; }
  }

  /** Keep the card's mark in step with the viewer's role; tuck it away while the panel/composer is up. */
  syncWhatsNew() {
    const el = this.$wn;
    if (!el) return;
    el.hidden = !!(this.open || this.$comp || this.$ann);
    const mark = el.querySelector(".wmark");
    const want = this.admin ? "admin" : "member";
    if (mark && mark.dataset.kind !== want) {
      mark.dataset.kind = want;
      mark.innerHTML = this.admin ? BRAND : SPARK;
    }
  }

  showToast(msg) {
    if (!this.shadowRoot) return;
    if (this.$toast) this.$toast.remove();
    const el = document.createElement("div");
    el.className = "toast"; el.setAttribute("role", "status"); el.textContent = msg;
    this.shadowRoot.appendChild(el); this.$toast = el;
    setTimeout(() => { el.remove(); if (this.$toast === el) this.$toast = null; }, 3000);
  }

  // Mutations surface their errors inline ("Sign in to …", "Item is under review", …).
  call(name, args) {
    if (!this.client) return Promise.reject(new Error("Not connected yet"));
    return this.client.mutation(this.ref(name), args).catch((e) => {
      this.flash = isUnauth(e) ? "Sign in to send a request." : errMsg(e);
      this.render();
      throw e;
    });
  }

  openQuestions() {
    if (!this.admin) return [];
    // Exclude server-resolved states AND optimistically-answered ones, so the
    // header count, bubble dot, and asking section drop the moment the user
    // answers — not only once the agent flips the server state.
    return (this.snap.refinements || []).filter(
      (r) =>
        r.state !== "rejected" &&
        r.state !== "completed" &&
        r.state !== "answered" &&
        r.state !== "skipped" &&
        !this.answered[r._id || r.id],
    );
  }
  openApprovals() {
    if (!this.admin) return [];
    return (this.pending || []).filter((p) => !this.reviewed[p.id]);
  }
  isBuilding() {
    if (!this.admin) return false;
    const t = this.snap.todos || [];
    return t.some((x) => x.status === "active") || (t.length > 0 && t.some((x) => x.status !== "done"));
  }

  render() {
    if (!this.$wrap) return;
    // Don't cut off a voice note someone is listening to; re-render when it stops.
    const playing = Array.from(this.$wrap.querySelectorAll("audio")).find((a) => !a.paused);
    if (playing) {
      if (!this._deferred) {
        this._deferred = true;
        playing.addEventListener("pause", () => { this._deferred = false; this.render(); }, { once: true });
      }
      return;
    }
    this.syncWhatsNew();
    if (!this.open) return this.renderFab();
    this.renderPanel();
  }

  renderFab() {
    const building = this.isBuilding();
    const badge = this.openQuestions().length + this.openApprovals().length;
    this.$wrap.innerHTML = `
      <button class="fab ${building ? "building" : ""} ${this.admin ? "" : "member"}" id="fab"
        aria-label="${esc(this.admin ? "Open Chef panel" : this.memberLabel)}" title="${esc(this.admin ? "Chef" : this.memberLabel)}">
        ${this.admin ? BRAND : `${BULB}<span class="lab">${esc(this.memberLabel)}</span>`}
        ${building ? `<span class="spin"></span>` : ""}
        ${badge > 0 ? `<span class="dot">${badge}</span>` : ""}
        ${this.mediaOk ? `<span class="mic" id="fabmic" title="Screenshot + voice note"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 17v5"/></svg></span>` : ""}
      </button>`;
    const fab = this.$wrap.querySelector("#fab");
    let timer = null, fired = false, x0 = 0, y0 = 0;
    const cancel = () => { if (timer) clearTimeout(timer); timer = null; fab.classList.remove("pressing"); };
    fab.addEventListener("pointerdown", (e) => {
      if (this.mediaOk === false || e.button > 0) return;
      fired = false; x0 = e.clientX; y0 = e.clientY;
      fab.classList.add("pressing");
      timer = setTimeout(() => { timer = null; fired = true; fab.classList.remove("pressing"); this.startMediaRequest(); }, LONG_PRESS_MS);
    });
    fab.addEventListener("pointermove", (e) => { if (timer && Math.hypot(e.clientX - x0, e.clientY - y0) > 10) cancel(); });
    fab.addEventListener("pointerup", cancel);
    fab.addEventListener("pointerleave", cancel);
    fab.addEventListener("pointercancel", cancel);
    fab.addEventListener("contextmenu", (e) => {
      if (this.mediaOk === false) return; // keep the native menu when media isn't available
      e.preventDefault();
      if (!fired) { cancel(); fired = true; this.startMediaRequest(); }
    });
    fab.onclick = (e) => {
      if (fired) { e.preventDefault(); fired = false; return; } // the long-press already acted
      if (e.target.closest && e.target.closest("#fabmic")) { e.preventDefault(); this.startMediaRequest(); return; }
      this.open = true; this.render();
    };
    if (this.mediaOk) fab.title = `${this.admin ? "Chef" : this.memberLabel} — long-press (or right-click) to send a screenshot + voice note`;
  }

  // The cloud build that holds the slot, if any (from recentRuns).
  activeRun() {
    return (this.runs || []).find((r) => isRunning(r.status)) || null;
  }
  // The requests being built right now: the active run's, and the rest of its
  // batch. Any other `inProgress` request is built and waiting for Ship it.
  buildingIds() {
    const ids = new Set();
    const run = this.activeRun();
    if (run && run.itemId) ids.add(String(run.itemId));
    for (const b of this.batches()) {
      if (b.status !== "building" && !(run && b.runId && String(b.runId) === String(run.runId))) continue;
      for (const it of b.items || []) ids.add(String(it.itemId));
    }
    return ids;
  }
  // What builds next, in order (buildState.upNext; [] on hosts that don't send it).
  upNext() {
    return (this.buildState && Array.isArray(this.buildState.upNext)) ? this.buildState.upNext : [];
  }

  // The batches waiting, building, or built and not shipped (buildState.batches; [] on older hosts).
  batches() {
    return (this.buildState && Array.isArray(this.buildState.batches)) ? this.buildState.batches : [];
  }

  // "Built together with #2, #3" for a request in a batch, or "".
  builtWith(itemId) {
    const b = this.batches().find((x) => x.items.some((it) => String(it.itemId) === String(itemId)));
    if (!b) return "";
    const others = b.items.filter((it) => String(it.itemId) !== String(itemId)).map((it) => `#${it.number}`);
    return others.length ? `${b.status === "planned" ? "Will be built" : "Built"} together with ${others.join(", ")}` : "";
  }

  // Split a request out of a batch that hasn't started building.
  splitFromBatch(itemId) {
    this.call("splitFromBatch", { itemId })
      .then(() => this.showToast("Split out: Chef builds it on its own."))
      .catch(() => {});
  }
  costOf(runId) {
    return (this.costs || []).find((c) => String(c.runId) === String(runId)) || null;
  }

  // Admins: "now" (what needs you), "builds", "requests". Members have no tabs.
  currentTab() {
    if (!this.admin) return "requests";
    return TABS.includes(this.tab) ? this.tab : "now";
  }
  setTab(tab) {
    this.tab = tab;
    writeTab(this.fnPrefix, tab);
    this.render();
  }

  renderPanel() {
    const building = this.isBuilding();
    const open = this.openQuestions();
    const approvals = this.openApprovals();
    const admin = this.admin;
    const active = admin ? this.activeRun() : null;

    // Something new needs you: show it, whatever tab was open.
    const attention = approvals.length + open.length;
    if (admin && attention > (this._seenAttention || 0)) this.tab = "now";
    this._seenAttention = attention;
    const tab = this.currentTab();

    let title, subtitle;
    if (!admin) {
      title = "Request a feature";
      subtitle = esc("Tell us what would make this better.");
    } else if (open.length > 0) {
      title = `Chef is asking (${open.length})`;
      subtitle = esc("Answer below so the build can go on.");
    } else if (approvals.length > 0) {
      title = `${approvals.length} waiting for approval`;
      subtitle = esc("Nothing gets built until you approve it.");
    } else if (active) {
      const c = this.costOf(active.runId);
      title = `Building: ${active.title || `build #${active.seq}`}`;
      subtitle = `<span class="spin"></span>${esc([`#${active.seq}`, active.statusText, c ? `${fmtUsd(c.spendUsd)} so far` : ""].filter(Boolean).join(" · "))}`;
    } else {
      const next = this.upNext()[0];
      title = "Chef";
      subtitle = building ? `<span class="spin"></span>${esc("Working on your app…")}`
        : esc(next ? `Up next: ${requestName(next)}` : "Ask for a feature or a fix below.");
    }

    // Keep what's been typed (and the caret) across re-renders.
    const prev = {};
    for (const id of ["rt", "ans"]) {
      const el = this.$wrap.querySelector(`#${id}`);
      if (el) prev[id] = { value: el.value, focused: this.shadowRoot.activeElement === el, start: el.selectionStart, end: el.selectionEnd };
    }
    const prevTab = this._renderedTab;
    const scroll = this.$wrap.querySelector(".body")?.scrollTop ?? 0;

    const tabBtn = (id, label, extra) =>
      `<button class="tab" role="tab" data-tab="${id}" aria-selected="${tab === id ? "true" : "false"}">${label}${extra || ""}</button>`;
    const nowCount = attention + (this.shipReady() ? 1 : 0);
    const tabs = admin ? `<div class="tabs" role="tablist">
        ${tabBtn("now", "Now", nowCount ? `<span class="n hot">${nowCount}</span>` : "")}
        ${tabBtn("builds", "Builds", active ? `<span class="spin"></span>` : "")}
        ${tabBtn("requests", "Requests", "")}
      </div>` : "";

    this.$wrap.innerHTML = `
      <div class="bubble">
        <div class="hdr ${admin ? "" : "member"}">
          ${this.mark()}
          <div class="ttl"><b>${esc(title)}</b><span>${subtitle}</span></div>
          <button class="min" id="min" aria-label="Minimize" title="Minimize">▾</button>
        </div>
        ${tabs}
        <div class="body" role="tabpanel"></div>
        ${this.composerFoot()}
      </div>`;
    this.$wrap.querySelector("#min").onclick = () => { this.open = false; this.flash = ""; this.render(); };
    this.$wrap.querySelectorAll("[data-tab]").forEach((b) => b.onclick = () => this.setTab(b.dataset.tab));
    this.$body = this.$wrap.querySelector(".body");

    const sections = [];
    if (this.flash) sections.push(`<div class="flash">${esc(this.flash)}</div>`);
    if (!admin) sections.push(this.sectionMemberRequest());
    else if (tab === "now") sections.push(...this.tabNow({ open, approvals, active, building }));
    else if (tab === "builds") sections.push(...this.tabBuilds());
    else sections.push(this.sectionRequest());
    this.$body.innerHTML = sections.join("");
    this._renderedTab = tab;

    this.wireApprovals();
    this.wireShip();
    this.wireCloudBuilds();
    this.wireAsking(open);
    this.wireRequest();

    for (const [id, p] of Object.entries(prev)) {
      const el = this.$wrap.querySelector(`#${id}`);
      if (!el) continue;
      el.value = p.value;
      if (p.focused) { el.focus(); try { el.setSelectionRange(p.start, p.end); } catch { /* not a text input */ } }
    }
    const rt = this.$wrap.querySelector("#rt");
    if (rt && !prev.rt) rt.value = readDraft(this.draftKey);
    if (rt) fitTextarea(rt);
    this.$body.scrollTop = prevTab === tab ? scroll : 0;
  }

  // ---- tabs ----

  // Now: what needs you (approvals, questions, a build to ship), then what's building.
  tabNow({ open, approvals, active, building }) {
    const out = [];
    if (approvals.length) out.push(this.sectionApprovals(approvals));
    if (open.length || Object.keys(this.answered).length) out.push(this.sectionAsking(open));
    if (this.ship.candidate && (this.ship.candidate.run || this.ship.candidate.release)) out.push(this.sectionShip());
    if (active) {
      out.push(`<section><div class="lbl">Building now</div><div class="list">${this.runRow(active)}</div></section>`);
    }
    const plan = this.sectionBuild(building);
    if (plan) out.push(plan);
    if (!out.length) {
      const next = this.upNext();
      out.push(`<div class="empty"><b>Nothing needs you right now.</b>
        <span>${next.length ? `${esc(`Up next: ${requestName(next[0])}`)}${next.length > 1 ? esc(`, then ${next.length - 1} more`) : ""}.`
          : "Ask Chef for a feature or a fix below. You'll approve it before anything is built."}</span>
        ${this.runs.length ? `<button class="link" data-tab-go="builds">See recent builds</button>` : ""}</div>`);
    }
    return out;
  }

  // Builds: what they cost, what's next, the recent builds, and the build settings.
  tabBuilds() {
    const out = [];
    const costs = this.costs || [];
    if (costs.length) {
      const total = costs.reduce((s, c) => s + (Number.isFinite(c.spendUsd) ? c.spendUsd : 0), 0);
      out.push(`<div class="stat rcosts" title="${esc(costTotalsLine(costs))}">
        <div><b>${esc(fmtUsd(total))}</b><span>last ${costs.length} build${costs.length === 1 ? "" : "s"}</span></div>
        <div><b>${esc(fmtUsd(total / costs.length))}</b><span>per build</span></div>
        <div><b>${esc(String(costs.filter((c) => c.status === "built").length))} of ${costs.length}</b><span>succeeded</span></div>
      </div>`);
    }
    out.push(this.sectionQueue());
    if (this.runs.length || this.showBuildInCloud()) out.push(this.sectionCloudBuilds());
    const settings = this.previewDataHtml() + this.learningsHtml();
    if (settings) out.push(`<section><div class="lbl">Settings</div><div class="list">${settings}</div></section>`);
    return out;
  }

  // What builds next, in order: Chef builds one request at a time.
  sectionQueue() {
    const next = this.upNext();
    const st = this.buildState;
    const busy = !!(st && st.busy);
    if (!next.length && !this.showBuildInCloud()) {
      return `<section><div class="lbl">Up next</div><p class="small">Nothing approved is waiting. Approve a request and it lines up here.</p></section>`;
    }
    // A batch (docs/chef-pipeline.md, "Batching") is one build: its requests
    // show together under its title, each with "Split out" until it starts.
    const batchOf = new Map(this.batches().map((b) => [b.batchId, b]));
    const shown = new Set();
    let pos = 0;
    const rows = next.map((n) => {
      const b = n.batchId ? batchOf.get(n.batchId) : null;
      if (b && shown.has(b.batchId)) return "";
      const i = pos++;
      if (!b) {
        return `<div class="row"><span class="pos ${i === 0 ? "next" : ""}">${i + 1}</span>
      <div class="main"><div class="rt">${esc(n.title || `Request #${n.number}`)}</div><div class="meta">#${esc(n.number)}${i === 0 ? ` · <b>next</b>` : ""}</div></div></div>`;
      }
      shown.add(b.batchId);
      const reqs = b.items.map((it) => `<li><span class="small">#${esc(it.number)}</span> ${esc(it.title)}${b.status === "planned"
        ? ` <button class="link" data-split="${esc(it.itemId)}" title="Build this one on its own">Split out</button>` : ""}</li>`).join("");
      return `<div class="row batch"><span class="pos ${i === 0 ? "next" : ""}">${i + 1}</span>
      <div class="main"><div class="rt">${esc(b.title)}</div><div class="meta"><span class="chip plain">One build, ${esc(b.items.length)} requests</span>${
        i === 0 ? ` · <b>next</b>` : ""}</div>${b.reason ? `<p class="small">${esc(b.reason)}</p>` : ""}<ul class="breqs">${reqs}</ul></div></div>`;
    }).join("");
    const planning = st && st.planning ? `<p class="small"><span class="spin"></span> Chef is grouping related requests into builds…</p>` : "";
    const how = busy ? "Chef builds one request at a time, in this order. The first starts when the current build finishes."
      : st && st.cloudEnabled && !st.autoBuild ? "Auto-build is off: press Build to start the first one."
      : st && !st.cloudEnabled ? (st.workerKeys ? "A local worker (npx chef work) builds these, in this order." : "Cloud builds are off: start npx chef work to build these.")
      : "Chef builds one request at a time, in this order.";
    const btn = this.showBuildInCloud()
      ? `<div class="row-btns"><button class="act" id="build-cloud" ${this.buildBusy ? "disabled" : ""}>${
        next[0] ? esc(`Build #${next[0].number} now`) : "Build in cloud"}</button><span class="small">On your Convex bill.</span></div>` : "";
    return `<section><div class="lbl">Up next <span class="n">${next.length || ""}</span></div>
      ${planning}${rows ? `<div class="list rnext">${rows}</div>` : ""}<p class="small">${esc(how)}${
        st && st.batching ? " Requests that touch the same part of the app are built together." : ""}</p>${btn}</section>`;
  }

  // Whether "Ship to the live app" has a build ready to approve.
  shipReady() {
    const c = this.ship.candidate;
    return !!(c && c.run && c.run.diff && !c.blocked && !(c.release && c.release.open));
  }

  // ---- sections ----
  sectionApprovals(items) {
    const cards = items.map((p) => {
      const shots = (p.attachments || []).filter((a) => a.kind === "screenshot" && a.url);
      const audio = (p.attachments || []).find((a) => a.kind === "audio" && a.url);
      return `<div class="appr">
        <div><div class="at">${esc(p.title)}</div><div class="who">${esc(p.from || "Someone")} · ${esc(ago(p.at))}</div></div>
        ${p.description ? `<div class="ad">${esc(p.description)}</div>` : ""}
        ${shots.length ? `<div class="ashots">${shots.map((a) =>
          `<a href="${esc(a.url)}" target="_blank" rel="noopener" title="Open screenshot"><img src="${esc(a.url)}" alt="Screenshot" loading="lazy" /></a>`).join("")}</div>` : ""}
        ${audio ? `<audio controls preload="none" src="${esc(audio.url)}"></audio>` : ""}
        ${this.approving && this.approving.id === p.id ? this.approvalBody(this.approving) : `<div class="row-btns">
          <button class="act" data-approve="${esc(p.id)}">Approve</button>
          <button class="no" data-reject="${esc(p.id)}">Reject</button>
        </div>`}
      </div>`;
    }).join("");
    return `<section><div class="lbl">Waiting for your approval (${items.length})</div>${cards}</section>`;
  }

  // The snapshot being approved, in full, with "Approve and build".
  approvalBody(a) {
    const err = a.error ? `<div class="flash">${esc(a.error)}</div>` : "";
    if (a.snapshot === undefined) {
      return `<div class="snapbox">${err}${a.error ? "" : `<p class="muted">Preparing the snapshot…</p>`}
        <div class="row-btns"><button class="ghost" data-cancel-approval="1">Cancel</button></div></div>`;
    }
    if (a.snapshot === null) {
      return `<div class="snapbox"><div class="flash">Snapshot unavailable.</div>
        <div class="row-btns"><button class="ghost" data-cancel-approval="1">Cancel</button></div></div>`;
    }
    return `<div class="snapbox">${snapshotHtml(a.snapshot)}${err}
      <div class="row-btns">
        <button class="act" id="approve-build" ${a.busy || a.snapshot.approved ? "disabled" : ""}>Approve and build</button>
        <button class="ghost" data-cancel-approval="1" ${a.busy ? "disabled" : ""}>Cancel</button>
      </div></div>`;
  }

  sectionShip() {
    const s = this.ship;
    const { run, release, blocked, requests } = s.candidate;
    const diff = run && run.diff;
    const err = s.error ? `<div class="flash" role="alert">${esc(s.error)}</div>` : "";
    const status = release ? `<div class="shipst ${release.state === "done" ? "ok" : release.error || release.state === "abandoned" ? "bad" : ""}">${esc(shipStateText(release))}${
      release.state === "done" && release.siteUrl ? ` <a href="${esc(release.siteUrl)}" target="_blank" rel="noopener">Open it</a>` : ""}</div>` : "";
    const relErr = release && release.error && (release.open || release.state === "abandoned")
      ? `<pre class="berr">${esc(release.error)}</pre>` : "";
    // Main moved before Ship it and Chef is merging it in: that's on its way, not a failure.
    const refreshing = !!(run && run.refreshing && blocked);
    // The open release follows main (docs/chef-pipeline.md, "When main moves
    // under Ship it"): "Merged main in", "Resolving a conflict", "Needs you: conflict in X".
    const follow = s.candidate.follow || null;
    const act = follow ? followAction(follow) : null;
    const paused = !!follow && follow.status !== "merged" && follow.status !== "merging";
    const inFlight = release && release.open && !release.error && !paused;
    const retry = release && release.open && release.error && release.shipRunId && release.approvedDiffHash && !follow;
    let body = "";
    const followHtml = follow ? `<div class="shipfollow"><div class="shipst ${follow.status === "failed" || follow.status === "stalled" ? "bad" : ""}">${
      follow.status === "merging" ? '<span class="spin"></span> ' : ""}${esc(follow.text)}</div>${
      follow.files.length && follow.status !== "merging" ? `<div class="small">Files: ${esc(follow.files.slice(0, 10).join(", "))}${follow.files.length > 10 ? ", …" : ""}</div>` : ""}${
      act === "approve" && follow.resolution ? `<pre class="shipdiff">${esc(follow.resolution)}${follow.resolutionTruncated ? "\n[… cut]" : ""}</pre>` : ""}${
      act === "approve" && follow.depsChanged ? `<label class="shipdeps"><input type="checkbox" id="ship-deps" ${s.deps ? "checked" : ""}/> The merged change touches dependencies. I checked them.</label>` : ""}${
      act ? `<div class="row-btns"><button class="act" id="ship-follow" ${s.busy || (act === "approve" && follow.depsChanged && !s.deps) ? "disabled" : ""}>${
        act === "approve" ? (follow.repaired ? "Approve the resolution and ship" : "Approve the merged change and ship") : "Try again"}</button></div>` : ""}</div>` : "";
    const replaces = run && run.replaces != null && !blocked
      ? `<p class="small">Release #${esc(run.replaces)} is waiting for you. Shipping this build ships its requests too, in its place.</p>` : "";
    const merged = !retry && !inFlight && !blocked && run ? mergedMainText(run) : null;
    if (refreshing) {
      body = `<div class="shiprefresh"><div class="shipst"><span class="spin"></span> ${esc(run.refreshing === "merging"
        ? "Merging the newest main into this build…" : "Main moved: Chef will merge it into this build next.")}</div>
        <p class="small">Chef checks the merge like any build. If the change is the one you approved, it ships on its own; if not, it's back here for you to look at.</p></div>`;
    } else if (retry) {
      body = `<div class="row-btns"><button class="act" id="ship-retry" ${s.busy ? "disabled" : ""}>Try again</button></div>`;
    } else if (!inFlight && blocked) {
      body = `<p class="muted">${esc(blocked)}</p>${run && run.retryItemId
        ? `<div class="row-btns"><button class="act" id="ship-rebuild" ${s.busy ? "disabled" : ""}>Try again</button></div>` : ""}`;
    }
    // The plain-language card first, whenever this build can ship.
    const card = !retry && !inFlight && !blocked && s.card && run && s.card.runId === run.runId
      ? cardHtml(s.card, { loginUsed: !!this.loginUsed[run.runId] }) : "";
    if (retry || inFlight || blocked) {
      // Try again, a ship in flight, or why not: nothing to review.
    } else if (run && diff && !s.open) {
      const onBeta = !!(s.card && s.card.runId === run.runId && s.card.beta && s.card.beta.onBeta);
      body = `<div class="row-btns"><button class="act" id="ship-it">${onBeta ? "Promote to everyone" : "Ship it"}</button>
        <span class="small">Build #${esc(run.seq)}, ${esc((run.commitSha || "").slice(0, 12))}: ${requests.length} request${requests.length === 1 ? "" : "s"}</span></div>`;
    } else if (run && diff) {
      const reqs = requests.map((r) => `<li>${r.number !== null ? `<span class="small">#${esc(r.number)} </span>` : ""}${esc(r.title)}</li>`).join("");
      const text = Array.from({ length: diff.chunkCount }, (_, i) => {
        const c = s.chunks[i];
        return c === undefined ? "Loading…\n" : c === null ? `[part ${i + 1} is unavailable]\n` : c.text;
      }).join("");
      body = `<div class="shiprev">
        <div>This ships <code>${esc((run.commitSha || "").slice(0, 12))}</code> to the live app, then moves main from
          <code>${esc((run.baseSha || "").slice(0, 12))}</code> to it.</div>
        ${reqs ? `<ul class="shipreqs">${reqs}</ul>` : ""}
        ${(s.candidate.alsoShips || []).length ? `<div class="small">Also ships (their builds stopped after pushing their change, so it is in this build):</div><ul class="shipreqs">${
          s.candidate.alsoShips.map((r) => `<li>${r.number !== null ? `<span class="small">#${esc(r.number)} </span>` : ""}${esc(r.title)} <span class="small">(build #${esc(r.seq)})</span></li>`).join("")}</ul>` : ""}
        <div class="small">${diff.filesChanged.length}${diff.filesTruncated ? "+" : ""} files · diff <code>${esc(diff.diffHash.slice(0, 12))}</code>${
          diff.redactions ? ` · ${diff.redactions} secret-looking strings hidden` : ""}</div>
        <div class="shipdetails"><button class="ghost" id="ship-details" aria-expanded="${s.details ? "true" : "false"}">${
          s.details ? "Hide the details" : "Details: the whole change, as code"}</button>
        ${s.details ? `<pre class="shipdiff">${esc(text)}</pre>` : ""}</div>
        ${diff.depsChanged ? `<label class="shipdeps"><input type="checkbox" id="ship-deps" ${s.deps ? "checked" : ""}/> This changes dependencies (package.json or a lockfile). I checked them.</label>` : ""}
        <div class="row-btns">
          <button class="act" id="ship-live" ${s.busy || (diff.depsChanged && !s.deps) ? "disabled" : ""}>${
            s.card && s.card.runId === run.runId && s.card.beta && s.card.beta.onBeta ? "Promote to everyone" : "Ship to live"}</button>
          <button class="ghost" id="ship-cancel" ${s.busy ? "disabled" : ""}>Cancel</button>
        </div></div>`;
    }
    return `<section><div class="lbl">Ship to the live app</div><div class="shipbox">${refreshing || follow ? "" : status + relErr}${followHtml}${replaces}${merged ? `<div class="shipmerged">${esc(merged)}</div>` : ""}${card}${body}${err}</div></section>`;
  }

  // One cloud build as a row: its title, status, cost and age; opens in place.
  runRow(r) {
    const open = !!(this.build && this.build.runId === r.runId);
    const c = this.costOf(r.runId);
    const cost = c ? `<span class="rcost" title="${esc(`What Chef spent building #${r.seq}`)}">${esc(runCostLabel(c))}</span>` : "";
    let body = open ? this.buildBody(this.build) : "";
    const run = open && this.build ? this.build.run : null;
    if (run && !isRunning(run.status)) body = body.replace("<dt>Spend so far</dt>", "<dt>Cost</dt>");
    return `<div class="run ${open ? "open" : ""}">
      <button class="runhd" data-run="${esc(r.runId)}" aria-expanded="${open ? "true" : "false"}">
        <span class="main"><span class="rt">${esc(r.title || `Build #${r.seq}`)}</span>
          <span class="meta"><span class="chip rst ${esc(r.status)}">${isRunning(r.status) ? `<span class="spin"></span>` : ""}${esc(r.statusText)}</span>${cost}<span>#${esc(r.seq)}${
            r.createdAt ? ` · ${esc(ago(r.createdAt))}` : ""}${r.builtLocallyOn ? " · built locally" : ""}</span></span></span>
        <span class="chev" aria-hidden="true">›</span>
      </button>
      ${r.failureReason && !open ? `<p class="runfail">${esc(r.failureReason)}</p>` : ""}
      ${body}
    </div>`;
  }

  sectionCloudBuilds() {
    const rows = this.runs.map((r) => this.runRow(r)).join("");
    return `<section><div class="lbl">Cloud builds</div>${rows ? `<div class="list">${rows}</div>` : `<p class="small">No cloud builds yet.</p>`}</section>`;
  }

  // "Preview data": the app's demo data (default), or a copy of this admin's own.
  previewDataHtml() {
    const p = this.previewData;
    if (!p) return "";
    const on = p.mode === "admin-copy";
    const help = on && !p.mine ? "On for another admin. Turn it off and on again to use your own data instead."
      : on ? "Each preview gets a copy of your own rows, never anyone else's. The build's code can read them."
      : "Previews start with the app's demo data.";
    return `<div class="setting pdata"><div class="main"><b>Preview with my own data</b><span class="small">${esc(help)}</span></div>
      <label class="switch" title="Preview with my own data"><input type="checkbox" id="preview-data" role="switch" aria-label="Preview with my own data" ${on && p.mine ? "checked" : ""} ${this.previewDataBusy ? "disabled" : ""}/><span></span></label></div>`;
  }

  async setPreviewData(on) {
    this.previewDataBusy = true; this.render();
    try {
      await this.client.mutation(this.ref("setPreviewData"), { mode: on ? "admin-copy" : "demo" });
    } catch (e) {
      console.warn("chef-panel: setPreviewData", e);
    } finally {
      this.previewDataBusy = false; this.render();
    }
  }

  // What Chef knows about this app, and what recent builds cost.
  learningsHtml() {
    const l = this.learnings;
    const entries = (l && l.entries) || [];
    if (!entries.length && !this.costs.length) return "";
    const head = `<div class="setting"><div class="main"><b>What Chef knows about this app</b><span class="small">${
      entries.length ? `${entries.length} note${entries.length === 1 ? "" : "s"} every build starts with` : "Nothing yet"}</span></div>
      <button class="ghost" id="learn-toggle" aria-expanded="${this.learnOpen ? "true" : "false"}">${this.learnOpen ? "Hide" : "Show"}</button></div>`;
    if (!this.learnOpen) return head;
    const group = (src, title) => {
      const rows = entries.filter((e) => e.source === src);
      if (!rows.length) return "";
      return `<div class="lbl">${esc(title)}</div><ul>${rows.map((e) => `<li class="${e.expired ? "exp" : ""}"><span style="flex:1">${
        src === "agent" ? `<span class="small">${esc(e.topic)}: </span>` : ""}${esc(e.text)} <span class="small">· build #${esc(e.lastRunSeq)}${
        e.seenCount > 1 ? `, seen ${esc(e.seenCount)}×` : ""}${e.expired ? ", expired" : ""}</span></span><button class="ghost" data-forget="${esc(e.id)}">Forget</button></li>`).join("")}</ul>`;
    };
    const max = Math.max(0.01, ...this.costs.map((c) => c.spendUsd));
    // Warm snapshots: how many recent installs came from one ("install (warm)" in the bar's title).
    const timed = this.costs.filter((c) => c.warm === true || c.warm === false);
    const hits = timed.filter((c) => c.warm === true).length;
    const installOf = (c) => {
      const p = c.phaseMs || {};
      return typeof p.installWarm === "number" ? `, install (warm) ${Math.round(p.installWarm / 1000)} s`
        : typeof p.install === "number" ? `, install ${Math.round(p.install / 1000)} s` : "";
    };
    const warmRate = timed.length ? `<div class="warm-rate">Warm installs: ${hits} of ${timed.length} recent build${timed.length === 1 ? "" : "s"} (${Math.round((hits / timed.length) * 100)}%)</div>` : "";
    const costs = this.costs.length ? `<div class="lbl">What builds cost</div><div class="costbars">${this.costs.map((c) =>
      `<span class="${esc(c.status)}" style="height:${Math.max(2, Math.round((c.spendUsd / max) * 40))}px" title="${esc(`#${c.seq}: $${c.spendUsd.toFixed(2)}${c.wallMs ? `, ${Math.round(c.wallMs / 60000)} min` : ""}${installOf(c)}, ${c.status}`)}"></span>`).join("")}</div>${warmRate}` : "";
    const brief = l && l.brief ? `<div><button class="ghost" id="brief-toggle">${this.briefOpen ? "Hide the next build's brief" : "Show the next build's brief"}</button></div>${
      this.briefOpen ? `<pre class="runlog">${esc(l.brief)}</pre>` : ""}` : "";
    return `<div>${head}<div class="learn">
      <p class="small">Each build starts with this, so it explores less. Agents' notes are only ever read as notes, never as settings. Delete anything wrong.</p>
      ${group("runner", "Seen by the runner")}${group("failure", "Earlier failures")}${group("agent", "Notes from build agents")}${brief}${costs}</div></div>`;
  }

  // Only with cloud builds on, an approved request waiting and no build running.
  // With auto-build on approvals start on their own, so the button is for auto-build off.
  showBuildInCloud() {
    const b = this.buildState;
    return !!(b && b.cloudEnabled && b.queued && !b.busy);
  }

  buildBody(b) {
    if (b.run === undefined) return `<div class="build"><p class="muted">Loading the build…</p></div>`;
    if (b.run === null) return `<div class="build"><p class="muted">No cloud build yet.</p></div>`;
    const card = b.card && b.run.status === "built" && b.card.runId === b.runId
      ? cardHtml(b.card, { loginUsed: !!this.loginUsed[b.runId] }) : "";
    return card + runHtml(b.run, {
      hideLinks: !!card,
      shots: b.shots, notes: b.notes, asks: b.asks, busy: b.busy, error: b.error,
      loginUsed: !!this.loginUsed[b.runId], logOpen: b.logOpen, logPages: b.logPages,
      retryBusy: b.retryBusy, retryNote: b.retryNote,
    });
  }

  sectionAsking(open) {
    const answeredList = Object.entries(this.answered);
    const askedBlock = open.length ? (() => {
      const q = open[0];
      const upnext = open.slice(1).map((r) => `<div class="upnext">${esc(r.title || r.text || "")}</div>`).join("");
      return `<div class="qcard">
          <div class="qt">${esc(q.title || q.text || "")}</div>
          <textarea id="ans" placeholder="Type your answer…" rows="3"></textarea>
          <div class="row-btns">
            <button class="act" id="send">Send to Chef</button>
            <button class="ghost" id="skip">Skip</button>
          </div>
        </div>
        ${open.length > 1 ? `<div class="lbl">Up next (${open.length - 1})</div>${upnext}` : ""}`;
    })() : "";
    const answeredBlock = answeredList.length ? answeredList.map(([, a]) =>
      `<div class="qcard done">✓ You: ${esc(a)}</div>`).join("") : "";
    return `<section><div class="lbl">Chef is asking</div>${askedBlock || (answeredBlock ? `<p class="muted">No open questions.</p>` : "")}${answeredBlock}</section>`;
  }

  // The local agent's plan and progress ("" when it has none).
  sectionBuild(building) {
    const s = this.snap;
    const todos = s.todos || [];
    const progress = (s.progress || []).slice(0, 8);
    if (!todos.length && !progress.length) return "";
    const plan = todos.map((t) => {
      const st = t.status === "done" ? "done" : t.status === "active" ? "active" : "pending";
      const glyph = st === "done" ? "✓" : st === "active" ? "●" : "○";
      return `<div class="todo ${st}"><span class="tdot ${st}">${glyph}</span><span class="t">${esc(t.text)}</span></div>`;
    }).join("");
    const recent = progress.length ? `<div class="lbl">Recent</div>` + progress.map((p, i) => {
      const k = p.kind === "shipped" ? "shipped" : p.kind === "note" ? "note" : "";
      const glyph = p.kind === "shipped" ? "✓" : p.kind === "note" ? "·" : "●";
      return `<div class="prog ${i === 0 ? "" : "dim"}"><span class="pdot ${k}">${glyph}</span><span>${esc(p.message)}</span></div>`;
    }).join("") : "";
    return `<section>${todos.length ? `<div class="lbl">Plan${building ? `<span class="spin"></span>` : ""}</div>` : ""}${plan}${recent}</section>`;
  }

  // Admins: every request in one list, grouped by where it is.
  sectionRequest() {
    const byId = new Map();
    for (const m of this.mineList || []) byId.set(m._id, { ...m, mine: true });
    for (const r of this.requests || []) {
      const id = r._id || r.id;
      byId.set(id, { ...(byId.get(id) || {}), ...r, _id: id });
    }
    const line = new Map(this.upNext().map((n, i) => [String(n.itemId), i]));
    const building = this.buildingIds();
    const groupOf = (r) =>
      r.state === "requested" || r.state === "planned" || !r.state ? "queued"
      : r.state === "inProgress" && !building.has(String(r._id)) ? "built"
      : r.state;
    const all = Array.from(byId.values()).map((r) => ({ ...r, shown: groupOf(r) }));
    if (!all.length) {
      return `<div class="empty"><b>No requests yet.</b><span>Type one below, or tap the mic to show Chef what you mean.</span></div>`;
    }
    return REQUEST_GROUPS.map(([key, label]) => {
      let rows = all.filter((r) => r.shown === key);
      if (!rows.length) return "";
      if (key === "queued") rows.sort((a, b) => (line.get(String(a._id)) ?? 1e9) - (line.get(String(b._id)) ?? 1e9));
      const more = key === "completed" || key === "rejected" ? Math.max(0, rows.length - 5) : 0;
      if (more) rows = rows.slice(0, 5);
      return `<section><div class="lbl">${esc(label)} <span class="n">${rows.length + more}</span></div><div class="list">${
        rows.map((r) => this.requestRow(r, line.get(String(r._id)))).join("")}</div>${more ? `<p class="small">and ${more} more</p>` : ""}</section>`;
    }).join("");
  }

  requestRow(r, place) {
    const [label, kind] = STATE_LABEL[r.shown === "built" ? "built" : r.state || "requested"] || ["Queued", "plain"];
    const id = r._id || r.id;
    const votes = r.voteCount ?? r.stats?.totalAmount;
    const att = this.attachments[id] || [];
    const shots = att.filter((a) => a.kind === "screenshot" && a.url);
    const audio = att.find((a) => a.kind === "audio" && a.url);
    const attHtml = att.length ? `<div class="att">${shots.map((a) =>
      `<a href="${esc(a.url)}" target="_blank" rel="noopener" title="Screenshot"><img src="${esc(a.url)}" alt="Screenshot" loading="lazy" /></a>`).join("")}${audio
      ? `<a class="mic" href="${esc(audio.url)}" target="_blank" rel="noopener" title="Voice note">🎙</a>` : ""}</div>`
      : r.screenshotCount || r.hasAudio ? `<span>${r.screenshotCount ? `📸${r.screenshotCount > 1 ? "×" + r.screenshotCount : ""}` : ""}${r.hasAudio ? "🎙" : ""}</span>` : "";
    const chip = place !== undefined ? `<span class="chip ${place === 0 ? "busy" : "plain"}">${place === 0 ? "Next" : `${place + 1} in line`}</span>`
      : `<span class="chip ${kind}">${esc(label)}</span>`;
    return `<div class="row req">
      ${votes !== undefined ? `<button class="vote" data-up="${esc(id)}" title="Vote">▲ ${esc(votes)}</button>` : ""}
      <div class="main"><div class="rt">${esc(r.title)}</div><div class="meta">${chip}${r.number !== undefined ? `<span>#${esc(r.number)}</span>` : ""}${attHtml}</div>${
        this.builtWith(id) ? `<div class="small btogether">${esc(this.builtWith(id))}</div>` : ""}</div>
    </div>`;
  }

  // Non-admins: just their own requests, in friendly words.
  sectionMemberRequest() {
    const mine = (this.mineList || []).slice(0, 10);
    const rows = mine.map((m) => {
      const [label, kind] = MEMBER_STATE_LABEL[m.state] || ["Planned", "info"];
      const media = [m.screenshotCount ? `📸${m.screenshotCount > 1 ? "×" + m.screenshotCount : ""}` : "", m.hasAudio ? "🎙" : ""].join("");
      return `<div class="row mine"><div class="main"><div class="rt mt">${esc(m.title)}</div><div class="meta"><span class="chip ms ${kind}">${esc(label)}</span>${media ? `<span>${media}</span>` : ""}</div></div></div>`;
    }).join("");
    return `<section>
      ${mine.length ? `<div class="lbl">Your requests</div><div class="list">${rows}</div>`
        : `<div class="empty"><b>What would make this better?</b><span>Type it below${this.mediaOk ? ", or tap the mic to show us" : ""}. The team reads every one.</span></div>`}
      ${this.me ? `<div class="myid" title="The app's owner makes an admin with: npx chef init --admin <this id>">Your Chef user id: <code id="myid">${esc(this.me)}</code><button class="ghost" id="copyid">Copy</button></div>` : ""}
    </section>`;
  }

  // The request box, pinned under every tab.
  composerFoot() {
    const admin = this.admin;
    return `<div class="foot">
      <div class="bar">
        <textarea id="rt" rows="1" aria-label="${admin ? "Ask Chef to build or fix something" : "Your request"}" placeholder="${
          admin ? "Ask Chef for a feature or a fix…" : "e.g., let me export to PDF"}"></textarea>
        ${this.mediaOk ? `<button class="iconbtn" id="media" title="Screenshot this page and describe it out loud (or long-press the ${admin ? "Chef bubble" : "button"})" aria-label="Screenshot and voice note">${MIC_SVG}</button>` : ""}
        <button class="act" id="sub" title="${admin ? "Send to Chef (⌘↩)" : "Send (⌘↩)"}">Send</button>
      </div>
    </div>`;
  }

  // ---- wiring ----
  // ⌘/Ctrl+Enter on a textarea triggers its primary submit.
  onCmdEnter(ta, fn) {
    if (!ta) return;
    ta.addEventListener("keydown", (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "Enter") { e.preventDefault(); fn(); }
    });
  }
  wireApprovals() {
    const act = (id, approve) => {
      this.reviewed[id] = true; this.flash = ""; this.render();
      this.call("review", { id, approve }).catch(() => { delete this.reviewed[id]; this.render(); });
    };
    // Approve opens the snapshot; "Approve and build" approves exactly that.
    this.$body.querySelectorAll("[data-approve]").forEach((b) => b.onclick = () => this.startApproval(b.dataset.approve));
    this.$body.querySelectorAll("[data-cancel-approval]").forEach((b) => b.onclick = () => { this.cancelApproval(); this.render(); });
    const build = this.$body.querySelector("#approve-build");
    if (build) build.onclick = () => this.approveAndBuild();
    this.$body.querySelectorAll("[data-reject]").forEach((b) => b.onclick = () => act(b.dataset.reject, false));
  }
  wireShip() {
    const s = this.ship;
    const c = s.candidate;
    const it = this.$body.querySelector("#ship-it");
    if (it) it.onclick = () => this.openShip();
    const det = this.$body.querySelector("#ship-details");
    if (det) det.onclick = () => this.toggleShipDetails();
    this.$body.querySelectorAll("[data-card-login]").forEach((a) => a.addEventListener("click", () => {
      this.loginUsed[a.dataset.cardLogin] = true; setTimeout(() => this.render(), 0);
    }));
    const cancel = this.$body.querySelector("#ship-cancel");
    if (cancel) cancel.onclick = () => { this.closeShip(); this.render(); };
    const deps = this.$body.querySelector("#ship-deps");
    if (deps) deps.onchange = () => { s.deps = deps.checked; this.render(); };
    const live = this.$body.querySelector("#ship-live");
    if (live && c && c.run && c.run.diff) {
      const d = c.run.diff;
      live.onclick = () => this.shipToLive({ runId: c.run.runId, diffHash: d.diffHash, ...(d.depsChanged ? { depsAcknowledged: s.deps } : {}) });
    }
    const rebuild = this.$body.querySelector("#ship-rebuild");
    if (rebuild && c && c.run && c.run.retryItemId) rebuild.onclick = () => this.shipRebuild(c.run.retryItemId);
    const retry = this.$body.querySelector("#ship-retry");
    if (retry && c && c.release) retry.onclick = () => this.shipToLive({ runId: c.release.shipRunId, diffHash: c.release.approvedDiffHash });
    const fol = this.$body.querySelector("#ship-follow");
    const f = c && c.follow;
    if (fol && f) {
      fol.onclick = () => followAction(f) === "approve"
        ? this.shipToLive({ runId: f.runId, diffHash: f.diffHash, ...(f.depsChanged ? { depsAcknowledged: s.deps } : {}) })
        : this.shipToLive({ runId: f.shipRunId, diffHash: f.approvedDiffHash });
    }
  }

  wireCloudBuilds() {
    this.$body.querySelectorAll("[data-tab-go]").forEach((b) => b.onclick = () => this.setTab(b.dataset.tabGo));
    const bc = this.$body.querySelector("#build-cloud");
    if (bc) bc.onclick = () => this.buildInCloud();
    this.$body.querySelectorAll("[data-split]").forEach((b) => b.onclick = () => this.splitFromBatch(b.dataset.split));
    this.$body.querySelectorAll("[data-run]").forEach((b) => b.onclick = () => {
      if (this.build && this.build.runId === b.dataset.run) { this.closeBuild(); this.render(); } else this.openBuild(b.dataset.run);
    });
    const lt = this.$body.querySelector("#learn-toggle");
    if (lt) lt.onclick = () => { this.learnOpen = !this.learnOpen; this.render(); };
    const pd = this.$body.querySelector("#preview-data");
    if (pd) pd.onchange = () => this.setPreviewData(pd.checked);
    const bt = this.$body.querySelector("#brief-toggle");
    if (bt) bt.onclick = () => { this.briefOpen = !this.briefOpen; this.render(); };
    this.$body.querySelectorAll("[data-forget]").forEach((x) => x.onclick = () => this.forgetLearning(x.dataset.forget));
    const b = this.build;
    if (!b) return;
    const rp = this.$body.querySelector("[data-repair-apply]");
    if (rp && this.build) rp.onclick = () => this.applyRepair(rp.dataset.repairApply, rp.dataset.sha);
    const rt = this.$body.querySelector("#run-retry");
    if (rt) rt.onclick = () => this.retryRun();
    const login = this.$body.querySelector("#preview-login");
    // The sign-in link works once: hide it as soon as it's opened.
    if (login) login.addEventListener("click", () => { this.loginUsed[b.runId] = true; setTimeout(() => this.render(), 0); });
    this.$body.querySelectorAll("[data-spend-approve]").forEach((x) => x.onclick = () => this.decideSpend(x.dataset.spendApprove, true));
    this.$body.querySelectorAll("[data-spend-decline]").forEach((x) => x.onclick = () => this.decideSpend(x.dataset.spendDecline, false));
    const log = this.$body.querySelector("#runlog");
    if (log) log.onclick = () => this.toggleLog();
    const more = this.$body.querySelector("#logmore");
    if (more) more.onclick = () => this.loadLogPage(Number(more.dataset.cursor));
  }
  wireAsking(open) {
    if (!open.length) return;
    const q = open[0], qid = q._id || q.id;
    const ta = this.$body.querySelector("#ans");
    const submit = () => {
      const v = ta.value.trim();
      if (!v) return;
      this.answered[qid] = v; ta.value = ""; this.flash = ""; this.render();
      this.call("answerRefinement", { id: qid, answer: v }).catch(() => { delete this.answered[qid]; this.render(); });
    };
    const send = this.$body.querySelector("#send");
    const skip = this.$body.querySelector("#skip");
    if (send) send.onclick = submit;
    if (skip) skip.onclick = () => this.call("skipRefinement", { id: qid }).catch(() => {});
    this.onCmdEnter(ta, submit);
  }
  wireRequest() {
    this.$body.querySelectorAll("[data-up]").forEach((b) => b.onclick = () => this.call("upvoteRequest", { id: b.dataset.up }).catch(() => {}));
    const ta = this.$wrap.querySelector("#rt");
    ta.addEventListener("input", () => { writeDraft(this.draftKey, ta.value); fitTextarea(ta); });
    const submitReq = () => {
      const text = ta.value.trim();
      if (!text) return;
      const nl = text.indexOf("\n");
      const title = nl >= 0 ? text.slice(0, nl).trim() : text;
      const description = nl >= 0 ? text.slice(nl + 1).trim() : "";
      this.flash = "";
      this.call("submitRequest", { title, description }).then(() => {
        writeDraft(this.draftKey, "");
        const el = this.$wrap && this.$wrap.querySelector("#rt");
        if (el && el.value.trim() === text) el.value = "";
        this.render();
        this.showToast(this.sentMessage());
      }).catch(() => {});
    };
    const sub = this.$wrap.querySelector("#sub");
    if (sub) sub.onclick = submitReq;
    const media = this.$wrap.querySelector("#media");
    if (media) media.onclick = () => this.startMediaRequest(ta.value.trim());
    const copyId = this.$body.querySelector("#copyid");
    if (copyId) copyId.onclick = () => {
      const id = this.me || "";
      Promise.resolve(navigator.clipboard && navigator.clipboard.writeText(id))
        .then(() => { copyId.textContent = "Copied"; })
        .catch(() => {});
    };
    this.onCmdEnter(ta, submitReq);
  }

  // ===================== screenshot + voice composer =====================
  // Long-press / right-click the bubble (or the 📸+🎙 button): snapshot the
  // page (DOM render, no screen-share prompt), then open a composer that is
  // already recording a voice note with a live transcript.

  async startMediaRequest(prefill = "") {
    if (this.$comp) return; // already composing
    this.c = { shots: [], audio: null, transcript: "", interim: "", titleEdited: false, descEdited: false,
      recording: false, sending: false, error: "", note: "", capturing: true };
    this.$comp = document.createElement("div");
    this.$comp.className = "comp";
    this.shadowRoot.appendChild(this.$comp);
    this.syncWhatsNew();
    this.$wrap.style.display = "none";
    if (!this._fetchToken) this.c.note = "Sending needs a signed-in user — sign in first.";
    if (prefill) { this.c.desc = prefill; this.c.descEdited = true; }
    this.renderComposer();
    // Record first: the page snapshot (a CDN library and a DOM render) hogs the
    // main thread for seconds, and a microphone started alongside it only goes
    // live once it's done. Wait until recording is live (or failed, or a
    // permission prompt has sat for MIC_WAIT_MS), let "Listening" paint, then
    // snapshot; the recorder keeps capturing off the main thread meanwhile. A
    // mic prompt is browser chrome, not page DOM, so it isn't in the picture.
    const c = this.c;
    await Promise.race([this.startRecording().catch(() => {}), wait(MIC_WAIT_MS)]);
    await nextPaint();
    if (this.c !== c) return; // closed (or reopened) meanwhile
    await this.addScreenshot();
  }

  closeComposer() {
    this.stopRecording(true);
    if (this.$ann) { this.$ann.remove(); this.$ann = null; }
    for (const s of (this.c && this.c.shots) || []) URL.revokeObjectURL(s.url);
    if (this.c && this.c.audio) URL.revokeObjectURL(this.c.audio.url);
    if (this.$comp) { this.$comp.remove(); this.$comp = null; }
    this.c = null;
    this.$wrap.style.display = "";
    this.render();
  }

  // "In 3 s": get out of the way so the page can be put in the state worth
  // showing (a menu open, a hover), count down, then capture. Recording goes on.
  async timedScreenshot(seconds = SHOT_TIMER_S) {
    const c = this.c;
    if (!c || !this.$comp || c.capturing || c.countdown) return;
    const pill = document.createElement("div");
    pill.className = "countdown"; pill.setAttribute("role", "status");
    this.shadowRoot.appendChild(pill);
    this.$comp.style.display = "none";
    c.countdown = true;
    try {
      for (let n = seconds; n > 0; n--) {
        pill.textContent = `Screenshot in ${n}…`;
        await wait(1000);
        if (this.c !== c) return; // closed meanwhile
      }
      pill.remove();
      await nextPaint();
      await this.addScreenshot();
    } finally {
      pill.remove();
      c.countdown = false;
      if (this.$comp && this.c === c) { this.$comp.style.display = ""; this.renderComposer(); }
    }
  }

  async addScreenshot() {
    const c = this.c;
    if (!c || c.shots.length >= MAX_SHOTS) return;
    c.capturing = true; this.renderComposer();
    try {
      const blob = await capturePage();
      if (this.c !== c) return;
      c.shots.push({ blob, url: URL.createObjectURL(blob) });
    } catch (e) {
      if (this.c === c) c.error = "Couldn't capture the page" + (e && e.message ? ` (${e.message})` : "") + ".";
    } finally {
      if (this.c === c) { c.capturing = false; this.renderComposer(); }
    }
  }

  async startRecording() {
    const c = this.c;
    if (!c || c.recording) return;
    if (!navigator.mediaDevices || !window.MediaRecorder) { c.note = "Voice recording isn't supported here — type instead."; this.renderComposer(); return; }
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
    catch { if (this.c === c) { c.note = "Microphone unavailable — type your request instead."; this.renderComposer(); } return; }
    if (this.c !== c) { stream.getTracks().forEach((t) => t.stop()); return; }
    if (c.audio) { URL.revokeObjectURL(c.audio.url); c.audio = null; }
    const mime = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg;codecs=opus"].find((m) => MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(m)) || "";
    const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
    const chunks = [];
    rec.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
    c.rec = { stream, rec, chunks, startedAt: Date.now(), done: new Promise((res) => { rec.onstop = res; }) };
    rec.start(1000);
    c.recording = true;
    // Waveform
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      const ac = new AC(); const src = ac.createMediaStreamSource(stream); const an = ac.createAnalyser();
      an.fftSize = 512; src.connect(an); c.rec.ac = ac; c.rec.an = an;
    } catch { /* waveform is cosmetic */ }
    // Live transcript (Web Speech; Chrome/Safari). Restarts across silences.
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SR) {
      const base = c.transcript ? c.transcript + " " : "";
      let finals = "";
      const sr = new SR();
      sr.continuous = true; sr.interimResults = true; sr.lang = navigator.language || "en-US";
      sr.onresult = (ev) => {
        let interim = "";
        for (let i = ev.resultIndex; i < ev.results.length; i++) {
          const r = ev.results[i];
          if (r.isFinal) finals += r[0].transcript.trim() + " "; else interim += r[0].transcript;
        }
        if (this.c !== c) return;
        c.transcript = (base + finals).trim(); c.interim = interim;
        this.syncFromTranscript();
      };
      sr.onerror = () => {};
      sr.onend = () => { if (this.c === c && c.recording) { try { sr.start(); } catch { /* already started */ } } };
      try { sr.start(); c.rec.sr = sr; } catch { /* no live transcript */ }
    } else {
      c.note = "Live transcript isn't available in this browser — your voice note is still attached.";
    }
    c.rec.limit = setTimeout(() => this.stopRecording(), MAX_REC_MS);
    this.renderComposer();
    this.drawWave();
  }

  async stopRecording(discard = false) {
    const c = this.c;
    if (!c || !c.rec) return;
    const r = c.rec; c.rec = null; c.recording = false; c.interim = "";
    clearTimeout(r.limit);
    try { r.sr?.stop(); } catch { /* already stopped */ }
    try { if (r.rec.state !== "inactive") r.rec.stop(); } catch { /* already stopped */ }
    await r.done;
    r.stream.getTracks().forEach((t) => t.stop());
    try { r.ac?.close(); } catch { /* already closed */ }
    if (discard || this.c !== c) return;
    const type = (r.rec.mimeType || r.chunks[0]?.type || "audio/webm").split(";")[0];
    const blob = new Blob(r.chunks, { type });
    if (blob.size > 0) c.audio = { blob, url: URL.createObjectURL(blob), ms: Date.now() - r.startedAt };
    if (blob.size > MAX_AUDIO_BYTES) { c.error = "Voice note is too long (max 25 MB)."; c.audio = null; }
    this.syncFromTranscript();
    this.renderComposer();
  }

  drawWave() {
    const c = this.c;
    if (!c || !c.rec || !this.$comp) return;
    if (c.rec.raf) return; // one loop per recording
    c.rec.raf = requestAnimationFrame(() => { if (c.rec) c.rec.raf = 0; this.drawWave(); });
    const cv = this.$comp.querySelector("#wave");
    const tm = this.$comp.querySelector("#tm");
    if (tm) tm.textContent = fmtMs(Date.now() - c.rec.startedAt);
    if (cv && c.rec.an) {
      const w = (cv.width = cv.clientWidth * (window.devicePixelRatio || 1));
      const h = (cv.height = cv.clientHeight * (window.devicePixelRatio || 1));
      const g = cv.getContext("2d"); const data = new Uint8Array(c.rec.an.fftSize);
      c.rec.an.getByteTimeDomainData(data);
      g.clearRect(0, 0, w, h); g.fillStyle = "#ea580c";
      const bars = 40, step = Math.floor(data.length / bars), bw = w / bars;
      for (let i = 0; i < bars; i++) {
        let peak = 0;
        for (let j = 0; j < step; j++) peak = Math.max(peak, Math.abs(data[i * step + j] - 128));
        const bh = Math.max(2, (peak / 128) * h * 1.6);
        g.fillRect(i * bw + bw * 0.2, (h - Math.min(h, bh)) / 2, bw * 0.6, Math.min(h, bh));
      }
    }
  }

  // What you say lands once, in the details, until you edit them by hand. The
  // title stays empty unless you type one; on send it's the first sentence.
  syncFromTranscript() {
    const c = this.c; if (!c || !this.$comp || c.descEdited) return;
    c.desc = (c.transcript + (c.interim ? " " + c.interim : "")).trim();
    const de = this.$comp.querySelector("#cd");
    if (de) de.value = c.desc;
  }

  renderComposer() {
    const c = this.c; if (!c || !this.$comp) return;
    const shots = c.shots.map((s, i) => `<div class="shot" data-ann="${i}" role="button" tabindex="0" title="Click to draw on it">
        <img src="${s.url}" alt="Screenshot ${i + 1}" /><span class="pen">✎ mark up</span>
        <button class="x" data-rm="${i}" aria-label="Remove screenshot">✕</button></div>`).join("");
    const canAdd = c.shots.length < MAX_SHOTS && !c.capturing;
    const recUi = c.recording
      ? `<div class="rec"><span class="rdot"></span><canvas id="wave"></canvas><span class="tm" id="tm">0:00</span><button id="stop">Stop</button></div>`
      : c.audio
        ? `<div class="rec"><span class="rdot off"></span><audio controls src="${c.audio.url}"></audio><button id="rerec" title="Record again">↺</button><button id="rmaudio" title="Remove voice note">✕</button></div>`
        : `<div class="rec"><span class="rdot off"></span><span class="tm" style="flex:1">No voice note</span><button id="record">🎙 Record</button></div>`;
    this.$comp.innerHTML = `
      <div class="hdr ${this.admin ? "" : "member"}">${this.mark()}<div class="ttl"><b>${this.admin ? "Show Chef what you mean" : "Request a feature"}</b><span>${c.recording ? "Listening — just describe it" : "Screenshot + voice note"}</span></div>
        <button class="min" id="cx" aria-label="Cancel" title="Cancel">✕</button></div>
      <div class="cbody">
        <div class="shots">${shots}${c.capturing ? `<span class="capturing"><span class="spin"></span>Capturing page…</span>` : ""}${canAdd ? `<button class="addshot" id="addshot">+ ${c.shots.length ? "Add another" : "Screenshot"}</button>
          <button class="addshot" id="timershot" title="Hides this for ${SHOT_TIMER_S} seconds so you can open a menu or hover something, then takes the screenshot">⏱ In ${SHOT_TIMER_S} s</button>` : ""}</div>
        ${recUi}
        <textarea id="cd" rows="4" placeholder="${c.recording ? "Start talking: what you say shows up here" : "Describe it"}"></textarea>
        <input id="ct" placeholder="Title (optional: we'll use your first sentence)" maxlength="200" />
        ${c.note ? `<div class="note">${esc(c.note)}</div>` : ""}
        ${c.error ? `<div class="err">${esc(c.error)}</div>` : ""}
        <div class="row-btns" style="margin-top:0">
          <button class="act" id="csend" ${c.sending || c.capturing ? "disabled" : ""}>${c.sending ? "Sending…" : this.admin ? "Send to Chef" : "Send"}</button>
          <button class="ghost" id="ccancel">Cancel</button>
        </div>
      </div>`;
    const $ = (sel) => this.$comp.querySelector(sel);
    const ti = $("#ct"), de = $("#cd");
    ti.value = c.title || ""; de.value = c.desc || "";
    ti.oninput = () => { c.title = ti.value; c.titleEdited = true; };
    de.oninput = () => { c.desc = de.value; c.descEdited = true; };
    this.onCmdEnter(de, () => this.sendComposer());
    $("#cx").onclick = $("#ccancel").onclick = () => this.closeComposer();
    $("#csend").onclick = () => this.sendComposer();
    if ($("#addshot")) $("#addshot").onclick = () => this.addScreenshot();
    if ($("#timershot")) $("#timershot").onclick = () => this.timedScreenshot();
    if ($("#stop")) $("#stop").onclick = () => this.stopRecording();
    if ($("#record")) $("#record").onclick = () => this.startRecording();
    if ($("#rerec")) $("#rerec").onclick = () => this.startRecording();
    if ($("#rmaudio")) $("#rmaudio").onclick = () => { URL.revokeObjectURL(c.audio.url); c.audio = null; this.renderComposer(); };
    this.$comp.querySelectorAll("[data-rm]").forEach((b) => b.onclick = (e) => {
      e.stopPropagation(); const i = +b.dataset.rm; URL.revokeObjectURL(c.shots[i].url); c.shots.splice(i, 1); this.renderComposer();
    });
    this.$comp.querySelectorAll("[data-ann]").forEach((d) => d.onclick = () => this.annotate(+d.dataset.ann));
  }

  // Simple red freehand markup on a screenshot.
  annotate(i) {
    const c = this.c; const shot = c && c.shots[i]; if (!shot) return;
    const img = new Image();
    img.onload = () => {
      const ann = document.createElement("div"); ann.className = "ann";
      ann.innerHTML = `<canvas></canvas><div class="hint">Draw to circle or point at things</div>
        <div class="bar"><button id="undo">Undo</button><button id="clear">Clear</button><button id="acancel">Cancel</button><button class="ok" id="done">Done</button></div>`;
      this.shadowRoot.appendChild(ann); this.$ann = ann;
      const cv = ann.querySelector("canvas"); cv.width = img.naturalWidth; cv.height = img.naturalHeight;
      const g = cv.getContext("2d");
      const strokes = []; let cur = null;
      const lw = Math.max(3, Math.round(img.naturalWidth / 300));
      const paint = () => {
        g.drawImage(img, 0, 0);
        g.strokeStyle = "#ef4444"; g.lineWidth = lw; g.lineCap = "round"; g.lineJoin = "round";
        for (const s of strokes) { g.beginPath(); s.forEach(([x, y], k) => (k ? g.lineTo(x, y) : g.moveTo(x, y))); if (s.length === 1) g.lineTo(s[0][0] + 0.1, s[0][1]); g.stroke(); }
      };
      const pt = (e) => { const r = cv.getBoundingClientRect(); return [((e.clientX - r.left) / r.width) * cv.width, ((e.clientY - r.top) / r.height) * cv.height]; };
      cv.onpointerdown = (e) => { try { cv.setPointerCapture(e.pointerId); } catch { /* capture is optional */ } cur = [pt(e)]; strokes.push(cur); paint(); };
      cv.onpointermove = (e) => { if (cur) { cur.push(pt(e)); paint(); } };
      cv.onpointerup = cv.onpointercancel = () => { cur = null; };
      const close = () => { ann.remove(); this.$ann = null; document.removeEventListener("keydown", onKey, true); };
      const onKey = (e) => { if (e.key === "Escape") { e.stopPropagation(); close(); } };
      document.addEventListener("keydown", onKey, true);
      ann.querySelector("#undo").onclick = () => { strokes.pop(); paint(); };
      ann.querySelector("#clear").onclick = () => { strokes.length = 0; paint(); };
      ann.querySelector("#acancel").onclick = close;
      ann.querySelector("#done").onclick = () => {
        if (!strokes.length) return close();
        cv.toBlob((b) => {
          close();
          if (!b || this.c !== c || !c.shots[i]) return;
          URL.revokeObjectURL(c.shots[i].url);
          c.shots[i] = { blob: b, url: URL.createObjectURL(b) };
          this.renderComposer();
        }, "image/png");
      };
      paint();
    };
    img.src = shot.url;
  }

  async upload(blob) {
    const postUrl = await this.client.mutation(this.ref("generateUploadUrl"), {});
    const res = await fetch(postUrl, { method: "POST", headers: { "Content-Type": blob.type || "application/octet-stream" }, body: blob });
    if (!res.ok) throw new Error(`upload failed (${res.status})`);
    const { storageId } = await res.json();
    return storageId;
  }

  async sendComposer() {
    const c = this.c; if (!c || c.sending) return;
    if (c.recording) await this.stopRecording();
    const transcript = c.transcript.trim();
    const description = (c.desc ?? transcript).trim();
    const title = (c.title || firstSentence(description) || (c.shots.length ? "Screenshot feedback" : "")).trim().slice(0, 200);
    if (!title) { c.error = "Say or type what you'd like."; return this.renderComposer(); }
    if (!this.client) { c.error = "Not connected yet — try again in a moment."; return this.renderComposer(); }
    c.sending = true; c.error = ""; this.renderComposer();
    try {
      const screenshotStorageIds = [];
      for (const s of c.shots) screenshotStorageIds.push(await this.upload(await fitShot(s.blob)));
      const audioStorageId = c.audio ? await this.upload(c.audio.blob) : undefined;
      await this.client.mutation(this.ref("submitRequestWithMedia"), {
        title, description, transcript: transcript || undefined, screenshotStorageIds, audioStorageId,
        context: { screen: (location.pathname + location.search).slice(0, 120) },
      });
      writeDraft(this.draftKey, "");
      this.closeComposer();
      this.showToast(this.sentMessage());
    } catch (e) {
      if (this.c !== c) return;
      if (isUnauth(e)) {
        c.error = "Sign in to send a request.";
      } else if (isMissingFn(e)) {
        // The host hasn't exposed the media functions: still file the request
        // as text so nothing the user said is lost.
        this.mediaOk = false;
        try {
          const desc = [description, transcript && transcript !== description ? `Voice note (transcript): ${transcript}` : ""].filter(Boolean).join("\n\n");
          await this.client.mutation(this.ref("submitRequest"), { title, description: desc });
          this.closeComposer();
          this.showToast(this.sentMessage());
          return;
        } catch (e2) { c.error = `Couldn't send: ${isUnauth(e2) ? "sign in first" : errMsg(e2)}`; }
      } else {
        c.error = `Couldn't send: ${errMsg(e)}`;
      }
      c.sending = false; this.renderComposer();
    }
  }
}

// How the panel gets Convex's browser client. Replace before the element
// connects to supply your own copy (or a test double):
//   ChefPanelElement.loadConvex = async () => ({ ConvexClient, makeFunctionReference });
ChefPanelElement.loadConvex = loadConvex;

const TABS = ["now", "builds", "requests"];
function readTab(prefix) { try { return localStorage.getItem(`chef-panel:tab:${prefix}`) || null; } catch { return null; } }
function writeTab(prefix, tab) { try { localStorage.setItem(`chef-panel:tab:${prefix}`, tab); } catch { /* storage unavailable */ } }
const MIC_WAIT_MS = 3000;
const SHOT_TIMER_S = 3;
const MIC_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 17v5"/></svg>`;
function wait(ms) { return new Promise((res) => setTimeout(res, ms)); }
/** Resolves after the browser has painted. */
function nextPaint() {
  return new Promise((res) => {
    if (typeof requestAnimationFrame === "function") requestAnimationFrame(() => setTimeout(res, 0));
    else setTimeout(res, 0);
  });
}
// Grow the request box with what's typed, up to its max-height.
function fitTextarea(ta) {
  ta.style.height = "auto";
  if (ta.scrollHeight) ta.style.height = `${Math.min(ta.scrollHeight + 2, 140)}px`;
}
function isRunning(status) { return status === "active" || status === "reconciling"; }
export function fmtUsd(n) { const v = Number.isFinite(n) ? Math.max(0, n) : 0; return `$${v.toFixed(2)}`; }
/** "$1.23", or "$0.40 so far" while the build is still going. */
export function runCostLabel(c) { return `${fmtUsd(c.spendUsd)}${isRunning(c.status) ? " so far" : ""}`; }
/** What the recent builds Chef knows the cost of came to, in words. */
export function costTotalsLine(costs) {
  if (!costs.length) return "";
  const total = costs.reduce((s, c) => s + (Number.isFinite(c.spendUsd) ? c.spendUsd : 0), 0);
  if (costs.length === 1) return `Your last build cost ${fmtUsd(total)}.`;
  return `Your last ${costs.length} builds cost ${fmtUsd(total)} in all, about ${fmtUsd(total / costs.length)} each.`;
}
/** "#67 Dark mode", or just "#67" for an untitled request. */
export function requestName(n) {
  const title = String(n.title ?? "").trim();
  return title ? `#${n.number} ${title}` : `#${n.number}`;
}

function isMissingFn(e) { return /Could not find (public )?function|Could not find module/i.test(String(e && e.message || e)); }
/** A repair commit for a failed run ("Chef can fix this: ... [Apply]"), or "". */
export function repairHtml(r, busy) {
  if (!r) return "";
  if (r.status === "making") return `<div class="repair small">Chef is preparing a fix for this…</div>`;
  if (r.status === "applying") return `<div class="repair small">Applying the fix…</div>`;
  if (r.status === "applied") return `<div class="repair small">Fix applied to main; building it again.</div>`;
  if (r.status === "declined") return "";
  if (r.status === "failed") return `<div class="repair small">Chef couldn't make a fix: ${esc(r.error || "unknown")}</div>`;
  const files = (r.files || []).map((f) => `<li><code>${esc(f.path)}</code> ${esc(f.how)}</li>`).join("");
  return `<div class="repair"><div><b>Chef can fix this:</b> ${esc(r.summary || "")}</div>${files ? `<ul class="small">${files}</ul>` : ""}
    <div class="row-btns"><button class="act" data-repair-apply="${esc(r.repairId)}" data-sha="${esc(r.sha || "")}" ${busy ? "disabled" : ""}>Apply</button>
    <span class="small">Moves main to the fix (commit <code>${esc((r.sha || "").slice(0, 12))}</code>), then builds again.</span></div></div>`;
}

/** What the admin can do about a release following main (the same as src/react/shipText.ts's followAction). */
export function followAction(f) {
  if (f.status === "needsApproval" && f.runId && f.diffHash) return "approve";
  if ((f.status === "failed" || f.status === "stalled") && f.shipRunId && f.approvedDiffHash) return "retry";
  return null;
}

/** What a merge-only build did (the same as src/react/shipText.ts's mergedMainText). */
export function mergedMainText(run) {
  if (!run.refresh || !run.mergedMain) return null;
  const m = run.mergedMain;
  const list = m.subjects.slice(0, 3).join("; ");
  const more = m.subjects.length > 3 ? `; and ${m.count - 3} more` : "";
  return `Main moved since you approved release #${run.refresh.releaseSeq}: Chef merged ${m.count} commit${m.count === 1 ? "" : "s"}` +
    `${list ? ` (${list}${more})` : ""} into this build, and its checks pass again.` +
    (run.refresh.sameDiff ? "" : " What ships changed with the merge, so approve it again.");
}

/** Where a ship is, in words (the same as src/react/ShipIt.tsx's shipStateText). */
export function shipStateText(r) {
  if (r.state === "done") return `Release #${r.seq} is live.`;
  if (r.state === "abandoned") return `Release #${r.seq} didn't ship${r.error ? "" : "."}`;
  if (r.state === "rolledBack") return `Release #${r.seq} was rolled back.`;
  if (r.error) return `Release #${r.seq} stopped (${r.state}). main is where it was.`;
  const doing = {
    approved: "deploying",
    backendDeployed: "backend deployed, publishing the frontend",
    frontendPublished: "published, checking the live site",
    verified: "verified, moving main",
    live: "live, finishing",
  };
  return `Release #${r.seq}: ${doing[r.state] || r.state}…`;
}

function errMsg(e) {
  const d = e && e.data; if (d && typeof d === "object" && d.message) return d.message;
  return String((e && e.message) || e).replace(/^\[CONVEX[^\]]*\]\s*/, "").replace(/^(\[Request ID: [^\]]*\]\s*)?Server Error\s*/, "").replace(/^Uncaught (Convex)?Error:\s*/, "").split("\n")[0].slice(0, 200);
}
function fmtMs(ms) { const s = Math.floor(ms / 1000); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; }
function firstSentence(t) {
  t = String(t || "").trim(); if (!t) return "";
  const m = t.match(/^(.+?[.!?])(\s|$)/);
  const s = (m ? m[1] : t.split("\n")[0]).trim();
  return s.length > 120 ? s.slice(0, 117).replace(/\s+\S*$/, "") + "…" : s;
}
let shotLib = null;
// Leave out the panel itself and browser-extension overlays: cloning an
// extension's custom element (e.g. 1Password's) re-runs its constructor and
// injects chrome-extension:// frames into the page.
const EXT_TAG = /^(COM-1PASSWORD|GRAMMARLY|LOOM|DASHLANE|BITWARDEN|LASTPASS|PLASMO|WXT)/;
function shotFilter(n) {
  const t = n && n.tagName;
  if (!t) return true;
  if (t === "CHEF-PANEL" || EXT_TAG.test(t)) return false;
  if (n.hasAttribute && n.hasAttribute("data-chef-panel")) return false;
  if (t === "IFRAME" && /^(chrome|moz|safari-web)-extension:/.test(n.getAttribute("src") || "")) return false;
  return true;
}
// Render the visible viewport to a PNG via a DOM snapshot (no screen-share
// prompt). <chef-panel> itself is filtered out of the clone.
async function capturePage() {
  shotLib = shotLib || import(/* webpackIgnore: true */ /* turbopackIgnore: true */ /* @vite-ignore */ SHOT_LIB);
  const { domToCanvas } = await shotLib;
  const body = document.body, rect = body.getBoundingClientRect();
  const scale = Math.min(window.devicePixelRatio || 1, 2);
  const bg = getComputedStyle(body).backgroundColor;
  const full = await domToCanvas(body, {
    scale,
    backgroundColor: bg && bg !== "rgba(0, 0, 0, 0)" ? bg : getComputedStyle(document.documentElement).backgroundColor || "#ffffff",
    filter: shotFilter,
    timeout: 8000,
    autoDestruct: true, // remove modern-screenshot's sandbox iframe afterwards
  });
  // Crop the body render to what is on screen right now.
  const vw = window.innerWidth, vh = window.innerHeight;
  const out = document.createElement("canvas");
  out.width = Math.round(vw * scale); out.height = Math.round(vh * scale);
  const g = out.getContext("2d");
  g.fillStyle = "#ffffff"; g.fillRect(0, 0, out.width, out.height);
  g.drawImage(full, -rect.left * scale, -rect.top * scale);
  return await new Promise((res, rej) => out.toBlob((b) => (b ? res(b) : rej(new Error("encode failed"))), "image/png"));
}
// Keep screenshots under the 10 MB cap: re-encode big PNGs as JPEG, shrinking if needed.
async function fitShot(blob) {
  if (blob.size <= MAX_SHOT_BYTES) return blob;
  const bmp = await createImageBitmap(blob);
  for (const k of [1, 0.75, 0.5, 0.35]) {
    const cv = document.createElement("canvas"); cv.width = Math.round(bmp.width * k); cv.height = Math.round(bmp.height * k);
    cv.getContext("2d").drawImage(bmp, 0, 0, cv.width, cv.height);
    const b = await new Promise((r) => cv.toBlob(r, "image/jpeg", 0.85));
    if (b && b.size <= MAX_SHOT_BYTES) return b;
  }
  throw new Error("Screenshot is too large");
}
function esc(s) { return String(s ?? "").replace(/[&<>"]/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[m])); }

function isUnauth(e) {
  const d = e && e.data;
  if (d && typeof d === "object" && d.code === "UNAUTHENTICATED") return true;
  return /not signed in|unauthenticated/i.test(String((e && e.message) || e));
}
function ago(ms) {
  const s = Math.max(0, Math.round((Date.now() - Number(ms)) / 1000));
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}
/** "just now", "5 minutes ago", "yesterday", "2 days ago", "3 weeks ago", or a date. */
function relTime(ms) {
  const s = Math.max(0, Math.round((Date.now() - Number(ms)) / 1000));
  const n = (k, unit) => `${k} ${unit}${k === 1 ? "" : "s"} ago`;
  if (s < 60) return "just now";
  if (s < 3600) return n(Math.floor(s / 60), "minute");
  if (s < 86400) return n(Math.floor(s / 3600), "hour");
  const d = Math.floor(s / 86400);
  if (d === 1) return "yesterday";
  if (d < 7) return n(d, "day");
  if (d < 35) return n(Math.floor(d / 7), "week");
  try { return new Date(Number(ms)).toLocaleDateString(undefined, { month: "short", day: "numeric", year: d > 300 ? "numeric" : undefined }); }
  catch { return n(Math.floor(d / 30), "month"); }
}
// A half-typed request survives reloads (per tab). Best effort only.
function readDraft(key) { try { return sessionStorage.getItem(key) || ""; } catch { return ""; } }
function writeDraft(key, v) { try { if (v) sessionStorage.setItem(key, v); else sessionStorage.removeItem(key); } catch { /* storage unavailable */ } }

// ---- hidden characters: the same rules as src/react/revealInvisible.ts ----
// Zero-width characters, bidi controls, tag characters, variation selectors,
// other format and control characters and lone surrogates each become a
// visible <U+XXXX> marker, so an approval shows every character the build
// will see. tests/chefPanelElement.test.ts checks the two agree.
export function isInvisibleCodePoint(cp) {
  if (cp < 0x20) return cp !== 0x0a && cp !== 0x09;
  return (
    (cp >= 0x7f && cp <= 0x9f) || cp === 0x00ad || cp === 0x034f || cp === 0x061c ||
    cp === 0x115f || cp === 0x1160 || cp === 0x3164 || cp === 0xffa0 ||
    cp === 0x17b4 || cp === 0x17b5 || (cp >= 0x180b && cp <= 0x180f) ||
    (cp >= 0x200b && cp <= 0x200f) || (cp >= 0x2028 && cp <= 0x202e) || (cp >= 0x2060 && cp <= 0x206f) ||
    (cp >= 0xfe00 && cp <= 0xfe0f) || cp === 0xfeff || (cp >= 0xfff0 && cp <= 0xfffb) ||
    (cp >= 0x1d173 && cp <= 0x1d17a) || (cp >= 0xe0000 && cp <= 0xe0fff) || (cp >= 0xd800 && cp <= 0xdfff)
  );
}
const marker = (cp) => `<U+${cp.toString(16).toUpperCase().padStart(4, "0")}>`;
/** The text with every hidden character replaced by its <U+XXXX> marker. */
export function revealInvisible(text) {
  let out = "";
  for (const ch of String(text ?? "")) { const cp = ch.codePointAt(0); out += isInvisibleCodePoint(cp) ? marker(cp) : ch; }
  return out;
}
function countInvisible(text) {
  let n = 0;
  for (const ch of String(text ?? "")) if (isInvisibleCodePoint(ch.codePointAt(0))) n++;
  return n;
}
/** Escaped HTML of the text, hidden characters as highlighted markers. Never truncates. */
function revealedHtml(text) {
  let out = "", run = "";
  for (const ch of String(text ?? "")) {
    const cp = ch.codePointAt(0);
    if (isInvisibleCodePoint(cp)) { out += esc(run); run = ""; out += `<span class="hid" title="Hidden character">${esc(marker(cp))}</span>`; }
    else run += ch;
  }
  return out + esc(run);
}

// Only http(s) links reach an href or src.
function safeUrl(u) { return typeof u === "string" && /^https?:\/\//i.test(u) ? u : null; }

/**
 * An approval snapshot in full: every character of the title, description
 * and transcript, hidden ones as markers, and every attachment listed inline
 * with its type, size and hash.
 */
export function snapshotHtml(snap) {
  const hidden = countInvisible(snap.title) + countInvisible(snap.description) + countInvisible(snap.transcript || "");
  const atts = snap.attachments || [];
  const attHtml = atts.map((a, i) => {
    const url = safeUrl(a.url);
    const body = a.kind === "screenshot" && url ? `<a href="${esc(url)}" target="_blank" rel="noopener"><img src="${esc(url)}" alt="Screenshot ${i + 1}" /></a>`
      : a.kind === "audio" && url ? `<audio controls preload="none" src="${esc(url)}"></audio>`
      : `<div>Attachment ${i + 1} is unavailable.</div>`;
    return `<figure>${body}<figcaption>${esc(a.contentType)} · ${esc(a.size)} bytes · sha256 ${esc(String(a.sha256).slice(0, 12))}</figcaption></figure>`;
  }).join("");
  return `<div class="snap" dir="ltr">
    ${hidden > 0 ? `<div class="snapwarn" role="alert">This request contains ${hidden} hidden character${hidden === 1 ? "" : "s"}, shown as <span class="hid">&lt;U+XXXX&gt;</span> markers.</div>` : ""}
    <div class="snapt">${revealedHtml(snap.title)}</div>
    <div class="snapd">${revealedHtml(snap.description)}</div>
    ${snap.transcript !== null && snap.transcript !== undefined ? `<div class="snapl">Voice note transcript</div><div class="snapd">${revealedHtml(snap.transcript)}</div>` : ""}
    <div class="snapl">${atts.length === 0 ? "No attachments" : `${atts.length} attachment${atts.length === 1 ? "" : "s"}`}</div>
    ${attHtml}
    <div class="snaph">snapshot ${esc(String(snap.contentHash).slice(0, 16))}</div>
  </div>`;
}

const PHASE_GLYPH = { done: "✓", now: "●", stopped: "■", todo: "○" };
function agoShort(ms) {
  const s = Math.max(0, Math.round((Date.now() - Number(ms)) / 1000));
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  return `${Math.round(s / 3600)}h ago`;
}

/**
 * One cloud run for admins: the phase list, status, spend, model calls,
 * heartbeat, the preview and its one-time sign-in link, screenshots, skill
 * notes, spend approval requests and the run log (collapsed unless
 * `logOpen`).
 */
/**
 * The plain-language Ship card (buildCard): what changed and what to try
 * (the agents' words, escaped text only), the preview, the screenshots and
 * the risk flags (from the diff, by fixed rules). One column, for a phone.
 */
export function cardHtml(card, o = {}) {
  const reqs = card.requests || [];
  const many = reqs.length > 1;
  const said = reqs.some((r) => r.wroteSummary);
  const together = reqs.some((r) => (r.builtWith || []).length);
  const changed = reqs.map((r) => `${many ? `<div class="creq">${r.number !== null && r.number !== undefined ? `<span class="small">#${esc(r.number)} </span>` : ""}${esc(r.title)}${
    (r.builtWith || []).length ? ` <span class="small btogether">(built together with ${esc(r.builtWith.map((n) => `#${n}`).join(", "))})</span>` : ""}</div>` : ""}${
    (r.whatChanged || []).length ? `<ul class="cchanged">${r.whatChanged.map((t) => `<li>${esc(t)}</li>`).join("")}</ul>` : ""}`).join("");
  const tries = reqs.flatMap((r) => r.whatToTry || []);
  const preview = safeUrl(card.previewUrl), login = safeUrl(card.previewLoginUrl);
  const yours = card.previewHasYourData ? `<p class="small cyours">This preview has a copy of your own data.</p>` : "";
  const links = preview || login ? `${yours}<div class="links">
      ${login && !o.loginUsed ? `<a class="act" data-card-login="${esc(card.runId)}" href="${esc(login)}" target="_blank" rel="noopener" title="A one-time sign-in link: it works once">Try it, signed in</a>` : ""}
      ${preview ? `<a class="ghost" href="${esc(preview)}" target="_blank" rel="noopener">Open the preview</a>` : ""}
    </div>` : "";
  const shots = (card.screenshots || []).map((x) => {
    const url = safeUrl(x.url);
    return url ? `<a href="${esc(url)}" target="_blank" rel="noopener" title="${esc(`${x.name} (${x.path})`)}"><img src="${esc(url)}" alt="${esc(x.name)}" loading="lazy" /></a>` : "";
  }).join("");
  const ic = card.iosCheck, mark = (ok) => (ok ? "✓" : "✗");
  const iosLine = ic ? `On ${ic.device || "an iPhone"}: compiled ${mark(ic.compiled)} installed ${mark(ic.installed)}${ic.error ? ` (${ic.error})` : ""}`
    : `Not tried on an iPhone yet: npx chef ios ${card.runId}`;
  const flags = (card.flags || []).map((f) => `<li class="flag" data-kind="${esc(f.kind)}"><b>⚠ ${esc(f.label)}</b><code>${esc((f.files || []).join(", "))}${
    f.count > (f.files || []).length ? esc(`, and ${f.count - f.files.length} more`) : ""}</code>${f.kind === "ios" ? `<div class="small cios">${esc(iosLine)}</div>` : ""}</li>`).join("");
  const vids = (card.videos || []).filter((x) => safeUrl(x.url));
  const main = vids.find((x) => x.viewport === "phone") || vids[0];
  const video = main ? `<div class="cvideo"><video src="${esc(safeUrl(main.url))}" controls playsinline muted preload="metadata"></video>
    <div class="small">The feature being used on the preview (${esc(main.viewport)}, ${esc(Math.round((main.durationMs || 0) / 1000))} s)${
      vids.filter((x) => x !== main).map((x) => ` · <a href="${esc(safeUrl(x.url))}" target="_blank" rel="noopener">${esc(x.viewport)} video</a>`).join("")}</div></div>` : "";
  const b = card.beta, betaUrl = b ? safeUrl(b.siteUrl) : null;
  const beta = b && (b.onBeta || b.status) ? `<p class="small cbeta">${b.onBeta
    ? `On the beta${betaUrl ? `: <a href="${esc(betaUrl)}" target="_blank" rel="noopener">open it</a>` : ""}. Promote it to everyone when it's ready.`
    : b.status === "deploying" ? "Deploying to the beta…" : esc(b.note || "Not on the beta.")}</p>` : "";
  return `<div class="card">
    ${beta}${video}${card.demoNote ? `<p class="muted cdemonote">${esc(card.demoNote)}</p>` : ""}${card.previewNote ? `<p class="muted cpreviewnote">${esc(card.previewNote)}</p>` : ""}
    <div><div class="ch">What changed</div>${together ? `<p class="small">One build for ${esc(reqs.length)} requests: Ship it ships them all.</p>` : ""}${said ? "" : `<p class="muted">The agent didn't describe this build in plain words. Open the preview, or read the details.</p>`}${changed}</div>
    ${tries.length ? `<div><div class="ch">What to try</div><ol class="ctry">${tries.map((t) => `<li>${esc(t)}</li>`).join("")}</ol></div>` : ""}
    ${links}
    ${shots ? `<div><div class="ch">After</div><div class="cshots">${shots}</div></div>` : ""}
    <div><div class="ch">Worth a look</div>${flags ? `<ul class="flags">${flags}</ul>` : `<p class="muted cnoflags">Nothing in the ${
      card.flagsFrom === "diff" ? "change" : "changed files' names"} touches sign-in, data, payments, secrets, sharing, dependencies or iOS.</p>`}</div>
  </div>`;
}

export function runHtml(run, o = {}) {
  const finished = run.status !== "active" && run.status !== "reconciling";
  const preview = safeUrl(run.previewUrl), login = safeUrl(run.previewLoginUrl);
  const links = (preview || login) && !o.hideLinks ? `<div class="links">
      ${login && !o.loginUsed ? `<a class="act" id="preview-login" href="${esc(login)}" target="_blank" rel="noopener" title="A one-time sign-in link: it works once">Open the preview, signed in</a>` : ""}
      ${preview ? `<a class="ghost" href="${esc(preview)}" target="_blank" rel="noopener">Open the preview</a>` : ""}
      ${login ? `<span class="small">${o.loginUsed ? "Sign-in link used. It works once." : "The sign-in link works once."}</span>` : ""}
    </div>` : "";
  const phases = (run.phases || []).map((p) =>
    `<li class="ph ${esc(p.state)}" data-state="${esc(p.state)}"><span class="pg">${PHASE_GLYPH[p.state] || "○"}</span>${esc(p.label)}</li>`).join("");
  const fact = (k, v) => `<dt>${esc(k)}</dt><dd>${v}</dd>`;
  const facts = [
    fact("Spend so far", esc(`$${Number(run.spendUsd || 0).toFixed(2)}`)),
    fact("Model calls", esc(`${run.aiRequests}${run.aiInFlight > 0 ? ` (${run.aiInFlight} running)` : ""}`)),
    fact("Last heartbeat", finished ? "-" : esc(agoShort(run.heartbeatAt))),
    run.branch ? fact("Branch", `<code>${esc(run.branch)}</code>`) : "",
    run.commitSha ? fact("Commit", `<code>${esc(run.commitSha.slice(0, 12))}</code>`) : "",
    (run.filesChanged || []).length ? fact("Files changed", esc(run.filesChanged.length)) : "",
    (run.attempt || 1) > 1 ? fact("Attempt", esc(`${run.attempt} (Chef retried a platform failure)`)) : "",
    run.convexPlugin ? fact("Convex plugin", esc(run.convexPlugin)) : "",
  ].join("");
  // A failed run: what went wrong and what to do; the raw error folded away.
  const f = run.failure;
  const failed = run.status === "failed" || run.status === "cancelled";
  const retryLine = run.retryAt
    ? `Chef tries again on its own ${run.retryAt > Date.now() ? `in ${Math.max(1, Math.round((run.retryAt - Date.now()) / 60000))} min` : "now"}.`
    : f ? f.action : "";
  const rec = run.recovery;
  const recLine = rec && rec.action === "stop" ? "Stopped for safety: Chef won't retry or repair this on its own."
    : rec && rec.action === "fixRound" ? "Chef is building it once more, told why the preview failed."
    : rec && rec.action === "repair" ? "Chef can fix this in the repo; see the repair below." : "";
  const failBox = failed && (f || run.error) ? `<div class="bfail" role="alert">
      ${f ? `<div class="fr">${esc(f.reason)}</div><div>${esc(retryLine)}</div>` : ""}
      ${recLine ? `<div class="small rec">${esc(recLine)}</div>` : ""}
      ${repairHtml(run.repair, o.busy)}
      ${run.canRetry ? `<div class="row-btns"><button class="act" id="run-retry" ${o.retryBusy ? "disabled" : ""}>${o.retryBusy ? "Starting…" : "Try again"}</button>${
        o.retryNote ? `<span class="small">${esc(o.retryNote)}</span>` : ""}</div>` : ""}
      ${run.error ? `<details><summary>Details</summary><pre class="berr">${esc(run.error)}</pre></details>` : ""}
    </div>` : "";
  const gates = (run.gates || []).map((g) => `<tr><td><code>${esc(g.command)}</code></td>
      <td class="${g.baseline === "fail" ? "fail" : g.baseline === "pass" ? "pass" : "pre"}">${
        g.baseline === "fail" ? (g.baselineOn === "main" ? "failing on main" : "failing before this build") : g.baseline === "pass" ? "passed" : "not run"}${g.baselineCached ? " (cached)" : ""}</td>
      <td class="${g.result === "pass" ? "pass" : g.result === "fail" ? (g.blocking ? "fail" : "pre") : "pre"}">${
        g.result === null || g.result === undefined ? "–" : g.result === "pass" ? "passes" : g.blocking ? "fails" : "still fails (didn't block)"}</td></tr>${
        g.note ? `<tr><td colspan="3" class="small">${esc(g.note)}</td></tr>` : ""}`).join("");
  const rounds = (run.rounds || []).map((x) => `<li>Fix round ${esc(x.round)} of ${esc(run.fixRounds || x.round)}: ${esc(x.reason)} <span class="small">· started at ${esc(`$${Number(x.spendUsd || 0).toFixed(2)}`)}</span></li>`).join("");
  const gatesHtml = (gates ? `<div class="lbl">Checks</div><table class="gates"><tr><th>Check</th><th>Before</th><th>After</th></tr>${gates}</table>` : "") +
    (rounds ? `<ol class="rounds small">${rounds}</ol>` : "") +
    (run.summary || run.diffStat ? `<details class="attempt"><summary class="small">What the agent tried</summary>${
      run.summary ? `<p class="small" style="white-space:pre-wrap">${esc(run.summary)}</p>` : ""}${run.diffStat ? `<pre class="berr" style="color:inherit">${esc(run.diffStat)}</pre>` : ""}</details>` : "");
  const shots = (o.shots || []).map((x) => {
    const url = safeUrl(x.url);
    return url ? `<a href="${esc(url)}" target="_blank" rel="noopener" title="${esc(`${x.name} (${x.path})`)}"><img src="${esc(url)}" alt="${esc(x.name)}" loading="lazy" /></a>`
      : `<span class="small">${esc(x.name)} (unavailable)</span>`;
  }).join("");
  const asks = o.asks || [];
  const pending = asks.filter((a) => a.status === "pending").length;
  const askHtml = asks.map((a) => `<div class="spend">
      <div class="at">${esc(a.action)}</div>
      <div class="small">${esc(a.why)}</div>
      <pre>${esc(a.commandOrSteps)}</pre>
      <div class="small">${a.estimatedCostUsd === null || a.estimatedCostUsd === undefined ? "cost unknown" : esc(`about $${Number(a.estimatedCostUsd).toFixed(2)}`)}${a.skill ? ` · from the ${esc(a.skill)} skill` : ""}</div>
      ${a.status === "pending" ? `<div class="row-btns">
        <button class="act" data-spend-approve="${esc(a.id)}" ${o.busy ? "disabled" : ""}>Approve</button>
        <button class="ghost" data-spend-decline="${esc(a.id)}" ${o.busy ? "disabled" : ""}>Decline</button></div>`
        : `<div class="decided ${esc(a.status)}">${a.status === "approved" ? "Approved" : "Declined"}${a.decisionNote ? ` · ${esc(a.decisionNote)}` : ""}</div>`}
    </div>`).join("");
  const notes = (o.notes || []).map((f) =>
    `<div class="skn"><code>${esc(f.skill)}</code> <span class="small">${esc(f.kind)}</span> ${esc(f.message)}${f.suggestion ? ` <span class="small">Suggests: ${esc(f.suggestion)}</span>` : ""}</div>`).join("");
  let log = "";
  if (o.logOpen) {
    const pages = o.logPages || [];
    const lines = pages.flatMap((p) => (p.data ? p.data.page : []).flatMap((b) => b.lines));
    const last = pages[pages.length - 1];
    const loading = last && last.data === undefined;
    const next = last && last.data ? last.data.nextCursor : null;
    log = `<div class="runlog">${lines.map((l) => `<div class="ll">${esc(l)}</div>`).join("")}${loading ? `<div class="small">Loading…</div>` : ""}${
      next !== null && next !== undefined ? `<button class="ghost" id="logmore" data-cursor="${esc(next)}">Load more</button>` : ""}</div>`;
  }
  return `<div class="build">
    <div class="small">Build #${esc(run.seq)} · started ${esc(agoShort(run.createdAt))}${run.builtLocallyOn ? ` · built locally on ${esc(run.builtLocallyOn)}` : ""}</div>
    <div class="bstatus ${esc(run.status)}">${esc(run.statusText)}</div>
    ${run.batch && (run.batch.requests || []).length > 1 ? `<div class="bbatch small">One build for ${esc(run.batch.requests.length)} requests: ${
      esc(run.batch.requests.map((x) => `#${x.number} ${x.title}`).join(" · "))}</div>` : ""}
    ${links}
    ${failBox}
    ${finished && !failed ? `<details class="phd"><summary>Steps and details</summary><ol class="phases">${phases}</ol><dl class="facts">${facts}</dl></details>`
      : `<ol class="phases">${phases}</ol><dl class="facts">${facts}</dl>`}
    ${gatesHtml}
    ${shots ? `<div class="lbl">Screenshots</div><div class="bshots">${shots}</div>` : ""}
    ${asks.length ? `<div class="lbl">${pending > 0 ? `Waiting for you (${pending})` : "Approval requests"}</div>
      <p class="small">The build may not spend money or act for you on its own, so it asked. Approving records your answer; nothing runs it yet.</p>
      ${o.error ? `<div class="flash">${esc(o.error)}</div>` : ""}${askHtml}` : ""}
    ${notes ? `<div class="lbl">Notes on its skills</div>${notes}` : ""}
    <button class="ghost" id="runlog" aria-expanded="${o.logOpen ? "true" : "false"}">${o.logOpen ? "Hide the run log" : "Show the run log"}</button>
    ${log}
  </div>`;
}

/** Register <chef-panel> (idempotent; a no-op outside the browser). */
export function defineChefPanel() {
  if (typeof customElements !== "undefined" && !customElements.get("chef-panel")) {
    customElements.define("chef-panel", ChefPanelElement);
  }
}
defineChefPanel();
