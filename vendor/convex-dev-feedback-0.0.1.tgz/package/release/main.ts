// The `chef-release` command line. `chef-release.mjs` loads this after
// installing hooks so Node can run the TypeScript, including from
// node_modules.
//
//   chef-release prepare                 pin chef and main, upload the diff
//   chef-release ship [<n>]              prepare if nothing is open, then drive to done
//   chef-release resume [<n>]            continue a release from its last checkpoint
//   chef-release rollback <n> [--reason <text>]
//   chef-release drop <request number> [--reason <text>]
//   chef-release abandon <n> [--reason <text>]
//
// Options: --config <file> (default ./chef-release.json), --operator <name>,
// --wait <minutes> (how long ship waits for the panel approval; default 30).
//
// Exit codes: 0 done, 1 failed, 2 usage, 3 refused, 4 still waiting for approval.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { spawn } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { hostname, userInfo } from "node:os";
import { isAbsolute, join, resolve } from "node:path";
import { Releaser, ReleaseError, type Config, type Deps, type Exec, type Release } from "./release.ts";

const USAGE = `usage: chef-release <prepare | ship [n] | resume [n] | rollback <n> | drop <request> | abandon <n>>
  [--config <file>] [--operator <name>] [--wait <minutes>] [--reason <text>]`;

type FileConfig = Partial<Omit<Config, "cwd" | "remoteUrl" | "cliVersion" | "operator">> & {
  /** A git remote name in the app's checkout, or a URL or path. Default "origin". */
  remote?: string;
  operator?: string;
};

/** Spawns a program and collects its output. Never through a shell. */
export const spawnExec: Exec = (cmd, args, opts) =>
  new Promise((done) => {
    const child = spawn(cmd, args, {
      cwd: opts.cwd,
      env: { ...process.env, ...(opts.env ?? {}) },
      stdio: ["ignore", "pipe", "pipe"],
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => (stdout += d));
    child.stderr.on("data", (d) => (stderr += d));
    child.on("error", (e) => done({ code: 127, stdout, stderr: stderr + String(e) }));
    child.on("close", (code) => done({ code: code ?? 1, stdout, stderr }));
  });

export const defaultDeps = (): Deps => ({
  exec: spawnExec,
  now: () => Date.now(),
  sleep: (ms) => new Promise((r) => setTimeout(r, ms)),
  fetch: async (url) => {
    const r = await fetch(url, { redirect: "follow" });
    return { ok: r.ok, status: r.status };
  },
  log: (line) => process.stderr.write(line + "\n"),
});

function cliVersion(): string {
  try {
    const pkg = JSON.parse(readFileSync(new URL("../package.json", import.meta.url), "utf8"));
    return `chef-release/${pkg.version}`;
  } catch {
    return "chef-release";
  }
}

function slug(s: string): string {
  return s.replace(/[^A-Za-z0-9@._+-]+/g, "-").slice(0, 100);
}

async function defaultOperator(cwd: string, exec: Exec): Promise<string> {
  const r = await exec("git", ["config", "user.email"], { cwd });
  const who = r.code === 0 && r.stdout.trim() ? r.stdout.trim() : userInfo().username;
  return slug(`${who}@${hostname()}`);
}

export async function loadConfig(
  cwd: string,
  flags: { config?: string; operator?: string; waitMinutes?: number },
  exec: Exec,
): Promise<Config> {
  const path = resolve(cwd, flags.config ?? "chef-release.json");
  const file: FileConfig = existsSync(path) ? JSON.parse(readFileSync(path, "utf8")) : {};
  if (flags.config && !existsSync(path)) throw new ReleaseError(`No config at ${path}`, 2);
  const remote = file.remote ?? "origin";
  let remoteUrl = remote;
  if (!/[/:]/.test(remote)) {
    const r = await exec("git", ["remote", "get-url", remote], { cwd });
    if (r.code !== 0) throw new ReleaseError(`No git remote "${remote}" in ${cwd}; set "remote" in the config`, 2);
    remoteUrl = r.stdout.trim();
  }
  const stateDir = file.stateDir ? (isAbsolute(file.stateDir) ? file.stateDir : join(cwd, file.stateDir)) : join(cwd, ".chef-release");
  const frontend = file.frontend ?? { convexApp: [], staticHosting: [] };
  return {
    cwd,
    stateDir,
    module: file.module ?? "chefPipeline",
    remoteUrl,
    prod: file.prod ?? true,
    convex: file.convex ?? ["npx", "convex"],
    operator: slug(flags.operator ?? file.operator ?? (await defaultOperator(cwd, exec))),
    install: file.install === undefined ? ["npm", "ci"] : file.install,
    gates: file.gates ?? [
      ["npm", "run", "lint"],
      ["npx", "tsc", "--noEmit"],
      ["npm", "test"],
      ["npm", "run", "build"],
    ],
    buildDir: file.buildDir ?? "dist",
    frontend: { convexApp: frontend.convexApp ?? [], staticHosting: frontend.staticHosting ?? [] },
    verify: file.verify ?? {},
    approvalTimeoutMs:
      flags.waitMinutes !== undefined ? flags.waitMinutes * 60_000 : (file.approvalTimeoutMs ?? 30 * 60_000),
    pollMs: file.pollMs ?? 10_000,
    cliVersion: cliVersion(),
  };
}

function summary(rel: Release): string {
  return `release #${rel.seq} ${rel.state}${rel.mergeSha ? ` merge ${rel.mergeSha}` : ""}${rel.artifactDigest ? ` artifact ${rel.artifactDigest}` : ""}`;
}

export async function main(
  argv: string[],
  opts: { cwd?: string; deps?: Partial<Deps> } = {},
): Promise<number> {
  const deps: Deps = { ...defaultDeps(), ...(opts.deps ?? {}) };
  try {
    return await run(argv, opts.cwd ?? process.cwd(), deps);
  } catch (e) {
    if (e instanceof ReleaseError) {
      deps.log(`chef-release: ${e.message}`);
      return e.code;
    }
    deps.log(`chef-release: ${e instanceof Error ? e.message : String(e)}`);
    return 1;
  }
}

async function run(argv: string[], cwd: string, deps: Deps): Promise<number> {
  const out = (s: string) => process.stdout.write(s + "\n");
  const positional: string[] = [];
  const flags: { config?: string; operator?: string; waitMinutes?: number; reason?: string } = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const val = () => {
      const x = argv[++i];
      if (x === undefined) throw new ReleaseError(`${a} needs a value\n${USAGE}`, 2);
      return x;
    };
    if (a === "--config") flags.config = val();
    else if (a === "--operator") flags.operator = val();
    else if (a === "--reason") flags.reason = val();
    else if (a === "--wait") {
      const m = Number(val());
      if (!Number.isFinite(m) || m < 0 || m > 24 * 60) {
        deps.log(`--wait takes minutes, 0 to 1440\n${USAGE}`);
        return 2;
      }
      flags.waitMinutes = m;
    } else if (a === "-h" || a === "--help") {
      out(USAGE);
      return 0;
    } else if (a.startsWith("-")) {
      deps.log(`Unknown option ${a}\n${USAGE}`);
      return 2;
    } else positional.push(a);
  }
  const [cmd, arg] = positional;
  const num = (required: boolean): number | undefined => {
    if (arg === undefined) {
      if (required) throw new ReleaseError(`${cmd} needs a number\n${USAGE}`, 2);
      return undefined;
    }
    const n = Number(arg.replace(/^#/, ""));
    if (!Number.isInteger(n) || n < 1) throw new ReleaseError(`Not a number: ${arg}\n${USAGE}`, 2);
    return n;
  };
  {
    if (!cmd || positional.length > 2) throw new ReleaseError(USAGE, 2);
    const cfg = await loadConfig(cwd, flags, deps.exec);
    const r = new Releaser(cfg, deps);
    switch (cmd) {
      case "prepare":
        if (arg !== undefined) throw new ReleaseError(USAGE, 2);
        out(summary(await r.prepare()));
        return 0;
      case "ship":
        out(summary(await r.ship(num(false))));
        return 0;
      case "resume":
        out(summary(await r.resume(num(false))));
        return 0;
      case "rollback":
        out(summary(await r.rollback(num(true)!, flags.reason ?? "rolled back with chef-release")));
        return 0;
      case "abandon":
        out(summary(await r.abandon(num(true)!, flags.reason ?? "abandoned with chef-release")));
        return 0;
      case "drop": {
        const res = await r.drop(num(true)!, flags.reason);
        out(res.revertSha ? `dropped: ${res.revertSha}` : "nothing to drop");
        return 0;
      }
      default:
        throw new ReleaseError(USAGE, 2);
    }
  }
}
