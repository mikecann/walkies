// `chef-release`: the release state machine's driver (docs/chef-pipeline.md,
// "Release: one state machine around one sha"). It runs on the operator's
// machine with their Convex CLI login and git access to Code Storage, and
// records every step in Convex through the host's internal functions
// (src/client/chefRelease.ts) before and after it runs, so an interrupted release
// resumes from its last checkpoint.
//
// What it never does: approve a diff (that is the panel's, by an admin),
// force-push anything, or print an env value.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { createHash } from "node:crypto";
import { copyFileSync, existsSync, mkdirSync, readFileSync, renameSync, rmSync } from "node:fs";
import { join } from "node:path";
import {
  FRONTEND_TARGETS,
  GIT_SHA,
  RELEASE_DIFF_ARGS,
  releaseBranch,
  releaseDiffHash,
  type FrontendTarget,
  type ReleaseState,
} from "../src/chef/release.ts";
import { scrub } from "../src/chef/scrub.ts";

// ------------------------------------------------------------------ types

export type ExecResult = { code: number; stdout: string; stderr: string };
export type Exec = (
  cmd: string,
  args: string[],
  opts: { cwd: string; env?: Record<string, string | undefined> },
) => Promise<ExecResult>;

export type Deps = {
  /** Runs a program: git, tar, the convex CLI, the gates and the publishers. */
  exec: Exec;
  now: () => number;
  sleep: (ms: number) => Promise<void>;
  /** For the site check after the deploy. */
  fetch: (url: string) => Promise<{ ok: boolean; status: number }>;
  /** Progress, for the operator (stderr). */
  log: (line: string) => void;
};

export type Config = {
  /** The app's checkout: where `npx convex` finds the project, and `.env.local`. */
  cwd: string;
  /** Work clone, build checkouts and artifacts (default `<cwd>/.chef-release`). */
  stateDir: string;
  /** The host module with the release functions (default `chefPipeline`). */
  module: string;
  /** Code Storage: a git URL or path. */
  remoteUrl: string;
  /** Run against prod (`--prod`). Off only for trying it on a dev deployment. */
  prod: boolean;
  /** How to invoke the Convex CLI (default `npx convex`). */
  convex: string[];
  /** Who is releasing, for the audit log. */
  operator: string;
  /** Install before the gates and the deploy (default `npm ci`); null to skip. */
  install: string[] | null;
  /** The gates, in order (default lint, tsc, tests, build). */
  gates: string[][];
  /** The frontend build output, relative to the checkout (default `dist`). */
  buildDir: string;
  /** How to publish the artifact to each target; `{dir}` is the unpacked artifact. */
  frontend: Record<FrontendTarget, string[]>;
  verify: { url?: string; healthCheck?: string; requiredEnv?: string[] };
  /** How long `ship` waits for the panel approval, and how often it looks. */
  approvalTimeoutMs: number;
  pollMs: number;
  cliVersion: string;
};

export type Release = {
  _id: string;
  seq: number;
  kind: "chef" | "cloud" | "rollback";
  state: ReleaseState | "abandoned" | "rolledBack";
  open: boolean;
  sha: string;
  baseSha: string;
  createdAt: number;
  diffHash?: string;
  approvedDiffHash?: string;
  mergeSha?: string;
  releaseBranch?: string;
  artifactDigest?: string;
  targets: Partial<Record<FrontendTarget, { digest: string }>>;
  mainSha?: string;
  rollbackOf?: number;
  restores?: number;
  inFlight?: { to: string };
};

type RunRef = {
  runId: string;
  seq: number;
  itemNumber: number | null;
  commitSha: string | null;
  finishedAt: number | null;
};

/** Exit codes: 0 done, 1 failed, 2 usage, 3 refused, 4 still waiting for approval. */
export class ReleaseError extends Error {
  code: number;
  constructor(message: string, code = 1) {
    super(message);
    this.code = code;
  }
}
const refuse = (message: string) => new ReleaseError(message, 3);

const GIT_BASE = [
  "-c", "core.hooksPath=/dev/null",
  "-c", "commit.gpgSign=false",
  "-c", "tag.gpgSign=false",
  "-c", "core.quotePath=true",
  "-c", "diff.noprefix=false",
  "-c", "diff.mnemonicPrefix=false",
  "-c", "diff.relative=false",
  "-c", "merge.ff=false",
  "-c", "advice.detachedHead=false",
];

/** The fixed identity of merge, rollback and drop commits, so a merge can be recreated exactly. */
const BOT_NAME = "Chef release";
const BOT_EMAIL = "chef-release@users.noreply.convex.dev";

/** Diff options that don't depend on the operator's git config (shared with the runner). */
const DIFF_ARGS = [...RELEASE_DIFF_ARGS];

const short = (s: string | undefined) => (s ? s.slice(0, 12) : "none");

export class Releaser {
  cfg: Config;
  deps: Deps;
  repo: string;

  constructor(cfg: Config, deps: Deps) {
    this.cfg = cfg;
    this.deps = deps;
    this.repo = join(cfg.stateDir, "repo");
  }

  // ---------------------------------------------------------------- convex

  /** `convex run [--prod] <module>:<name> <json>`; the printed result, parsed. */
  async call<R>(name: string, args: Record<string, unknown>): Promise<R> {
    const [cmd, ...pre] = this.cfg.convex;
    const json = JSON.stringify(args);
    if (json.length > 900_000) throw new ReleaseError(`Arguments for ${name} are too large for a command line`);
    const r = await this.deps.exec(
      cmd,
      [...pre, "run", ...(this.cfg.prod ? ["--prod"] : []), `${this.cfg.module}:${name}`, json],
      { cwd: this.cfg.cwd },
    );
    if (r.code !== 0) {
      throw new ReleaseError(`${this.cfg.module}:${name} failed: ${scrub(lastLines(r.stderr || r.stdout, 15))}`);
    }
    const out = r.stdout.trim();
    // The CLI prints nothing for null, and JSON otherwise when not on a TTY.
    if (!out) return null as R;
    try {
      return JSON.parse(out) as R;
    } catch {
      throw new ReleaseError(`${this.cfg.module}:${name} printed something that isn't JSON`);
    }
  }

  async status(seq?: number): Promise<Release | null> {
    return await this.call<Release | null>("releaseStatus", seq !== undefined ? { seq } : {});
  }

  private async checkpoint(
    rel: Release,
    to: ReleaseState,
    phase: "begin" | "complete",
    facts: Record<string, unknown> = {},
  ): Promise<Release> {
    return await this.call<Release>("releaseStep", {
      operator: this.cfg.operator,
      releaseId: rel._id,
      phase,
      to,
      ...facts,
    });
  }

  // ------------------------------------------------------------------- git

  async git(args: string[], opts: { cwd?: string; env?: Record<string, string>; allowFail?: boolean } = {}) {
    if (args[0] === "push") assertNoForce(args);
    const r = await this.deps.exec("git", [...GIT_BASE, ...args], {
      cwd: opts.cwd ?? this.repo,
      env: { GIT_TERMINAL_PROMPT: "0", ...(opts.env ?? {}) },
    });
    if (r.code !== 0 && !opts.allowFail) {
      throw new ReleaseError(`git ${args[0]} failed: ${scrub(lastLines(r.stderr || r.stdout, 10))}`);
    }
    return r;
  }

  private async gitOut(args: string[], opts: { cwd?: string; env?: Record<string, string> } = {}) {
    return (await this.git(args, opts)).stdout.trim();
  }

  /** Branch tips on Code Storage, read fresh. */
  async remoteRefs(names: string[]): Promise<Record<string, string | null>> {
    const r = await this.git(["ls-remote", this.cfg.remoteUrl, ...names.map((n) => `refs/heads/${n}`)], {
      cwd: this.cfg.cwd,
    });
    const out: Record<string, string | null> = Object.fromEntries(names.map((n) => [n, null]));
    for (const line of r.stdout.split("\n")) {
      const [oid, ref] = line.trim().split(/\s+/);
      if (oid && ref?.startsWith("refs/heads/")) {
        const name = ref.slice("refs/heads/".length);
        if (name in out) out[name] = oid;
      }
    }
    return out;
  }

  /** The work clone, with every Code Storage branch under refs/remotes/cs/. */
  async fetch(): Promise<void> {
    if (!existsSync(join(this.repo, ".git"))) {
      mkdirSync(this.repo, { recursive: true });
      await this.git(["init", "-q"], { cwd: this.repo });
    }
    await this.git(["fetch", "-q", "--no-tags", "--prune", this.cfg.remoteUrl, "+refs/heads/*:refs/remotes/cs/*"]);
  }

  private async hasCommit(sha: string): Promise<boolean> {
    return (await this.git(["cat-file", "-e", `${sha}^{commit}`], { allowFail: true })).code === 0;
  }

  private async isAncestor(a: string, b: string): Promise<boolean> {
    return (await this.git(["merge-base", "--is-ancestor", a, b], { allowFail: true })).code === 0;
  }

  /** Push a commit to a branch. Never forced: Code Storage refuses a non-fast-forward. */
  private async push(sha: string, branch: string): Promise<void> {
    if (!GIT_SHA.test(sha)) throw new ReleaseError(`Not a commit id: ${sha}`);
    await this.git(["push", "--no-verify", "--porcelain", this.cfg.remoteUrl, `${sha}:refs/heads/${branch}`]);
    const after = (await this.remoteRefs([branch]))[branch];
    if (after !== sha) throw new ReleaseError(`${branch} is ${short(after ?? undefined)} after the push, not ${short(sha)}`);
  }

  private botEnv(at: number): Record<string, string> {
    const date = `@${Math.floor(at / 1000)} +0000`;
    return {
      GIT_AUTHOR_NAME: BOT_NAME,
      GIT_AUTHOR_EMAIL: BOT_EMAIL,
      GIT_COMMITTER_NAME: BOT_NAME,
      GIT_COMMITTER_EMAIL: BOT_EMAIL,
      GIT_AUTHOR_DATE: date,
      GIT_COMMITTER_DATE: date,
    };
  }

  /** The release diff: what merging `sha` into `baseSha` changes on main. */
  async releaseDiff(baseSha: string, sha: string): Promise<string> {
    const mt = await this.git(["merge-tree", "--write-tree", "--no-messages", baseSha, sha], { allowFail: true });
    if (mt.code !== 0) throw refuse(`chef ${short(sha)} doesn't merge cleanly into main ${short(baseSha)}`);
    const tree = mt.stdout.trim().split("\n")[0];
    return (await this.git([...DIFF_ARGS, baseSha, tree])).stdout;
  }

  private async diffOf(baseSha: string, commit: string): Promise<string> {
    return (await this.git([...DIFF_ARGS, baseSha, commit])).stdout;
  }

  // --------------------------------------------------------------- prepare

  /** Pin `chef` and `main`, then upload the diff. Returns the release. */
  async prepare(): Promise<Release> {
    const refs = await this.remoteRefs(["chef", "main"]);
    if (!refs.chef || !refs.main) throw refuse("Code Storage needs both chef and main branches");
    await this.fetch();
    const runs = (await this.call<RunRef[]>("releaseBuiltRuns", { limit: 100 })) ?? [];
    const covered: string[] = [];
    for (const run of runs) {
      if (!run.commitSha || !(await this.hasCommit(run.commitSha))) continue;
      if ((await this.isAncestor(run.commitSha, refs.chef)) && !(await this.isAncestor(run.commitSha, refs.main))) {
        covered.push(run.runId);
      }
    }
    const res = await this.call<{ seq: number; resumed: boolean }>("releasePrepare", {
      operator: this.cfg.operator,
      sha: refs.chef,
      baseSha: refs.main,
      runIds: covered,
      cliVersion: this.cfg.cliVersion,
    });
    this.deps.log(
      `${res.resumed ? "Resuming" : "Pinned"} release #${res.seq}: chef ${short(refs.chef)} onto main ${short(refs.main)}, ${covered.length} request run(s).`,
    );
    let rel = (await this.status(res.seq))!;
    if (rel.state === "pinned") rel = await this.uploadDiff(rel);
    return rel;
  }

  private async uploadDiff(rel: Release): Promise<Release> {
    if (!(await this.hasCommit(rel.sha)) || !(await this.hasCommit(rel.baseSha))) await this.fetch();
    const text = await this.releaseDiff(rel.baseSha, rel.sha);
    if (!text) throw refuse("Nothing to release: merging chef changes nothing on main");
    const { diffHash, chunks } = await releaseDiffHash(text);
    for (let i = 0; i < chunks.length; i++) {
      await this.call("releaseDiffChunk", {
        operator: this.cfg.operator,
        releaseId: rel._id,
        diffHash,
        index: i,
        count: chunks.length,
        text: chunks[i],
      });
    }
    this.deps.log(`Diff ${short(diffHash)} uploaded (${chunks.length} chunk(s)). Approve it in the panel.`);
    return (await this.status(rel.seq))!;
  }

  // ------------------------------------------------------------------ ship

  /**
   * Drive a release to `done` from wherever it is: the open release, or a new
   * one pinned now when none is open, or release `seq`.
   */
  async ship(seq?: number): Promise<Release> {
    let rel = seq !== undefined ? await this.status(seq) : await this.status();
    if (!rel) {
      if (seq !== undefined) throw new ReleaseError(`No release #${seq}`);
      rel = await this.prepare();
    }
    return await this.drive(rel);
  }

  /** Continue an existing release from its last checkpoint. */
  async resume(seq?: number): Promise<Release> {
    const rel = await this.status(seq);
    if (!rel) throw new ReleaseError(seq !== undefined ? `No release #${seq}` : "No open release");
    return await this.drive(rel);
  }

  async drive(start: Release): Promise<Release> {
    let rel = start;
    if (rel.kind === "cloud" && rel.state !== "done") {
      // Its frontend is in the host's storage, not on this machine.
      throw refuse(`Release #${rel.seq} is a cloud ship from the panel; the host drives it. Roll it back or wait for it.`);
    }
    if (rel.inFlight) this.deps.log(`Release #${rel.seq}: ${rel.inFlight.to} was started and not recorded; repeating it.`);
    for (;;) {
      if (rel.state === "abandoned" || rel.state === "rolledBack") {
        throw refuse(`Release #${rel.seq} is ${rel.state}`);
      }
      if (rel.state === "done") {
        this.deps.log(`Release #${rel.seq} is done: main is ${short(rel.mainSha)}.`);
        return rel;
      }
      this.deps.log(`Release #${rel.seq}: ${rel.state}`);
      switch (rel.state) {
        case "pinned":
          rel = rel.kind === "rollback" ? await this.deployBackend(rel) : await this.uploadDiff(rel);
          break;
        case "diffReady":
          rel = await this.waitForApproval(rel);
          break;
        case "approved":
          rel = await this.merge(rel);
          break;
        case "merged":
          rel = await this.pushSource(rel);
          break;
        case "sourcePushed":
          rel = await this.runGates(rel);
          break;
        case "gatesPassed":
          rel = await this.deployBackend(rel);
          break;
        case "backendDeployed":
          rel = await this.publishFrontends(rel);
          break;
        case "frontendPublished":
          rel = await this.verify(rel);
          break;
        case "verified":
          rel = await this.goLive(rel);
          break;
        case "live":
          rel = await this.checkpoint(rel, "done", "complete");
          break;
      }
    }
  }

  /** Wait (bounded) for an admin to approve the diff in the panel. The CLI can't approve. */
  private async waitForApproval(rel: Release): Promise<Release> {
    const deadline = this.deps.now() + this.cfg.approvalTimeoutMs;
    this.deps.log(`Waiting for the diff ${short(rel.diffHash)} to be approved in the panel.`);
    for (;;) {
      const cur = (await this.status(rel.seq))!;
      if (cur.state !== "diffReady") return cur;
      if (this.deps.now() >= deadline) {
        throw new ReleaseError(
          `Release #${rel.seq} is still waiting for approval in the panel. Run chef-release resume ${rel.seq} after approving.`,
          4,
        );
      }
      await this.deps.sleep(this.cfg.pollMs);
    }
  }

  /** approved -> merged: `chef` must still be the pinned sha, and the merge's diff the approved one. */
  private async merge(rel: Release): Promise<Release> {
    const refs = await this.remoteRefs(["chef", "main"]);
    if (refs.chef !== rel.sha) {
      throw refuse(
        `chef moved from the pinned ${short(rel.sha)} to ${short(refs.chef ?? undefined)}. Abandon release #${rel.seq} and prepare again.`,
      );
    }
    if (refs.main !== rel.baseSha) {
      throw refuse(`main moved from ${short(rel.baseSha)} to ${short(refs.main ?? undefined)}. Abandon release #${rel.seq} and prepare again.`);
    }
    await this.checkpoint(rel, "merged", "begin");
    await this.fetch();
    const mergeSha = await this.makeMerge(rel);
    const { diffHash } = await releaseDiffHash(await this.diffOf(rel.baseSha, mergeSha));
    if (diffHash !== rel.approvedDiffHash) {
      throw refuse(`The merge's diff ${short(diffHash)} isn't the approved ${short(rel.approvedDiffHash)}`);
    }
    return await this.checkpoint(rel, "merged", "complete", { mergeSha, diffHash });
  }

  /** `--no-ff` merge of sha into baseSha with a fixed identity and date, so it can be made again. */
  private async makeMerge(rel: Release): Promise<string> {
    await this.git(["checkout", "-q", "--detach", rel.baseSha]);
    await this.git(
      ["merge", "-q", "--no-ff", "--no-edit", "-m", `Release #${rel.seq}: chef ${short(rel.sha)}`, rel.sha],
      { env: this.botEnv(rel.createdAt) },
    );
    return await this.gitOut(["rev-parse", "HEAD"]);
  }

  /** The release's merge commit, from this clone, the release branch, or made again. */
  private async ensureMerge(rel: Release): Promise<string> {
    const sha = rel.mergeSha!;
    if (await this.hasCommit(sha)) return sha;
    await this.fetch();
    if (await this.hasCommit(sha)) return sha;
    if (rel.kind === "chef" && (await this.makeMerge(rel)) === sha) return sha;
    throw refuse(`Can't find the release's merge commit ${short(sha)} here or on Code Storage`);
  }

  /** merged -> sourcePushed: release/<n> on Code Storage before anything deploys. */
  private async pushSource(rel: Release): Promise<Release> {
    const branch = releaseBranch(rel.seq);
    await this.checkpoint(rel, "sourcePushed", "begin");
    const sha = await this.ensureMerge(rel);
    const existing = (await this.remoteRefs([branch]))[branch];
    if (existing && existing !== sha) throw refuse(`${branch} already exists at ${short(existing)}, not ${short(sha)}`);
    if (!existing) await this.push(sha, branch);
    return await this.checkpoint(rel, "sourcePushed", "complete", { releaseBranch: branch });
  }

  private buildPath(rel: Release) {
    return join(this.cfg.stateDir, "build", String(rel.seq));
  }

  /** A clean checkout of the release's merge, with the app's .env.local and dependencies. */
  private async checkout(rel: Release): Promise<string> {
    const sha = await this.ensureMerge(rel);
    const dir = this.buildPath(rel);
    if (existsSync(dir)) {
      const head = await this.git(["rev-parse", "HEAD"], { cwd: dir, allowFail: true });
      const clean = await this.git(["status", "--porcelain", "--untracked-files=no"], { cwd: dir, allowFail: true });
      if (head.stdout.trim() === sha && clean.code === 0 && clean.stdout.trim() === "") return dir;
      rmSync(dir, { recursive: true, force: true });
      await this.git(["worktree", "prune"]);
    }
    mkdirSync(join(this.cfg.stateDir, "build"), { recursive: true });
    await this.git(["worktree", "add", "-q", "--detach", dir, sha]);
    // The project's deployment settings, copied as a file and never read here.
    const env = join(this.cfg.cwd, ".env.local");
    if (existsSync(env)) copyFileSync(env, join(dir, ".env.local"));
    if (this.cfg.install) await this.runCmd(this.cfg.install, dir, "install");
    return dir;
  }

  private async runCmd(argv: string[], cwd: string, label: string): Promise<void> {
    const [cmd, ...args] = argv;
    this.deps.log(`  ${label}: ${argv.join(" ")}`);
    const r = await this.deps.exec(cmd, args, { cwd });
    if (r.code !== 0) {
      throw new ReleaseError(`${label} failed (exit ${r.code}):\n${scrub(lastLines(r.stdout + r.stderr, 40))}`);
    }
  }

  private artifactPath(digest: string) {
    return join(this.cfg.stateDir, "artifacts", `${digest}.tar`);
  }

  /** sourcePushed -> gatesPassed: the gates on a clean checkout, then the build output as one tar. */
  private async runGates(rel: Release): Promise<Release> {
    await this.checkpoint(rel, "gatesPassed", "begin");
    const dir = await this.checkout(rel);
    const names: string[] = [];
    for (const gate of this.cfg.gates) {
      await this.runCmd(gate, dir, "gate");
      names.push(gate.join(" "));
    }
    const out = join(dir, this.cfg.buildDir);
    if (!existsSync(out)) throw new ReleaseError(`The build produced no ${this.cfg.buildDir}/`);
    mkdirSync(join(this.cfg.stateDir, "artifacts"), { recursive: true });
    const tmp = join(this.cfg.stateDir, "artifacts", `release-${rel.seq}.tar.partial`);
    await this.runCmd(["tar", "-cf", tmp, "-C", out, "."], dir, "artifact");
    const digest = sha256File(tmp);
    renameSync(tmp, this.artifactPath(digest));
    this.deps.log(`  artifact ${short(digest)}`);
    return await this.checkpoint(rel, "gatesPassed", "complete", { artifactDigest: digest, gates: names });
  }

  /** gatesPassed (a rollback: pinned) -> backendDeployed: `convex deploy` of the merge. */
  private async deployBackend(rel: Release): Promise<Release> {
    await this.checkpoint(rel, "backendDeployed", "begin");
    const dir = await this.checkout(rel);
    const [cmd, ...pre] = this.cfg.convex;
    const args = this.cfg.prod ? [...pre, "deploy", "-y"] : [...pre, "dev", "--once"];
    await this.runCmd([cmd, ...args], dir, "backend");
    return await this.checkpoint(rel, "backendDeployed", "complete", { mergeSha: rel.mergeSha });
  }

  /** The release's artifact, checked against its digest. */
  private artifact(rel: Release): string {
    const digest = rel.artifactDigest!;
    const path = this.artifactPath(digest);
    if (!existsSync(path)) {
      throw refuse(`Artifact ${short(digest)} isn't on this machine (${path}); it can only be published from where it was built`);
    }
    if (sha256File(path) !== digest) throw refuse(`Artifact ${path} doesn't match its digest ${short(digest)}`);
    return path;
  }

  /** backendDeployed -> frontendPublished: the same artifact to each target, each recorded on its own. */
  private async publishFrontends(rel: Release): Promise<Release> {
    await this.checkpoint(rel, "frontendPublished", "begin");
    const digest = rel.artifactDigest!;
    let cur = rel;
    for (const target of FRONTEND_TARGETS) {
      if (cur.targets[target]?.digest === digest) continue;
      const tar = this.artifact(rel);
      const dir = join(this.cfg.stateDir, "publish", `${rel.seq}-${target}`);
      rmSync(dir, { recursive: true, force: true });
      mkdirSync(dir, { recursive: true });
      await this.runCmd(["tar", "-xf", tar, "-C", dir], this.cfg.cwd, "unpack");
      const argv = this.cfg.frontend[target].map((a) => a.replaceAll("{dir}", dir).replaceAll("{digest}", digest));
      if (argv.length === 0) throw new ReleaseError(`No publish command configured for ${target}`);
      await this.runCmd(argv, this.cfg.cwd, target);
      cur = await this.call<Release>("releaseTarget", {
        operator: this.cfg.operator,
        releaseId: rel._id,
        target,
        digest,
      });
    }
    return await this.checkpoint(cur, "frontendPublished", "complete");
  }

  /** frontendPublished -> verified: the site loads, the health check passes, required env vars exist. */
  private async verify(rel: Release): Promise<Release> {
    await this.checkpoint(rel, "verified", "begin");
    const checks: { name: string; ok: boolean }[] = [];
    const v = this.cfg.verify;
    if (v.url) {
      let ok = false;
      try {
        ok = (await this.deps.fetch(v.url)).ok;
      } catch {
        ok = false;
      }
      checks.push({ name: "site", ok });
    }
    const [cmd, ...pre] = this.cfg.convex;
    const prod = this.cfg.prod ? ["--prod"] : [];
    if (v.healthCheck) {
      const r = await this.deps.exec(cmd, [...pre, "run", ...prod, v.healthCheck, "{}"], { cwd: this.cfg.cwd });
      checks.push({ name: "healthCheck", ok: r.code === 0 });
    }
    if (v.requiredEnv?.length) {
      // Only the names are read from this output; it is never printed.
      const r = await this.deps.exec(cmd, [...pre, "env", "list", ...prod], { cwd: this.cfg.cwd });
      const names = new Set(
        r.code === 0 ? r.stdout.split("\n").map((l) => l.split("=")[0].trim()).filter(Boolean) : [],
      );
      for (const name of v.requiredEnv) checks.push({ name: `env:${name}`, ok: names.has(name) });
    }
    if (checks.length === 0) throw new ReleaseError("No verification configured (verify.url, verify.healthCheck or verify.requiredEnv)");
    const failed = checks.filter((c) => !c.ok).map((c) => c.name);
    if (failed.length) {
      throw new ReleaseError(
        `Verification failed: ${failed.join(", ")}. main hasn't moved. Fix it and run chef-release resume ${rel.seq}, or chef-release rollback ${rel.seq}.`,
      );
    }
    return await this.checkpoint(rel, "verified", "complete", { checks });
  }

  /** verified -> live: Code Storage main moves forward to what is now deployed. */
  private async goLive(rel: Release): Promise<Release> {
    await this.checkpoint(rel, "live", "begin");
    const main = (await this.remoteRefs(["main"])).main;
    if (!main) throw refuse("Code Storage has no main");
    const target = await this.ensureMerge(rel);
    let mainSha: string;
    if (rel.kind === "chef") {
      if (main === target) {
        mainSha = main;
      } else if (main === rel.baseSha) {
        await this.push(target, "main");
        mainSha = target;
      } else {
        throw refuse(`main moved to ${short(main)} during the release; it was ${short(rel.baseSha)}`);
      }
    } else {
      // A rollback can't move main back without a force push, so main moves
      // forward to a commit whose tree is the restored release's.
      await this.fetch();
      const tree = await this.gitOut(["rev-parse", `${target}^{tree}`]);
      if ((await this.gitOut(["rev-parse", `${main}^{tree}`])) === tree) {
        mainSha = main;
      } else {
        const msg = `Roll back to release #${rel.restores}\n\nRelease #${rel.rollbackOf} rolled back by release #${rel.seq}.`;
        mainSha = await this.gitOut(["commit-tree", tree, "-p", main, "-m", msg], { env: this.botEnv(rel.createdAt) });
        await this.push(mainSha, "main");
      }
    }
    return await this.checkpoint(rel, "live", "complete", { mainSha });
  }

  // -------------------------------------------------------------- rollback

  /** Roll release `seq` back to the release before it, through the same machine. */
  async rollback(seq: number, reason: string): Promise<Release> {
    const main = (await this.remoteRefs(["main"])).main;
    if (!main) throw refuse("Code Storage has no main");
    const rel = await this.call<Release>("releaseRollback", {
      operator: this.cfg.operator,
      seq,
      mainSha: main,
      reason,
    });
    this.deps.log(`Release #${rel.seq} rolls #${seq} back to release #${rel.restores} (${short(rel.mergeSha)}).`);
    return await this.drive(rel);
  }

  async abandon(seq: number, reason: string): Promise<Release> {
    const rel = await this.status(seq);
    if (!rel) throw new ReleaseError(`No release #${seq}`);
    return await this.call<Release>("releaseAbandon", { operator: this.cfg.operator, releaseId: rel._id, reason });
  }

  // ------------------------------------------------------------------ drop

  /**
   * Take a built request off `chef` before release: one new commit that
   * reverts its commits, pushed as a fast-forward.
   */
  async drop(itemNumber: number, reason?: string): Promise<{ revertSha: string | null; reverted: string[] }> {
    const info = await this.call<{ title: string; runs: RunRef[] } | null>("releaseItemRuns", { itemNumber });
    if (!info) throw new ReleaseError(`No request #${itemNumber}`);
    const refs = await this.remoteRefs(["chef", "main"]);
    if (!refs.chef || !refs.main) throw refuse("Code Storage needs both chef and main branches");
    await this.fetch();
    const runs = [...info.runs].sort((a, b) => (b.finishedAt ?? 0) - (a.finishedAt ?? 0));
    const toRevert: string[] = [];
    for (const run of runs) {
      const c = run.commitSha;
      if (!c || !(await this.hasCommit(c))) continue;
      if (await this.isAncestor(c, refs.main)) {
        throw refuse(`Request #${itemNumber}'s commit ${short(c)} is already on main; roll the release back instead`);
      }
      if (!(await this.isAncestor(c, refs.chef))) continue;
      const already = await this.gitOut(["log", "--format=%H", `--grep=^Chef-Drops: ${c}$`, refs.chef]);
      if (already) continue;
      toRevert.push(c);
    }
    let revertSha: string | null = null;
    if (toRevert.length) {
      await this.git(["checkout", "-q", "--detach", refs.chef]);
      for (const c of toRevert) {
        const parents = (await this.gitOut(["rev-list", "--parents", "-n", "1", c])).split(" ").length - 1;
        const r = await this.git(
          ["revert", "--no-edit", "--no-commit", ...(parents > 1 ? ["-m", "1"] : []), c],
          { allowFail: true },
        );
        if (r.code !== 0) {
          await this.git(["revert", "--abort"], { allowFail: true });
          throw refuse(`Reverting ${short(c)} conflicts with later work on chef; drop it by hand`);
        }
      }
      const staged = await this.git(["diff", "--cached", "--quiet"], { allowFail: true });
      if (staged.code !== 0) {
        const msg = [
          `Drop request #${itemNumber} from chef`,
          "",
          ...(reason ? [reason, ""] : []),
          ...toRevert.map((c) => `Chef-Drops: ${c}`),
        ].join("\n");
        await this.git(["commit", "-q", "--no-verify", "-m", msg], { env: this.botEnv(this.deps.now()) });
        revertSha = await this.gitOut(["rev-parse", "HEAD"]);
        await this.push(revertSha, "chef");
      }
    }
    await this.call("releaseDrop", {
      operator: this.cfg.operator,
      itemNumber,
      revertSha,
      reverted: toRevert,
      ...(reason ? { reason } : {}),
    });
    this.deps.log(
      revertSha
        ? `Request #${itemNumber} dropped from chef: ${short(revertSha)} reverts ${toRevert.map(short).join(", ")}.`
        : `Request #${itemNumber} has nothing on chef to revert.`,
    );
    const open = await this.status();
    if (revertSha && open && open.kind === "chef" && open.sha === refs.chef) {
      this.deps.log(`Release #${open.seq} was pinned at the old chef; abandon it and prepare again.`);
    }
    return { revertSha, reverted: toRevert };
  }
}

// ------------------------------------------------------------------ helpers

function assertNoForce(args: string[]): void {
  for (const a of args) {
    if (a === "-f" || a === "--force" || a.startsWith("--force-") || a === "--mirror" || a === "--delete" || a === "-d") {
      throw new ReleaseError(`Refusing a forced or destructive push (${a})`);
    }
    if (/^\+/.test(a) || /^:/.test(a)) throw new ReleaseError(`Refusing a forced or deleting refspec (${a})`);
  }
}

export function sha256File(path: string): string {
  return createHash("sha256").update(readFileSync(path)).digest("hex");
}

function lastLines(s: string, n: number): string {
  return s.trimEnd().split("\n").slice(-n).join("\n");
}
