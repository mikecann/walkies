// The bundled runner's entry point (scripts/build-runner.mjs bundles this,
// runner/*.ts and the src/chef modules they use into one file). The same as
// runner/chef-runner.mjs, without the resolve hook a bundle doesn't need.
import { main } from "../main.ts";

process.exitCode = await main(process.argv.slice(2), process.env);
