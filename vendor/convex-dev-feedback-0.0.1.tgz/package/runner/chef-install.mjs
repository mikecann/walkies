#!/usr/bin/env node
// How Chef installs an app's dependencies, decided by its lockfile. One
// place for every install of an app's checkout: the build sandbox
// (runner/runner.ts, as the agent user), the deploy and "Ship it" sandboxes
// (chef-preview-deploy.sh and chef-ship-deploy.sh run this file, delivered
// next to them), and `npx chef init`'s preflight (cli/preflight.ts), which
// passes only what these can install.
//
//   package-lock.json, npm-shrinkwrap.json   npm ci --ignore-scripts
//   pnpm-lock.yaml                           pnpm install --frozen-lockfile --ignore-scripts
//                                            --ignore-pnpmfile, pnpm from the npm registry
//   yarn.lock, bun.lock, none                refused, with what to do instead
//
// The plan itself, and the warm install's inputs, are pure functions in
// chef-install-plan.mjs (delivered next to this file), which the host runs
// too on the files of a commit. This file runs them on a checkout.
//
// A warm snapshot (docs/chef-pipeline.md, "Warm snapshots") has npm's cache,
// and pnpm's store for pnpm, filled by this same install at
// /opt/chef/warm/<inputsHash>/. When its marker is for exactly this
// checkout's inputs, the install is the same command, `--offline`, against
// a copy of them; npm and pnpm still check every package against the
// lockfile's integrity. Anything else (no snapshot, other inputs, a failed
// offline install) is the normal install.
//
// yarn.lock resolves to registry.yarnpkg.com, which the sandboxes can't
// reach; bun isn't in the image.
//
// Usage, in the checkout: node chef-install.mjs   prints the plan and runs it
//   CHEF_WARM_ROOT   where warm dirs are (default /opt/chef/warm; "" for none)
//
// Node built-ins and chef-install-plan.mjs only.

import { spawnSync } from "node:child_process";
import { cpSync, existsSync, lstatSync, mkdtempSync, readFileSync, realpathSync, rmSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { basename, join, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import {
  MAX_LOCKFILE_BYTES,
  MAX_PACKAGE_JSON_BYTES,
  MAX_WARM_TARBALL_BYTES,
  WARM_MARKER,
  WARM_ROOT,
  checkWarmMarker,
  describePlan,
  installPlanFrom,
  packageManagerOf,
  sha256Hex,
  warmCaches,
  warmDirFor,
  warmInputs,
  warmInstallArgv,
} from "./chef-install-plan.mjs";

export {
  NPM_INSTALL,
  PNPM_FOR_LOCKFILE,
  describePlan,
  lockfileCheckArgv,
  lockfileFix,
  pnpmInstallArgv,
  pnpmLockfileMajor,
} from "./chef-install-plan.mjs";

function readText(path, max = MAX_LOCKFILE_BYTES) {
  try {
    const b = readFileSync(path);
    return b.length > max ? null : b.toString("utf8");
  } catch {
    return null;
  }
}

/** A checkout's root files, as installPlanFrom and warmInputs read them. */
export function checkoutFiles(dir) {
  return {
    exists: (name) => existsSync(join(dir, name)),
    read: (name, max) => readText(join(dir, name), max),
  };
}

/** package.json's packageManager as {name, version}; version null when it isn't exact. Null if unset. */
export function packageManagerField(dir) {
  return packageManagerOf(readText(join(dir, "package.json"), MAX_PACKAGE_JSON_BYTES));
}

/**
 * How `dir` installs: `{ manager, lockfile, argv }`, plus `version` for pnpm;
 * or `{ error, lockfile, help }` when Chef can't install it.
 */
export function installPlan(dir) {
  return installPlanFrom(checkoutFiles(dir));
}

/**
 * Offline and dependency-free: the root importer's specifiers in a
 * pnpm-lock.yaml (lockfile 6 and 9) against package.json's, the check
 * pnpm's frozen install makes first. Lines like `added is-odd@^3.0.0`,
 * `removed x`, `is-number: lockfile ^7.0.0, package.json ^6.0.0`; [] when
 * they agree, null when the lockfile can't be read this way (then only
 * pnpm itself can tell).
 */
export function pnpmSpecifierMismatches(dir) {
  const text = readText(join(dir, "pnpm-lock.yaml"));
  let pkg;
  try {
    pkg = JSON.parse(readText(join(dir, "package.json"), 1024 * 1024) ?? "null");
  } catch {
    return null;
  }
  if (text === null || !pkg || typeof pkg !== "object") return null;
  const lines = text.split("\n");
  const start = lines.findIndex((l) => /^importers:\s*$/.test(l));
  const locked = new Map();
  if (start >= 0) {
    let i = start + 1;
    while (i < lines.length && !/^ {2}['"]?\.['"]?:/.test(lines[i])) {
      if (/^\S/.test(lines[i])) return null;
      i++;
    }
    if (i >= lines.length) return null;
    if (/^ {2}['"]?\.['"]?:\s*\{\s*\}\s*$/.test(lines[i])) i = lines.length; // `.: {}`
    let field = null;
    let name = null;
    for (i++; i < lines.length; i++) {
      const l = lines[i];
      if (l.trim() === "") continue;
      if (/^ {0,3}\S/.test(l)) break; // the next importer, or the next top-level key
      let m;
      if ((m = /^ {4}(\w+):\s*$/.exec(l))) {
        field = ["dependencies", "devDependencies", "optionalDependencies"].includes(m[1]) ? m[1] : null;
        name = null;
      } else if (field && (m = /^ {6}(['"]?)(.+?)\1:\s*$/.exec(l))) {
        name = m[2];
      } else if (field && name && (m = /^ {8}specifier:\s*(.*?)\s*$/.exec(l))) {
        locked.set(name, unquote(m[1]));
      }
    }
  } else if (/^lockfileVersion:/m.test(text) && !/^(dependencies|devDependencies|optionalDependencies|specifiers):/m.test(text)) {
    // No importers and no root deps at all: an empty project.
  } else return null;
  const wanted = new Map();
  for (const f of ["dependencies", "devDependencies", "optionalDependencies"]) {
    for (const [n, s] of Object.entries(pkg[f] ?? {})) if (typeof s === "string") wanted.set(n, s);
  }
  const out = [];
  for (const [n, s] of wanted) {
    if (!locked.has(n)) out.push(`added ${n}@${s}`);
    else if (locked.get(n) !== s) out.push(`${n}: lockfile ${locked.get(n)}, package.json ${s}`);
  }
  for (const n of locked.keys()) if (!wanted.has(n)) out.push(`removed ${n}`);
  return out;
}

function unquote(s) {
  const m = /^(['"])(.*)\1$/.exec(s);
  return m ? (m[1] === "'" ? m[2].replace(/''/g, "'") : m[2]) : s;
}

/** A `file:` tarball's sha256 in the checkout: a regular file (no symlink) inside it, at most 16 MB; else null. */
function tarballSha256In(dir) {
  const top = resolve(dir);
  return async (path) => {
    const f = resolve(top, path);
    if (!f.startsWith(top + sep)) return null;
    try {
      const st = lstatSync(f);
      if (!st.isFile() || st.size > MAX_WARM_TARBALL_BYTES) return null;
      return await sha256Hex(readFileSync(f));
    } catch {
      return null;
    }
  };
}

/**
 * Whether the checkout in `dir` can install warm from `root`: the warm dir
 * for exactly its inputs (lockfile, package.json's install fields, `file:`
 * tarballs, the install command) exists, and its marker says so.
 * `{ ok: true, plan, inputsHash, dir, marker }` or `{ ok: false, reason }`.
 * The marker is only trusted to point at the caches: npm and pnpm check
 * every package in them against the lockfile's integrity.
 */
export async function warmLookup(dir, root = WARM_ROOT) {
  if (!root || !existsSync(root)) return { ok: false, reason: "not a warm snapshot" };
  const w = await warmInputs(checkoutFiles(dir), tarballSha256In(dir));
  if (w.unsupported) return { ok: false, reason: w.unsupported };
  const wdir = warmDirFor(root, w.inputsHash);
  const c = checkWarmMarker(readText(join(wdir, WARM_MARKER), MAX_PACKAGE_JSON_BYTES), w);
  if (!c.ok) return { ok: false, reason: c.reason, inputsHash: w.inputsHash };
  // Built root-owned and read-only for everyone else; refuse one anybody can change.
  for (const p of [root, wdir]) {
    if (statSync(p).mode & 0o002) return { ok: false, reason: `${p} is writable by everyone` };
  }
  return { ok: true, plan: w.plan, inputsHash: w.inputsHash, dir: wdir, marker: c.marker };
}

/**
 * Copies of a warm dir's caches in a fresh dir under `parent` (the install
 * writes to them; the snapshot's stay as built), and the offline install
 * argv against them: `{ argv, dir }`.
 */
export function prepareWarm(lookup, parent = tmpdir()) {
  const into = mkdtempSync(join(parent, "chef-warm-"));
  const from = warmCaches(lookup.dir);
  const to = warmCaches(into);
  cpSync(from.npmCache, to.npmCache, { recursive: true });
  if (lookup.plan.manager === "pnpm") cpSync(from.pnpmStore, to.pnpmStore, { recursive: true });
  return { argv: warmInstallArgv(lookup.plan, to, { offline: true }), dir: into };
}

const seconds = (ms) => `${Math.round(ms / 100) / 10} s`;

function spawnInstall(argv) {
  const r = spawnSync(argv[0], argv.slice(1), { stdio: "inherit" });
  if (r.error) {
    process.stderr.write(`chef-install: ${argv[0]} didn't run: ${r.error.message}\n`);
    return 1;
  }
  return r.status ?? 1;
}

async function main() {
  const cwd = process.cwd();
  const plan = installPlan(cwd);
  if ("error" in plan) {
    process.stderr.write(`chef-install: ${plan.error}\n`);
    for (const l of plan.help) process.stderr.write(`chef-install:   ${l}\n`);
    return 1;
  }
  // A warm snapshot's caches (docs/chef-pipeline.md, "Warm snapshots"), when
  // they are for exactly this checkout; anything else installs normally.
  // CHEF_WARM_ROOT is the launcher's (tests'), never the checkout's; "" turns it off.
  const root = process.env.CHEF_WARM_ROOT ?? WARM_ROOT;
  let warm;
  try {
    warm = await warmLookup(cwd, root);
  } catch (e) {
    warm = { ok: false, reason: `the warm check failed: ${e?.message ?? e}` };
  }
  if (warm.ok) {
    const t0 = Date.now();
    let code = 1;
    let prepared = null;
    try {
      prepared = prepareWarm(warm);
      process.stdout.write(
        `chef-install: ${describePlan(plan)}, warm from ${warm.marker.name} (key ${warm.marker.key.slice(0, 12)}): ${prepared.argv.join(" ")}\n`,
      );
      code = spawnInstall(prepared.argv);
    } catch (e) {
      process.stderr.write(`chef-install: the warm caches couldn't be copied: ${e?.message ?? e}\n`);
    }
    if (code === 0) {
      // npm's copy is done with; pnpm's store stays, node_modules links into it.
      if (prepared && plan.manager === "npm") rmSync(prepared.dir, { recursive: true, force: true });
      process.stdout.write(`chef-install: install (warm) took ${seconds(Date.now() - t0)}\n`);
      return 0;
    }
    process.stdout.write(`chef-install: the warm install failed (exit ${code}); installing normally\n`);
    if (prepared) rmSync(prepared.dir, { recursive: true, force: true });
    rmSync(join(cwd, "node_modules"), { recursive: true, force: true });
  } else if (root && existsSync(root)) {
    process.stdout.write(`chef-install: no warm install: ${warm.reason}\n`);
  }
  const t0 = Date.now();
  process.stdout.write(`chef-install: ${describePlan(plan)}: ${plan.argv.join(" ")}\n`);
  const code = spawnInstall(plan.argv);
  if (code === 0) process.stdout.write(`chef-install: install took ${seconds(Date.now() - t0)}\n`);
  return code;
}

// Run as a script, not imported (the runner's bundle includes this module,
// and there argv[1] is the bundle).
const self = fileURLToPath(import.meta.url);
const invoked =
  !!process.argv[1] && basename(self) === "chef-install.mjs" && existsSync(process.argv[1]) && realpathSync(process.argv[1]) === realpathSync(self);
if (invoked) {
  main().then(
    (code) => (process.exitCode = code),
    (e) => {
      process.stderr.write(`chef-install: ${e?.message ?? e}\n`);
      process.exitCode = 1;
    },
  );
}
