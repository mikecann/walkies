// The runner's command line. `chef-runner.mjs` loads this after installing
// a resolve hook for the shared `src/chef/*.ts` modules.
//
//   node /opt/chef/runner/chef-runner.mjs [--config /opt/chef/runner.json]
//
// The config file is root-owned in the snapshot image. The orchestrator
// starts the runner with CHEF_API and CHEF_RUN_ID; the secrets arrive as
// Daytona placeholders in CHEF_RUN_TOKEN, CHEF_GIT_AUTH and CHEF_AI_TOKEN.
// Daytona runs commands as `daytona`, so the launcher starts this through
// `sudo -n --preserve-env=<src/chef/runnerEnv.ts>` to get root and keep
// those and NODE_EXTRA_CA_CERTS.
//
// Exit codes: 0 pushed, 1 failed, 3 refused (already started), 2 bad usage.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { processGroupAgentUser, systemAgentUser, type AgentUser } from "./agent-user.ts";
import { commandEgressCheck, defaultEgressCheck } from "./egress.ts";
import { runChef, type RunnerConfig } from "./runner.ts";
import { RUNNER_SECRET_ENV, RUNNER_TRUST_ENV } from "../src/chef/runnerEnv.ts";

export const DEFAULT_CONFIG_PATH = "/opt/chef/runner.json";

/**
 * What the runner takes from its environment for the commands it runs as
 * the agent user (runner/agent-env.ts): the three placeholders, and the
 * egress proxy's CA bundle path. Without the bundle path, npm in the install
 * step can't verify the registry behind the proxy
 * (UNABLE_TO_VERIFY_LEAF_SIGNATURE on every fetch), retries for 70 seconds
 * and crashes with "Exit handler never called!" (wishbox build #8).
 */
export function runnerEnvFrom(env: Record<string, string | undefined>): Record<string, string | undefined> {
  const out: Record<string, string | undefined> = {};
  for (const k of [...RUNNER_SECRET_ENV, ...RUNNER_TRUST_ENV]) {
    if (env[k] !== undefined) out[k] = env[k];
  }
  return out;
}

type FileConfig = Omit<RunnerConfig, "env" | "runId" | "api"> & {
  /** "chefagent" (default) or, for local tests only, "current-user". */
  agentUser?: string;
  /** For local tests and L2: a command whose exit 0 means egress is closed. */
  egressCheckCommand?: string[];
};

export async function main(argv: string[], env: Record<string, string | undefined>): Promise<number> {
  let configPath = DEFAULT_CONFIG_PATH;
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === "--config" && argv[i + 1]) configPath = argv[++i];
    else {
      process.stderr.write("usage: chef-runner [--config <path>]\n");
      return 2;
    }
  }
  const file = JSON.parse(readFileSync(configPath, "utf8")) as FileConfig;
  const runId = env.CHEF_RUN_ID;
  const api = env.CHEF_API;
  if (!runId || !api) {
    process.stderr.write("chef-runner: CHEF_RUN_ID and CHEF_API are required\n");
    return 2;
  }
  const { agentUser: userName, egressCheckCommand, ...rest } = file;
  const agentUser: AgentUser =
    userName === "current-user" ? processGroupAgentUser() : systemAgentUser(userName ?? "chefagent");
  const egressCheck = egressCheckCommand
    ? commandEgressCheck(async () => {
        const r = spawnSync(egressCheckCommand[0], egressCheckCommand.slice(1), {
          encoding: "utf8",
          env: { PATH: rest.runnerPath ?? "/usr/local/bin:/usr/bin:/bin" },
          timeout: 60_000,
        });
        return { code: r.status, output: `${r.stdout ?? ""}${r.stderr ?? ""}` };
      })
    : defaultEgressCheck(env);
  const cfg: RunnerConfig = {
    ...rest,
    runId,
    api,
    ...(env.CHEF_REPO_URL ? { repoUrl: env.CHEF_REPO_URL } : {}),
    // Only these are read from the environment.
    env: runnerEnvFrom(env),
  };
  const result = await runChef(cfg, { agentUser, egressCheck });
  if (result.ok) return 0;
  return result.stage === "start" ? 3 : 1;
}
