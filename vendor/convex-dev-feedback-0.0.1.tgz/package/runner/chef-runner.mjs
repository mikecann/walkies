#!/usr/bin/env node
// Entry point for the Chef runner (runner/main.ts). Node 22 runs the
// TypeScript directly with type stripping. The shared modules in src/chef
// import each other as `./x.js` (for the bundler and vitest), which Node
// can't find, so a resolve hook maps a missing relative `.js` to its `.ts`.
import { register } from "node:module";

const hook = `
export async function resolve(specifier, context, next) {
  try {
    return await next(specifier, context);
  } catch (e) {
    if (e && e.code === "ERR_MODULE_NOT_FOUND" && /^\\.\\.?\\//.test(specifier) && specifier.endsWith(".js")) {
      return await next(specifier.slice(0, -3) + ".ts", context);
    }
    throw e;
  }
}
`;
register("data:text/javascript," + encodeURIComponent(hook), import.meta.url);

const { main } = await import("./main.ts");
process.exitCode = await main(process.argv.slice(2), process.env);
