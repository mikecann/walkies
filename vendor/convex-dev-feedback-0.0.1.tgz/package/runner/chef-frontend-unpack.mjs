#!/usr/bin/env node
// Unpacks the frontend the runner built (runner/frontend-artifact.ts) inside
// the deploy sandbox, and points it at the preview. Runs from
// runner/chef-preview-deploy.sh, after the deploy. See "The preview" in
// docs/chef-pipeline.md.
//
// Usage: chef-frontend-unpack.mjs --in-prefix <path> --parts <n> --sha256 <hex>
//          --out <dir> --url https://<deployment>.convex.cloud
//
// The launcher wrote the archive into the sandbox as base64 text in <n> parts,
// <path>0.b64 to <path><n-1>.b64 (the Daytona file API carries text). This:
//
//   1. joins and decodes the parts, refuses anything over the size cap, and
//      checks the sha256 the runner reported and Chef recorded;
//   2. gunzips with an output cap and reads the ustar archive, accepting only
//      regular files and directories with plain relative paths;
//   3. writes them into <out>, a new directory, never through a link;
//   4. replaces the Convex URL placeholder with <url> in every file, as a
//      plain byte string replace; at least one file must have held it.
//
// Node built-ins only. Nothing from the archive is ever executed, and this
// never sees the deploy key.

import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, realpathSync, writeFileSync } from "node:fs";
import { dirname, isAbsolute, join } from "node:path";
import { fileURLToPath } from "node:url";
import { gunzipSync } from "node:zlib";

// The same values as src/chef/frontend.ts (tests check they agree).
export const CONVEX_URL_PLACEHOLDER = "https://__CHEF_CONVEX_URL__.invalid";
export const MAX_ARTIFACT_BYTES = 8 * 1024 * 1024;
export const MAX_ARTIFACT_FILES = 5000;
export const MAX_ARTIFACT_UNPACKED_BYTES = 200 * 1024 * 1024;

const SHA256 = /^[0-9a-f]{64}$/;
const CONVEX_URL = /^https:\/\/[a-z0-9][a-z0-9-]{0,62}\.convex\.cloud$/;
const BASE64 = /^[A-Za-z0-9+/]*={0,2}$/;
// No control characters, no slashes or backslashes.
// eslint-disable-next-line no-control-regex
const NAME_PART = /^[^\x00-\x1f\x7f/\\]+$/;

export class Refusal extends Error {}

function say(msg) {
  process.stdout.write(`chef-frontend-unpack: ${msg}\n`);
}

export function parseArgs(argv) {
  const out = { inPrefix: null, parts: null, sha256: null, out: null, url: null };
  const flags = { "--in-prefix": "inPrefix", "--parts": "parts", "--sha256": "sha256", "--out": "out", "--url": "url" };
  for (let i = 0; i < argv.length; i++) {
    const key = flags[argv[i]];
    if (!key) throw new Refusal(`unknown argument ${JSON.stringify(argv[i])}`);
    const v = argv[i + 1];
    if (v === undefined || v.startsWith("--")) throw new Refusal(`${argv[i]} needs a value`);
    out[key] = v;
    i++;
  }
  if (!out.inPrefix || !isAbsolute(out.inPrefix)) throw new Refusal("--in-prefix must be an absolute path");
  const parts = Number(out.parts);
  if (!Number.isInteger(parts) || parts < 1 || parts > 64) throw new Refusal("--parts must be 1 to 64");
  out.parts = parts;
  if (!SHA256.test(out.sha256 ?? "")) throw new Refusal("--sha256 must be 64 hex characters");
  if (!out.out || !isAbsolute(out.out)) throw new Refusal("--out must be an absolute path");
  if (!CONVEX_URL.test(out.url ?? "")) throw new Refusal("--url must be https://<deployment>.convex.cloud");
  return out;
}

/** The archive's bytes from its base64 parts, checked against the sha256. */
export function readArchive(inPrefix, parts, sha256) {
  let text = "";
  for (let i = 0; i < parts; i++) {
    const p = `${inPrefix}${i}.b64`;
    if (!existsSync(p)) throw new Refusal(`missing part ${i}`);
    text += readFileSync(p, "utf8").replace(/\s+/g, "");
    if (text.length > (MAX_ARTIFACT_BYTES * 4) / 3 + 8) throw new Refusal(`the archive is over ${MAX_ARTIFACT_BYTES} bytes`);
  }
  if (!BASE64.test(text)) throw new Refusal("the archive parts are not base64");
  const bytes = Buffer.from(text, "base64");
  if (bytes.length === 0 || bytes.length > MAX_ARTIFACT_BYTES) throw new Refusal("bad archive size");
  const got = createHash("sha256").update(bytes).digest("hex");
  if (got !== sha256) throw new Refusal("the archive's sha256 doesn't match");
  return bytes;
}

function field(buf, off, len) {
  const end = buf.indexOf(0, off);
  return buf.toString("utf8", off, end >= off && end < off + len ? end : off + len);
}

function octalField(buf, off, len) {
  const s = buf.toString("ascii", off, off + len).replace(/[\0 ]+$/, "").replace(/^ +/, "");
  if (!/^[0-7]+$/.test(s)) throw new Refusal("bad number in the archive");
  return parseInt(s, 8);
}

function checkPath(path) {
  if (path === "" || path.startsWith("/") || path.length > 1024) throw new Refusal(`bad path in the archive: ${JSON.stringify(path)}`);
  for (const part of path.split("/")) {
    if (!NAME_PART.test(part) || part === "." || part === "..") {
      throw new Refusal(`bad path in the archive: ${JSON.stringify(path)}`);
    }
  }
}

/** Regular files from a ustar archive: [{ path, bytes }]. Anything else is refused. */
export function parseTar(tar) {
  const files = [];
  const seen = new Set();
  let total = 0;
  let off = 0;
  for (;;) {
    if (off + 512 > tar.length) throw new Refusal("the archive is truncated");
    const h = tar.subarray(off, off + 512);
    if (h.every((b) => b === 0)) break;
    let sum = 0;
    for (let i = 0; i < 512; i++) sum += i >= 148 && i < 156 ? 32 : h[i];
    if (octalField(h, 148, 8) !== sum) throw new Refusal("bad checksum in the archive");
    const type = String.fromCharCode(h[156]);
    const name = field(h, 0, 100);
    const prefix = h.toString("ascii", 257, 262) === "ustar" ? field(h, 345, 155) : "";
    let path = prefix ? `${prefix}/${name}` : name;
    const size = octalField(h, 124, 12);
    off += 512;
    if (type === "5") {
      path = path.replace(/\/$/, "");
      checkPath(path);
      if (size !== 0) throw new Refusal("a directory with contents in the archive");
      continue;
    }
    if (type !== "0" && type !== "\0") throw new Refusal(`only regular files are allowed; ${JSON.stringify(path)} is type ${JSON.stringify(type)}`);
    checkPath(path);
    if (seen.has(path)) throw new Refusal(`${path} is in the archive twice`);
    seen.add(path);
    if (off + size > tar.length) throw new Refusal("the archive is truncated");
    total += size;
    if (total > MAX_ARTIFACT_UNPACKED_BYTES) throw new Refusal(`the archive unpacks to over ${MAX_ARTIFACT_UNPACKED_BYTES} bytes`);
    if (files.length >= MAX_ARTIFACT_FILES) throw new Refusal(`the archive has over ${MAX_ARTIFACT_FILES} files`);
    files.push({ path, bytes: tar.subarray(off, off + size) });
    off += Math.ceil(size / 512) * 512;
  }
  return files;
}

/** Every occurrence of `from` in `buf` replaced by `to`, and how many there were. */
export function replaceAll(buf, from, to) {
  const parts = [];
  let count = 0;
  let at = 0;
  for (let i = buf.indexOf(from, at); i >= 0; i = buf.indexOf(from, at)) {
    parts.push(buf.subarray(at, i), to);
    at = i + from.length;
    count++;
  }
  if (count === 0) return { bytes: buf, count };
  parts.push(buf.subarray(at));
  return { bytes: Buffer.concat(parts), count };
}

export function unpack(opts) {
  if (existsSync(opts.out)) throw new Refusal("the output directory already exists");
  const gz = readArchive(opts.inPrefix, opts.parts, opts.sha256);
  let tar;
  try {
    tar = gunzipSync(gz, { maxOutputLength: MAX_ARTIFACT_UNPACKED_BYTES + 1024 * 1024 });
  } catch {
    throw new Refusal("the archive doesn't gunzip within its size cap");
  }
  const files = parseTar(Buffer.from(tar.buffer, tar.byteOffset, tar.length));
  if (files.length === 0) throw new Refusal("the archive is empty");
  if (!files.some((f) => f.path === "index.html")) throw new Refusal("the archive has no index.html");
  const from = Buffer.from(CONVEX_URL_PLACEHOLDER);
  const to = Buffer.from(opts.url);
  mkdirSync(opts.out, { mode: 0o755 });
  const root = realpathSync(opts.out);
  let replaced = 0;
  let filesReplaced = 0;
  for (const f of files) {
    const target = join(root, f.path);
    // Only directories this run made: nothing in the archive can be a link.
    mkdirSync(dirname(target), { recursive: true, mode: 0o755 });
    if (realpathSync(dirname(target)) !== dirname(target)) throw new Refusal(`${f.path} escapes the output directory`);
    const r = replaceAll(f.bytes, from, to);
    replaced += r.count;
    if (r.count) filesReplaced++;
    writeFileSync(target, r.bytes, { flag: "wx", mode: 0o644 });
  }
  if (replaced === 0) throw new Refusal("no file holds the Convex URL placeholder; the build didn't use it");
  say(`${files.length} files, the placeholder replaced ${replaced} times in ${filesReplaced} files`);
  return { files: files.length, replaced, filesReplaced };
}

const invoked = process.argv[1] && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url));
if (invoked) {
  try {
    unpack(parseArgs(process.argv.slice(2)));
  } catch (e) {
    process.stderr.write(`chef-frontend-unpack: ${e instanceof Error ? e.message : String(e)}\n`);
    process.exitCode = e instanceof Refusal ? 2 : 1;
  }
}
