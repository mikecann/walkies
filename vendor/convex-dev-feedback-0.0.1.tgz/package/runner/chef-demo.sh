#!/usr/bin/env bash
# The demo sandbox's script (docs/chef-pipeline.md, "The demo video"): runs
# the bundled recorder, chef-demo.mjs, delivered next to it, with the
# image's Playwright and browsers, against the preview only.
# Usage: chef-demo.sh <40 character sha> (the build's commit, for the record)
set -euo pipefail
self="${BASH_SOURCE[0]}"
while [ -L "$self" ]; do
  link="$(readlink "$self")"
  case "$link" in /*) self="$link" ;; *) self="$(dirname "$self")/$link" ;; esac
done
d="$(cd "$(dirname "$self")" && pwd -P)"
ca=/etc/daytona/netleash/ca.crt
if [ -r "$ca" ]; then
  if [ -x /opt/chef/bin/trust-daytona-proxy-ca ]; then /opt/chef/bin/trust-daytona-proxy-ca >/dev/null 2>&1 || true; fi
  export NODE_EXTRA_CA_CERTS="$ca"
fi
export PLAYWRIGHT_BROWSERS_PATH="${PLAYWRIGHT_BROWSERS_PATH:-/opt/chef/ms-playwright}"
export PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1
exec node "$d/chef-demo.mjs"
