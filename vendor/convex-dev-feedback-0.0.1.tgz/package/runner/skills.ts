// Skills for the agent, and the Claude Code config dir it runs with.
//
// The build image ships skills root-owned at /opt/chef/skills/<name>/SKILL.md.
// Before the agent starts, the runner copies them into a plugin directory of
// its own and passes it with `claude --plugin-dir`. Claude Code loads a
// `--plugin-dir` plugin in place ("the directory loads in place and is never
// copied", https://code.claude.com/docs/en/plugins/loading), so what the
// agent can do to it is what the file modes allow: root owns every file and
// directory, files are 0444 and directories 0555, and no ancestor is
// writable by anyone but root. The agent can't edit, replace or add a skill.
//
// Two frontmatter fields are dropped at copy time, because each one changes
// what the agent may run (https://code.claude.com/docs/en/skills, frontmatter
// reference):
// - `allowed-tools` "grants permission for the listed tools during the turn
//   that invokes the skill". Deny rules still win over it, but our settings
//   deny little and rely on `claude -p` refusing anything not allowed, so a
//   grant would widen what the agent can run.
// - `hooks`: "Hooks that Claude Code registers when the skill is invoked and
//   keeps running for the rest of the session."
// Inline `!` commands in skill bodies are turned off by the settings file
// (`disableSkillShellExecution`, runner/claude-settings.ts).
//
// The agent's other skill sources are closed too. `--setting-sources user`
// leaves out project skills (the repo's .claude/skills, which the agent can
// write), and the user source is CLAUDE_CONFIG_DIR, which this module makes
// a dir the agent can create files in (Claude Code keeps its session state
// there) but whose skills/, commands/, agents/, rules/, settings.json and
// CLAUDE.md are root-owned and empty. Claude Code watches the user skills
// dir and reloads settings files mid-session
// (https://code.claude.com/docs/en/skills, "Live change detection";
// https://code.claude.com/docs/en/settings), so an agent-owned config dir
// would let the agent add skills, hooks or allow rules while it runs.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import {
  chmodSync,
  existsSync,
  lstatSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { dirname, join } from "node:path";

export const DEFAULT_SKILLS_DIR = "/opt/chef/skills";
export const DEFAULT_PLUGIN_DIR = "/opt/chef-agent/plugin";
export const DEFAULT_CLAUDE_CONFIG_DIR = "/opt/chef-agent/claude";

/** The plugin's name; its skills are invoked as `chef:<skill>`. */
export const PLUGIN_NAME = "chef";

/** Frontmatter keys dropped at copy time (see the file comment). */
export const STRIPPED_FRONTMATTER = ["allowed-tools", "hooks"];

const SKILL_NAME = /^[a-z0-9][a-z0-9_-]{0,63}$/;
const FILE_NAME = /^[A-Za-z0-9._-]{1,128}$/;
const MAX_FILE_BYTES = 1024 * 1024;
const MAX_TOTAL_BYTES = 16 * 1024 * 1024;
const MAX_FILES = 2000;
const MAX_DEPTH = 6;

const FILE_MODE = 0o444;
const DIR_MODE = 0o555;

/** In the config dir: root-owned and empty, so nothing loads from them. */
export const PINNED_CONFIG_DIRS = ["skills", "commands", "agents", "rules"];
/** In the config dir: root-owned, read-only. */
export const PINNED_CONFIG_FILES: Record<string, string> = {
  "settings.json": "{}\n",
  "CLAUDE.md": "",
};

/**
 * Throws unless `path` and every directory above it are owned by root or by
 * the runner and writable by nobody else. A directory with the sticky bit
 * (like /tmp) may be world-writable: others can't rename or remove what root
 * owns in it.
 */
export function assertRunnerOwnedPath(path: string): void {
  const runner = process.getuid?.() ?? 0;
  let p = path;
  let first = true;
  for (;;) {
    if (existsSync(p) || !first) {
      const s = lstatSync(p);
      if (s.isSymbolicLink()) throw new Error(`${p} is a symlink`);
      if (s.uid !== 0 && s.uid !== runner) throw new Error(`${p} is not owned by root or the runner`);
      const sticky = (s.mode & 0o1000) !== 0;
      if ((s.mode & 0o022) !== 0 && !(sticky && !first)) {
        throw new Error(`${p} is writable by others`);
      }
    }
    first = false;
    const up = dirname(p);
    if (up === p) return;
    p = up;
  }
}

/**
 * Drops the frontmatter keys in STRIPPED_FRONTMATTER (with their nested
 * lines) from a SKILL.md. Returns the text and the keys it dropped. A file
 * without frontmatter is returned as is.
 */
export function stripSkillFrontmatter(text: string): { text: string; stripped: string[] } {
  const m = /^---\r?\n([\s\S]*?)\r?\n---(\r?\n|$)/.exec(text);
  if (!m) return { text, stripped: [] };
  const lines = m[1].split(/\r?\n/);
  const out: string[] = [];
  const stripped: string[] = [];
  let dropping = false;
  for (const line of lines) {
    const key = /^([A-Za-z0-9_-]+)\s*:/.exec(line);
    if (key) {
      const k = key[1].toLowerCase().replace(/_/g, "-");
      dropping = STRIPPED_FRONTMATTER.includes(k);
      if (dropping) stripped.push(k);
    } else if (line.trim() !== "" && !/^[\s-]/.test(line)) {
      // Not a key and not a nested line: keep it, and stop dropping.
      dropping = false;
    }
    if (!dropping) out.push(line);
  }
  if (stripped.length === 0) return { text, stripped };
  const head = `---\n${out.join("\n")}\n---${m[2] ? "\n" : ""}`;
  return { text: head + text.slice(m[0].length), stripped };
}

export type SkillsPluginResult = {
  /** Skills copied, by directory name. Empty when there were none. */
  skills: string[];
  /** The runner's own agents written into the plugin (`chef:<name>`). */
  agents: string[];
  /** Entries skipped, with why. */
  skipped: string[];
  /** Skills whose frontmatter lost a key, and which. */
  stripped: { skill: string; keys: string[] }[];
};

/**
 * Copies `skillsDir/<name>/` (regular files only, bounded) into
 * `pluginDir/skills/<name>/`, writes the runner's own `agents` (name to
 * markdown, the runner's text, never the image's or the repo's) into
 * `pluginDir/agents/`, with `pluginDir/.claude-plugin/plugin.json`, then
 * makes the whole tree read-only. `skillsDir` null means no image skills.
 * Returns null when there is no skills dir and there are no agents; creates
 * nothing when there is no valid skill and no agent.
 */
export function buildSkillsPlugin(
  skillsDir: string | null,
  pluginDir: string,
  opts: { agents?: Record<string, string> } = {},
): SkillsPluginResult | null {
  removeLockedTree(pluginDir);
  const agents = Object.entries(opts.agents ?? {});
  for (const [name] of agents) if (!SKILL_NAME.test(name)) throw new Error(`bad agent name ${JSON.stringify(name.slice(0, 64))}`);
  const haveSkillsDir = skillsDir !== null && existsSync(skillsDir) && statSync(skillsDir).isDirectory();
  if (!haveSkillsDir && agents.length === 0) return null;
  const result: SkillsPluginResult = { skills: [], agents: [], skipped: [], stripped: [] };
  let files = 0;
  let bytes = 0;
  const planned: { name: string; files: { rel: string; content: Buffer }[] }[] = [];

  const collect = (dir: string, rel: string, depth: number, into: { rel: string; content: Buffer }[]): string | null => {
    if (depth > MAX_DEPTH) return "too deep";
    for (const entry of readdirSync(dir).sort()) {
      if (!FILE_NAME.test(entry)) return `bad file name ${JSON.stringify(entry.slice(0, 40))}`;
      const path = join(dir, entry);
      const s = lstatSync(path);
      const r = rel ? `${rel}/${entry}` : entry;
      if (s.isDirectory()) {
        const why = collect(path, r, depth + 1, into);
        if (why) return why;
      } else if (s.isFile()) {
        if (s.size > MAX_FILE_BYTES) return `${r} is too large`;
        if (++files > MAX_FILES) return "too many files";
        bytes += s.size;
        if (bytes > MAX_TOTAL_BYTES) return "skills are too large in total";
        into.push({ rel: r, content: readFileSync(path) });
      } else {
        // Symlinks, sockets, devices: never followed or copied.
        return `${r} is not a regular file`;
      }
    }
    return null;
  };

  const root = haveSkillsDir ? skillsDir! : "";
  for (const name of haveSkillsDir ? readdirSync(root).sort() : []) {
    const dir = join(root, name);
    const s = lstatSync(dir);
    if (!s.isDirectory()) {
      result.skipped.push(`${name.slice(0, 64)}: not a directory`);
      continue;
    }
    if (!SKILL_NAME.test(name)) {
      result.skipped.push(`${name.slice(0, 64)}: bad skill name`);
      continue;
    }
    const skillMd = join(dir, "SKILL.md");
    if (!existsSync(skillMd) || !lstatSync(skillMd).isFile()) {
      result.skipped.push(`${name}: no SKILL.md`);
      continue;
    }
    const into: { rel: string; content: Buffer }[] = [];
    const before = { files, bytes };
    const why = collect(dir, "", 0, into);
    if (why) {
      files = before.files;
      bytes = before.bytes;
      result.skipped.push(`${name}: ${why}`);
      continue;
    }
    for (const f of into) {
      if (f.rel !== "SKILL.md") continue;
      const s2 = stripSkillFrontmatter(f.content.toString("utf8"));
      if (s2.stripped.length > 0) {
        f.content = Buffer.from(s2.text, "utf8");
        result.stripped.push({ skill: name, keys: s2.stripped });
      }
    }
    planned.push({ name, files: into });
  }
  if (planned.length === 0 && agents.length === 0) return result;

  mkdirSync(dirname(pluginDir), { recursive: true, mode: 0o755 });
  assertRunnerOwnedPath(dirname(pluginDir));
  mkdirSync(join(pluginDir, ".claude-plugin"), { recursive: true, mode: 0o755 });
  writeFileSync(
    join(pluginDir, ".claude-plugin", "plugin.json"),
    JSON.stringify({ name: PLUGIN_NAME, description: "Skills shipped with the Chef build image" }, null, 2) + "\n",
  );
  for (const skill of planned) {
    for (const f of skill.files) {
      const path = join(pluginDir, "skills", skill.name, f.rel);
      mkdirSync(dirname(path), { recursive: true, mode: 0o755 });
      writeFileSync(path, f.content);
    }
    result.skills.push(skill.name);
  }
  for (const [name, text] of agents) {
    mkdirSync(join(pluginDir, "agents"), { recursive: true, mode: 0o755 });
    writeFileSync(join(pluginDir, "agents", `${name}.md`), text);
    result.agents.push(name);
  }
  lockTree(pluginDir);
  assertRunnerOwnedPath(pluginDir);
  return result;
}

/** Files 0444, directories 0555, children before parents. */
export function lockTree(path: string): void {
  const s = lstatSync(path);
  if (s.isDirectory()) {
    for (const entry of readdirSync(path)) lockTree(join(path, entry));
    chmodSync(path, DIR_MODE);
  } else {
    chmodSync(path, FILE_MODE);
  }
}

/** Removes a tree `lockTree` made read-only. */
export function removeLockedTree(path: string): void {
  if (!existsSync(path)) return;
  const unlock = (p: string) => {
    const s = lstatSync(p);
    if (s.isSymbolicLink()) return;
    if (s.isDirectory()) {
      chmodSync(p, 0o755);
      for (const entry of readdirSync(p)) unlock(join(p, entry));
    }
  };
  unlock(path);
  rmSync(path, { recursive: true, force: true });
}

/**
 * A fresh CLAUDE_CONFIG_DIR for the agent: the runner owns it, and `share`
 * (AgentUser.shareDir) lets the agent user create entries in it without
 * being able to rename or remove root's. The discovery paths in it are
 * root-owned, read-only and empty.
 */
export async function prepareClaudeConfigDir(dir: string, share: (path: string) => Promise<void>): Promise<void> {
  removeLockedTree(dir);
  mkdirSync(dirname(dir), { recursive: true, mode: 0o755 });
  assertRunnerOwnedPath(dirname(dir));
  mkdirSync(dir, { mode: 0o755 });
  for (const d of PINNED_CONFIG_DIRS) {
    mkdirSync(join(dir, d), { mode: DIR_MODE });
    chmodSync(join(dir, d), DIR_MODE);
  }
  for (const [name, content] of Object.entries(PINNED_CONFIG_FILES)) {
    writeFileSync(join(dir, name), content, { mode: FILE_MODE });
    chmodSync(join(dir, name), FILE_MODE);
  }
  await share(dir);
}
