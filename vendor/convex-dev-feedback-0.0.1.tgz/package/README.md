# @convex-dev/feedback

Embeddable feature-request & voting backend as a [Convex component](https://docs.convex.dev/components).

Drop a feature-request workflow into any Convex app with one line in your `convex.config.ts`.

## Try it in your app

Two packages from this repo. `@convex-dev/feedback` is the feedback board:
requests, voting, approvals and the panel, with no child components and no
dependencies. `@convex-dev/chef-cloud` adds cloud builds: approved requests
built by Claude Code in sandboxes, previewed, and shipped from the panel. It
brings Daytona, Code Storage, Resend and `@convex-dev/workflow` as its own
children, so an app with just the board installs none of them.

You need the app's `convex` 1.35 or later (1.45 for cloud builds), and
GitHub access to `sethconvex/feedback-chef` (it's private). The marketplace
components cloud builds use are bundled inside chef-cloud, so no other repo
access is needed. Paste one of these to your coding agent, in the app's
directory.

**The feedback board only:**

```text
Add Chef's feedback board to this app: users suggest features and vote, and
I approve them in a panel. No cloud builds.
Install @convex-dev/feedback from github:sethconvex/feedback-chef#chef-pipeline,
then follow node_modules/@convex-dev/feedback/skills/convex-chef/SKILL.md for
the board alone (npx chef init --no-cloud). Read the whole runbook first.

- Run `npx chef init --no-cloud`, show me the changes, then `--write`.
- Name me admin with my Chef user id (I'll copy it from the panel).
- Mount the Chef panel where signed-in users can reach it.
- Never print env values, keys or tokens.

When done, tell me what changed, anything in the runbook that was wrong or
unclear, and what's left for me.
```

**Cloud builds:** for a paid Convex team.

```text
Add Chef to this app so it can improve itself from feature requests, with
cloud builds. Install @convex-dev/feedback from
github:sethconvex/feedback-chef#chef-pipeline, then follow
node_modules/@convex-dev/feedback/skills/convex-chef/SKILL.md exactly, with
cloud builds (npx chef init --cloud). Read the whole runbook first.

- The build sandbox can only reach the npm registry: vendor GitHub-only
  dependencies as tarballs, as the runbook says. That's @convex-dev/feedback
  and @convex-dev/chef-cloud (from the dist/chef-cloud branch, which
  `npx chef init --cloud --write` vendors with npm), from the same commit.
- Set chefCloud's options in convex/chef.ts before `npx chef init --write`.
  If the app already sends email, pass notify.send using its existing mailer.
- Run `npx chef init --cloud`, show me the changes, then `--write`.
- Name me admin with my Chef user id (I'll copy it from the panel).
- Mount the Chef panel where signed-in users can reach it.
- Use the dev deployment. Ask me before creating a production deploy key
  (Ship it deploys wherever that key points) and before turning cloud
  builds on.
- Never print env values, keys or tokens.

When done, tell me what changed, anything in the runbook that was wrong or
unclear, and what's left for me.
```

- **What you'll see:** your users get a lightbulb to suggest features. You
  get the Chef panel: approve a request, and with cloud builds Chef builds
  it, you get an email with a preview, and **Ship it** puts it live.
- **Cost:** the board costs nothing beyond your app's own usage. Cloud
  builds bill model calls and sandbox time to your team, usually about $1 to
  $2 a build, capped per run, plus storage for up to 2 warm snapshots
  (dependencies pre-installed, a few GB each; `warmSnapshots: false` for
  none). Or run `npx chef work` (it needs chef-cloud,
  with cloud builds left off) to build on your own Claude or Codex
  subscription instead.
- **Problems:** tell Seth. The runbook gets better with each install.

### Install lines

| Package | From | In the app |
| --- | --- | --- |
| `@convex-dev/feedback` | `github:sethconvex/feedback-chef#chef-pipeline` (its `prepare` builds it) | `npm pack github:sethconvex/feedback-chef#chef-pipeline --pack-destination vendor`, then `"@convex-dev/feedback": "file:vendor/convex-dev-feedback-0.0.1.tgz"` |
| `@convex-dev/chef-cloud` | `github:sethconvex/feedback-chef#dist/chef-cloud` (built, by `scripts/publish-dist.sh`) | `npm pack github:sethconvex/feedback-chef#dist/chef-cloud --pack-destination vendor`, then `npm install ./vendor/convex-dev-chef-cloud-0.0.1.tgz` (`npx chef init --cloud --write` does both) |

Vendor both as tarballs, from the same commit: the build sandbox reaches
only the npm registry, and chef-cloud checks the feedback component's
contract version at setup and in `chefSetupStatus`, refusing a mismatch
with a message saying which one is older.

## Install in 3 steps

Adds a feedback button to your app. Your users see a neutral lightbulb **"Suggest a feature"**
button: they send a request (typed, or a screenshot + voice note with a live transcript) and
follow their own requests ("Waiting for approval" → "Planned" → "In progress" → "Done"). Admins
see **Chef** instead: the Chef brand, build status, Chef's questions, the approvals queue, their
cloud builds, and every request. The panel is how an owner approves requests and watches the
cloud builds they start: no separate admin app.

**1. Install the component.**

```sh
npm install github:sethconvex/feedback-chef#chef-pipeline   # pin a commit with #<sha> for reproducible builds
```

```ts
// convex/convex.config.ts
import { defineApp } from "convex/server";
import feedback from "@convex-dev/feedback/convex.config";

const app = defineApp();
app.use(feedback);
export default app;
```

**2. Expose the Chef API — one file.**

```ts
// convex/chef.ts
import { exposeChefApi } from "@convex-dev/feedback";
import { components } from "./_generated/api";
import { getAuthUserId } from "@convex-dev/auth/server"; // 2.0 alpha: "@convex-dev/auth/core"

export const {
  agentState, listPublicItems, submitRequest, upvoteRequest, answerRefinement, skipRefinement,
  generateUploadUrl, submitRequestWithMedia, listAttachments,
  mine, amAdmin, whoAmI, awaitingApproval, review, whatsNew,
  approvalSnapshot, prepareApproval, approveSnapshot, runLogs, skillFeedback,
  approvalRequests, approveApprovalRequest, declineApprovalRequest, runScreenshots,
  runStatus, recentRuns, buildState, buildInCloud, shipCandidate, shipDiffChunk, shipApprove,
  retryRun, appLearnings, forgetLearning, buildCosts, applyRepair, buildCard,
  previewDataMode, setPreviewData, splitFromBatch,
} = exposeChefApi(components.feedback, {
  getUserId: getAuthUserId, // who is calling (null = signed out)
});
```

Not on Convex Auth? Any identity works, e.g.
`getUserId: async (ctx) => (await ctx.auth.getUserIdentity())?.subject ?? null` (Clerk, Auth0, …).

For `npx chef` (naming the admin, upgrades), the same file exports two internal functions:

```ts
import { chefAdmin } from "@convex-dev/feedback";
export const { chefSetAdmin, chefMigrateAgentKeys } = chefAdmin(components.feedback);
```

With cloud builds, `chefCloud` (from `@convex-dev/chef-cloud`) exports these two instead,
with the rest of its functions.

**3. Add the panel.** In a React / Next.js app, inside your Convex provider (a client component):

```tsx
import { ChefPanelMount } from "@convex-dev/feedback/react";
import { useAuthToken } from "@convex-dev/auth/react";

<ChefPanelMount convexUrl={process.env.NEXT_PUBLIC_CONVEX_URL!} token={useAuthToken()} />
```

(Clerk: `getToken={() => getToken({ template: "convex" })}` instead of `token`. Rename the
members' button with `memberLabel="Feedback"`.) Any other page — the panel is a plain web component with no build step:

```html
<script type="module" src="https://cdn.jsdelivr.net/gh/sethconvex/feedback@main/panel/chef-panel.browser.js"></script>
<chef-panel convex-url="https://YOUR-DEPLOYMENT.convex.cloud" prefix="chef"></chef-panel>
<script type="module">
  // Hand it the signed-in user's Convex token so requests are attributed:
  document.querySelector("chef-panel").setAuth(async ({ forceRefreshToken }) => getMyConvexToken(forceRefreshToken));
</script>
```

`prefix` is the module you exported the API from (`convex/chef.ts` → `"chef"`, the default);
`member-label="Feedback"` renames the members' button. With a bundler you can also
`import "@convex-dev/feedback/panel"` to register `<chef-panel>`.

That's the whole admin surface. Signed in as an owner, open the panel to:

- **Approve requests.** Approve on a waiting request takes a snapshot of it and shows it in full:
  every character, hidden ones (zero-width, bidi controls) as `<U+XXXX>` markers, the voice note
  transcript, and every attachment. **Approve and build** approves exactly that snapshot, which is
  the only approval that can start a cloud build. Reject works as before.
- **Watch cloud builds.** Under **Cloud builds**, open one to see its phases as they happen,
  status, spend, model calls and heartbeat, the preview and a one-time **Open the preview, signed
  in** link, screenshots of the built app, the agent's notes on its skills, the paid steps it asked
  for (Approve or Decline), and the run log (collapsed until you open it).
- **Ship it to the live app.** Under **Ship to the live app**, **Ship it** shows exactly what
  shipping the newest build changes on `main` (the whole diff `main..chef`), and the requests it
  ships. **Ship to live** approves that diff by its hash; the app's shipper deploys that commit to
  the live deployment, publishes its frontend, checks the live site, and only then moves `main`.
  The requests are marked done and their requesters told. If it stops after the deploy, the panel
  shows why, `main` stays where it was, and **Try again** picks it up. Setting this up is in
  "Chef cloud builds" below.

**Who sees what** (decided by the server's `amAdmin`, live):

| | Members & signed-out visitors | Admins |
|---|---|---|
| Launcher | lightbulb + "Suggest a feature" (no Chef branding) | Chef bubble |
| Panel | "Request a feature" (typed, or screenshot + voice note) + "Your requests" | Chef: approvals, Chef's questions, build status, cloud builds, all requests |
| Approving | | Approve shows the full snapshot; "Approve and build" approves it |
| Cloud builds | | phases, status, spend, model calls, heartbeat, preview + one-time sign-in link, screenshots, skill notes, spend approvals, run log |
| Ship it | | the diff main..chef, the requests, "Ship to live", the last ship's state |
| States shown | Waiting for approval · Planned · In progress · Done · Declined | raw lifecycle |

Signed-out visitors still see the button; sending asks them to sign in. Members never load any
build data: the build queries return nothing to them, and the panel doesn't ask.

**iOS:** the same `convex/chef.ts` powers ChefKit, the Swift package — see `ios/` (coming in the
same PR series).

### Setting up: `npx chef init`

In the app's directory, with a clean git tree. (Agents: the whole setup, from install to
turning it off, is the runbook in [`skills/convex-chef/SKILL.md`](skills/convex-chef/SKILL.md).)

```sh
npx chef init --no-cloud           # the board alone: prints the code it would add; changes nothing
npx chef init --no-cloud --write   # adds and commits it (app.use(feedback), exposeChefApi and
                                   # chefAdmin in convex/chef.ts), pushes, names the admin (--admin)
npx chef init --cloud              # cloud builds too: checks the app, prints the code
npx chef init --cloud --write      # vendors @convex-dev/chef-cloud, adds and commits the code,
                                   # then sets everything up
```

Without `--cloud` or `--no-cloud`, an app with chef-cloud installed (or `chefCloud` in
`convex/chef.ts`) gets cloud builds, and otherwise init asks; with no terminal to ask on,
it sets up the board alone.

With cloud builds it checks first (a `convex/` directory, `convex` 1.45 or later, a cloud
dev or prod deployment, no dependencies installed from git, a lockfile the build sandboxes
can install from, the frontend's URL env var, the CLI login) and lists every problem at
once. The sandboxes install with `npm ci --ignore-scripts` from `package-lock.json`, or with
pnpm's frozen install (`--ignore-scripts --ignore-pnpmfile`) from `pnpm-lock.yaml`, using
the pnpm package.json's `packageManager` names, else pnpm 10 for a 9.x lockfile (8 for
6.x), fetched from the npm registry with `npm exec`. yarn, bun and no lockfile fail the
check: the sandboxes reach only registry.npmjs.org. Then it:

1. vendors `@convex-dev/chef-cloud` if it isn't installed (`npm pack` from the
   `dist/chef-cloud` branch into `vendor/`, then `npm install` of the tarball; `--cloud-from
   <spec>` for another source; with pnpm, yarn or bun it prints the commands for you), adds
   `app.use(feedback)` and `app.use(chefCloud)`, `convex/chef.ts` (every `exposeChefApi` and
   `chefCloud` function, as in "Chef cloud builds" below; no crons, see "No crons" below),
   `mountChefAgentRoutes(http, components.feedback)` in `convex/http.ts`
   and the deploy guard as package.json's `predev` (below), only inserting lines, and
   prints the panel mount for you to place. A `convex/chef.ts` from an earlier init gets
   the functions it's missing;
2. runs the deploy guard, pushes the functions, creates the app's repo and pushes HEAD as
   its `main` (a pack uploaded to the deployment; no git token reaches your machine);
3. adds a `chef` git remote whose credential helper (`npx chef git-credential`) asks the
   deployment for a short-lived token each time, and keeps other helpers from storing it;
4. creates a preview deploy key with your CLI login and sets throwaway preview defaults for
   the env vars `convex.config` requires (fresh signing keys, random strings), plus
   `scripts/chef-local-env.mjs` and the `chef:local-env` npm script that runs it, which
   `chefCloud`'s `localEnv: "auto"` runs on the build's local backend;
5. offers a deploy key for this deployment, for "Ship it": made with
   `npx convex deployment token create`, piped straight into `CHEF_DEPLOY_KEY` and recorded
   with `chefSetDeployKey` (`--deploy-key` to skip the question, `--skip-deploy-key` for
   none);
6. for an app with chefCloud's `beta`, offers the beta deployment's deploy key
   (`--beta <deployment>` to skip the question, `--skip-beta` for none), into
   `CHEF_BETA_DEPLOY_KEY`;
7. asks before turning cloud builds on, since builds are billed to your team (`--enable` to
   skip the question).

Run it again any time: each step skips what's already done. `npx chef sync` pushes your
HEAD to chef's `main`, after checking it has nothing the preview deploy refuses (tracked
`.env`/`.env.local`/`.npmrc`, symlinks, `convex.json` functions outside the repo, git
dependencies) and a lockfile the sandbox installs; `npx chef status` shows where things stand. Nothing it runs prints a
token, key or env value. `npx chef ios <runId|itemId>` builds a run's commit with Xcode on your
Mac, installs it on your iPhone and marks the run "compiled ✓ / installed ✓" (config:
`chef.ios` in package.json; docs/chef-pipeline.md, "Trying a build on your iPhone").

**The deploy guard.** "Ship it" deploys a build to the deployment `CHEF_DEPLOY_KEY` is for,
then moves chef's `main`. A later deploy of an older checkout to that deployment (a local
`npx convex dev`, `npx chef upgrade`) would put the old code back and roll back what
shipped. So the CLI refuses, before any deploy to that deployment and in `npx chef sync`,
while chef's `main` has commits the checkout lacks, and says to `git pull chef main` first.
`npx chef guard` is the check on its own (exit 3 when it refuses); init adds it as the
app's `predev` script when the app's scripts run `convex dev`, so `npm run dev` runs it
first (pnpm needs `enable-pre-post-scripts`). Local deployments are never guarded, a
deployment Ship it doesn't deploy to is let through, and when the CLI can't tell it
refuses; `CHEF_SKIP_DEPLOY_GUARD=1` deploys anyway.

### Admins

Nobody becomes an admin by signing in or by sending the first request: everyone who signs in
is a member until they're named. Name the app's owner once, with their Chef user id (what your
`getUserId` returns for them; the panel shows a signed-in member "Your Chef user id" with a
Copy button):

```sh
npx chef init --admin <userId>
# or, by hand:
npx convex run chef:chefSetAdmin '{"userId":"<userId>"}'
```

Cloud builds (`chefEnableCloudBuilds`) and "Ship it" are refused until an admin like this exists;
the CLI's own `operator:cli` identity doesn't count. Admins' requests go straight to the build
queue; everyone else's wait under **"Waiting for your approval"** in the admin's panel (with their
screenshots and voice note).

Apps that set roles themselves keep working: `feedback.users.setRole` (for example, syncing an
`OWNER_EMAIL` user to admin on sign-in) makes an admin like `chefSetAdmin` does. Installs from
before this change keep the admins they have; only new sign-ins stopped becoming admin. To make
someone else an admin from your own code:

```ts
// convex/setupChef.ts — run with: npx convex run setupChef:makeAdmin '{"userId":"<id>"}'
import { internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { Feedback } from "@convex-dev/feedback";
import { components } from "./_generated/api";

export const makeAdmin = internalMutation({
  args: { userId: v.string() },
  handler: async (ctx, { userId }) =>
    new Feedback(components.feedback).users.setRole(ctx, { userId, role: "admin" }),
});
```

### Get an email when a request needs approval

`onSubmitted` runs inside the submitting mutation, after the request and its media are saved:

```ts
import { internal } from "./_generated/api";
import { Feedback } from "@convex-dev/feedback";

const feedback = new Feedback(components.feedback);

export const { /* …the same names… */ } = exposeChefApi(components.feedback, {
  getUserId: getAuthUserId,
  onSubmitted: async (ctx, { itemId, title, description, state }) => {
    if (state !== "submitted") return; // an admin's own request: already queued
    const adminIds = await feedback.users.listAdmins(ctx);
    // Send from an action (e.g. with @convex-dev/resend), not inline:
    await ctx.scheduler.runAfter(0, internal.emails.chefRequestWaiting, { adminIds, itemId, title, description });
  },
});
```

Other options: `agentKey` (e.g. `() => process.env.FEEDBACK_AGENT_KEY`; only used on behalf of
verified admins), `getUserName` (shown as "from" in approvals), `includeCommunity` (show
not-yet-approved requests on the public list; default off), `autoRegister` (default on).

### What `exposeChefApi` enforces

- Identity comes only from `getUserId(ctx)` — never from arguments. Signed-out callers get
  `ConvexError({ code: "UNAUTHENTICATED" })` from writes, and empty results / `false` from queries.
- Requests need a title; at most 4 screenshots + 1 voice note, no duplicate uploads (type, size and
  freshness are checked by the component). Voice notes carry the client's transcript; no server
  transcription is involved.
- Only admins auto-approve, see approvals (`awaitingApproval`, `review`) and build status
  (`agentState`), and answer/skip Chef's questions (before anyone has registered, the build
  status is open so the scaffolding agent can work).
- `mine` returns the caller's own requests (≤50, newest first) with media counts.
- `runLogs` pages through a Chef run's log lines, oldest first (`cursor` is the previous page's
  `nextCursor`). The lines were scrubbed when the runner's batch was stored. Admins only; everyone
  else gets an empty page.
- `skillFeedback` pages (`paginationOpts`) through what build agents said about the image's skills:
  `{ skill, kind: "wrong" | "missing" | "outdated" | "deviation", message, suggestion }`. Pass
  `runId` for one run's, in the order written, or `skill` for one skill's, newest first. Admins only.
- `approvalRequests` pages through steps builds needed that cost money or reach outside the app,
  which the agent wrote down instead of taking: `{ id, action, skill, estimatedCostUsd, why,
  commandOrSteps, status: "pending" | "approved" | "declined", decidedBy, decidedAt, decisionNote }`.
  Pass `runId` or `status`. `approveApprovalRequest({ id, note? })` and
  `declineApprovalRequest({ id, note? })` record an admin's decision (audited); nothing carries out
  an approved step yet. Admins only.
- `runScreenshots({ runId })` lists the screenshots the runner took of the built app after the
  guards: `{ name, path, url, width, height, createdAt }`, where `url` is the PNG in the
  component's file storage. Admins only.
- `runStatus({ runId })` or `runStatus({ itemId })` (that request's newest run) is one cloud run as
  the panel shows it: `phases` (each `{ phase, label, state: "done" | "now" | "stopped" | "todo" }`),
  `status`, `statusText`, `spendUsd`, `aiRequests`, `aiInFlight`, `heartbeatAt`, `previewUrl`,
  `previewLoginUrl` (a one-time sign-in link to the preview: it works once), `branch`,
  `commitSha`, `filesChanged` and `error`. Admins only; null for everyone else.
- `recentRuns({ limit? })` lists the newest runs (10 by default, at most 50) with each request's
  title. Admins only; [] for everyone else.
- `buildState()` is `{ cloudEnabled, workerKeys, autoBuild, queued, busy }`, and
  `buildInCloud()` claims the oldest approved request for a cloud build now (`{ outcome, reason }`;
  `disabled` with cloud builds off). The panel shows "Build in cloud" only with `cloudEnabled`, a
  request queued and no build running. Admins only; null for everyone else.
- `whatsNew({ since })` is public (signed-out callers too): it returns only the admin-written
  changelog line and ship time of completed requests — see "What's new" below.

### What's new (changelogs)

When something ships, record one short, user-facing line for it. Users then get a small
**"What's new"** pop-up the next time they open the app, listing everything that shipped since
their last visit.

```ts
// convex/ship.ts — from your build agent / CLI:
//   npx convex run ship:complete '{"itemId":"<id>","changelog":"You can now export your book as a PDF."}'
import { internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { Feedback } from "@convex-dev/feedback";
import { components } from "./_generated/api";

const feedback = new Feedback(components.feedback);

export const complete = internalMutation({
  args: { itemId: v.string(), changelog: v.string() },
  handler: async (ctx, { itemId, changelog }) =>
    // Sets the changelog and moves the item to "completed" (supporters are notified as usual).
    feedback.items.complete(ctx, { itemId, changelog }),
});
```

- Write the changelog for users ("Dark mode is here."), not the request text — requests can be
  crude or private, and only the changelog is ever shown. ≤280 characters. Fix or add one later
  with `feedback.items.setChangelog(ctx, { itemId, text })` (empty text clears it).
- It is for users, so it never shows a commit hash, a run or snapshot id, or a note for the
  operator ("Built by Chef run …", "Shipped … in a594c962 (merged by hand)"): those are taken
  out (`src/chef/changelog.ts`). An item completed without a line (by hand, or shipped by a
  Chef release) gets one from its Chef build's summary: its own line under "## Each request",
  else the first "## What changed" bullet, as one plain sentence with no file paths. With
  neither, it doesn't appear.
- Read it yourself with `feedback.items.listShippedSince(ctx, { since, limit })` →
  `[{ _id, changelog, completedAt }]`, or call the public `whatsNew({ since })` →
  `[{ id, text, at }]` from any client.
- **Web** (`<chef-panel>` / `ChefPanelMount`): once per page load the panel compares against
  `localStorage["chef-whatsnew-seen:<prefix>"]`. A first visit only records the time (no backlog
  dump); afterwards, new changelogs appear in a card above the launcher (up to 6, with "and N
  more", relative dates, **Got it** / × / Escape). Members see it unbranded; admins see the Chef
  logo. Turn it off with `whats-new="off"` (`<ChefPanelMount whatsNew={false} />`).
- **iOS** (ChefKit): same rule, keyed by `UserDefaults` `"ChefKit.whatsNewSeen.<prefix>"`; the
  sheet floats above the app. Turn it off with `ChefKit.showsWhatsNew = false` (before `install`);
  `ChefKit.presentWhatsNew()` shows the last 30 days on demand (e.g. a "What's new" row in
  Settings).
- Older backends without `whatsNew` are detected and skipped silently by both clients.

## Packages

`@convex-dev/feedback` (this directory):

- **`src/component/`**: the Convex component itself (`defineComponent("feedback")`, no children), with items, bids, devLogs, notifications, agentKeys and Chef's runs, approvals, releases, keys and audit log.
- **`src/client/`** (`@convex-dev/feedback`, `/http`, `/delivery`): what the host imports, meaning `Feedback`, `exposeChefApi`, `chefAdmin`, the HTTP routes (`/agent/*`, `/chef-agent/*` and the model proxy) and the runner delivery chef-cloud writes into sandboxes.
- **`runner/`**: the build's runner (in a sandbox or `npx chef work`'s container) and the deploy scripts, bundled by `scripts/build-runner.mjs`.
- **`cli/`**: the `chef` CLI (`init`, `work`, `sync`, `guard`, `status`, `upgrade`, the git credential helper).
- **`src/chef/`** (`/chef/*`): pure modules shared by the component, the client, `runner/`, `release/` and chef-cloud.
- **`src/react/`** (`@convex-dev/feedback/react`) — prebuilt React widgets: `FeatureRequestButton`, `FeatureRequestList`, `FeatureRequestDetail`, `AdminPanel`, `NotificationBell`.

`@convex-dev/chef-cloud` (**`packages/chef-cloud/`**), cloud builds:

- **`src/component/`**: `defineComponent("chefCloud")`, using the workflow, a cleanup pool, and the vendored Daytona, Code Storage and Resend as its children. Its tables: `config` (the repo record and the executor) and `effects` (the ledger of each build's sandboxes, commands and emails).
- **`src/client/`** (`@convex-dev/chef-cloud`, `/effects`, `/launcher`, `/ship`, `/daytona`): `chefCloud` (and `chefCrons`, a deprecated no-op), and the host-side steps they are made of.
- **`vendor/marketplace/`**: the Daytona, Code Storage and Resend components, from the marketplace's dist branches (`npm run vendor:marketplace` there).

## Quick start

```ts
// convex/convex.config.ts
import { defineApp } from "convex/server";
import feedback from "@convex-dev/feedback/convex.config";

const app = defineApp();
app.use(feedback);
export default app;
```

```ts
// convex/featureRequests.ts
import { components } from "./_generated/api";
import { Feedback } from "@convex-dev/feedback";

const feedback = new Feedback(components.feedback);

// Wrap with your own auth — the component never calls ctx.auth.
export const submit = mutation({
  args: { title: v.string(), description: v.string() },
  handler: async (ctx, args) => {
    const userId = await requireUserId(ctx); // your auth
    return await feedback.items.create(ctx, { userId, ...args });
  },
});
```

## Refinement questions

Agents can ask clarifying questions through the same `items` + `devLogs`
mechanism — just pass `kind: "refinement"` on create. The user's answer
is posted back as a devLog on the item.

```ts
// Agent: ask
const qId = await feedback.items.create(ctx, {
  userId: "agent",
  title: "What kind of auth?",
  description: "Email/password, magic links, or social?",
  kind: "refinement",
  autoApprove: true,
});

// User UI: answer by posting a devLog
await feedback.devLogs.post(ctx, { itemId: qId, authorId: userId, message: "magic links" });

// Agent: watch for an answer
const open = await feedback.items.listRefinementOpen(ctx);
const replies = await feedback.devLogs.listForItem(ctx, { itemId: qId });
```

Refinement items are filtered out of `items.listPublic` so they never pollute
the feature-request feed.

## Build-mode UI (todos + progress)

Two optional tables power a build-mode "watching the agent" UX:

- `feedback.todos.plan({ items })` / `.advance()` / `.listAll()` — checklist
  the agent fills in as work progresses.
- `feedback.progress.post({ message, kind })` / `.listRecent()` — free-form
  feed of agent updates (`"step" | "shipped" | "note"`).
- `feedback.agentState.snapshot({ mode, limit })` — a CLI-friendly read model
  of todos, progress, refinement questions, and requested/in-progress work.
  Hosts can expose it with a tiny wrapper query so coding agents can inspect
  Chef state with `npx convex run`, without requiring browser auth:

```ts
export const chefAgentState = query({
  args: { limit: v.optional(v.number()) },
  handler: (ctx, args) => feedback.agentState.snapshot(ctx, args),
});
```

Both are unused in production deployments — feel free to ignore them.

### `ChefPanel` widget

`@convex-dev/feedback/react` ships a `ChefPanel` — a floating bubble with
three tabs (Building / Asking / Request) that renders todos, refinement
questions, the progress feed, and feature requests. Like the other
widgets it's host-agnostic: pass your own wrapper-function refs.

```tsx
import { ChefPanel } from "@convex-dev/feedback/react";
import { api } from "./convex/_generated/api";

// Your host exposes a wrapper module (the wow-shell convention is
// `convex/wow.ts`) with these public functions:
<ChefPanel
  api={{
    listOpenRefinements: api.wow.listOpenRefinements,
    answerRefinement: api.wow.answerRefinement,
    skipRefinement: api.wow.skipRefinement,
    listPublicItems: api.wow.listPublicItems,
    submitRequest: api.wow.submitRequest,
    upvoteRequest: api.wow.upvoteRequest,
    listProgress: api.wow.listProgress,
    listTodos: api.wow.listTodos,
    myRole: api.wow.myRole,
    listTriage: api.wow.listTriage,
    decide: api.wow.decide,
    // Optional, from exposeChefApi: snapshot approval and the cloud build view.
    snapshots: {
      prepareApproval: api.chef.prepareApproval,
      approvalSnapshot: api.chef.approvalSnapshot,
      approveSnapshot: api.chef.approveSnapshot,
    },
    cloud: {
      runStatus: api.chef.runStatus,
      recentRuns: api.chef.recentRuns,
      runScreenshots: api.chef.runScreenshots,
      skillFeedback: api.chef.skillFeedback,
      approvalRequests: api.chef.approvalRequests,
      approveApprovalRequest: api.chef.approveApprovalRequest,
      declineApprovalRequest: api.chef.declineApprovalRequest,
      runLogs: api.chef.runLogs,
      retryRun: api.chef.retryRun, // optional: "Try again" on a failed build
    },
    // Optional: "What Chef knows about this app" and what builds cost.
    learnings: {
      appLearnings: api.chef.appLearnings,
      forgetLearning: api.chef.forgetLearning,
      buildCosts: api.chef.buildCosts,
    },
  }}
/>
```

With `snapshots`, the Owner tab's Approve shows the snapshot and "Approve and build" approves its
hash (Reject still calls `decide`). With `cloud`, the Owner tab lists cloud builds; a failed one
shows why and what to do, its checks before and after, its fix rounds, and (with `retryRun`) "Try
again". With `learnings`, it has "What Chef knows about this app". The build view is also exported
on its own: `<CloudBuildView api={cloud} itemId={id} />` (or `runId`), `<CloudBuilds api={cloud} />`
for the list, and `<AppLearnings api={learnings} />`. The `<chef-panel>` web component uses all of
these when the host exports them.

## Attachments (screenshots + voice notes)

Items can carry up to **4 screenshots** (`image/*`, ≤10 MB each) and **1 voice
note** (`audio/*` or `video/mp4`, ≤25 MB). Files live in the component's own
file storage, are deleted by `items.remove`, and move to the target on
`items.merge`. A voice-note transcript is stored on the item as `transcript`
(separate from the editable `description`).

```ts
// convex/wow.ts (host) — auth first, then forward a trusted userId
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    await requireUserId(ctx);
    return await feedback.attachments.generateUploadUrl(ctx);
  },
});

export const submitRequestWithMedia = mutation({
  args: {
    title: v.string(),
    description: v.optional(v.string()),
    transcript: v.optional(v.string()),
    screenshotStorageIds: v.array(v.string()),
    audioStorageId: v.optional(v.string()),
  },
  handler: async (ctx, a) => {
    const userId = await requireUserId(ctx);
    const itemId = await feedback.items.create(ctx, {
      userId, title: a.title, description: a.description ?? "", transcript: a.transcript,
    });
    for (const storageId of a.screenshotStorageIds)
      await feedback.attachments.add(ctx, { itemId, kind: "screenshot", storageId, userId });
    if (a.audioStorageId)
      await feedback.attachments.add(ctx, { itemId, kind: "audio", storageId: a.audioStorageId, userId });
    return itemId;
  },
});

export const listAttachments = query({
  args: { itemId: v.string() },
  handler: async (ctx, a) =>
    feedback.attachments.list(ctx, { itemId: a.itemId, viewer: await getUserId(ctx) }),
});
```

Client upload: `POST` the Blob to the URL with its `Content-Type` header set;
the response is `{ storageId }`. `add` validates type, size, per-item caps, that
the upload is under an hour old, and that it isn't already attached. Uploads
that are never attached stay in component storage (sweep them if that matters).

**Who can read attachments:** the same audience as the item — admins/agents,
the item's creator (`viewer`), and anyone while the item is on the public board
(`items.listPublic` rules; pre-triage items count as public per
`settings.communityBoardVisible`, or per the `includeCommunity` you pass to
`attachments.list` — pass the same value you give `items.listPublic`). Screenshots
can contain private data, so consider turning off `communityBoardVisible` for
apps where pre-triage requests shouldn't be public. The agent HTTP queue
(`GET /agent/queue`) inlines `attachments: [{ kind, url, mimeType }]` per item.

## Approvals (members' requests)

Only admins' requests go straight to the build queue (`autoApprove` is ignored for everyone else);
members' requests wait in `submitted`. Give admins a place to approve them:

```ts
// convex/chef.ts (host)
export const awaitingApproval = query({
  args: {},
  handler: async (ctx) => {
    const me = await getAuthUserId(ctx);
    if (!me) return [];
    const items = await feedback.items.listAwaitingApproval(ctx, { viewer: me }).catch(() => []);
    // + feedback.attachments.listForItems(ctx, { itemIds, viewer: me }) for screenshots / voice notes
    return items.map((i) => ({ id: i._id, title: i.title, description: i.description, from: null, at: i._creationTime, attachments: [] }));
  },
});
export const review = mutation({
  args: { id: v.string(), approve: v.boolean() },
  handler: async (ctx, { id, approve }) =>
    feedback.items.review(ctx, { itemId: id as any, approve, reviewerId: (await getAuthUserId(ctx))! }),
});
```

```tsx
import { ApprovalQueue } from "@convex-dev/feedback/react";
<ApprovalQueue
  api={{
    list: api.chef.awaitingApproval,
    review: api.chef.review,
    // Approve shows the snapshot in full; "Approve and build" approves it.
    snapshots: {
      prepareApproval: api.chef.prepareApproval,
      approvalSnapshot: api.chef.approvalSnapshot,
      approveSnapshot: api.chef.approveSnapshot,
    },
  }}
/>
```

The Chef panel already does all of this; `ApprovalQueue` is for putting the queue somewhere else.

`review` checks the reviewer is an admin, moves `submitted` → `requested` (approve) or `rejected`,
and notifies the requester. To tell admins a request is waiting (e.g. by email), check the new
item's state after `items.create` and message `feedback.users.listAdmins(ctx)`:

```ts
const itemId = await feedback.items.create(ctx, { userId, title, description, autoApprove: true });
if ((await feedback.items.get(ctx, { itemId }))?.state === "submitted") {
  for (const adminId of await feedback.users.listAdmins(ctx)) { /* email / push them */ }
}
```

## Chef cloud builds

An approved request can build itself: Chef clones the app in a sandbox,
runs Claude Code on it, checks it, pushes a branch, deploys a preview, and
emails the owner. "Ship to live" in the panel deploys it. There are no
Daytona, Code Storage or Resend accounts or keys: `@convex-dev/chef-cloud`
composes those marketplace components in gateway mode, the deployment's own
service token is the credential, and usage lands on the team's Convex bill.
The design is `docs/chef-pipeline.md`.

### Turn them on in 3 steps

**1. Install** `@convex-dev/chef-cloud` next to `@convex-dev/feedback`
(vendored, see "Install lines" above; `npx chef init --cloud --write` does
it), and use both:

```ts
// convex/convex.config.ts
import feedback from "@convex-dev/feedback/convex.config.js";
import chefCloud from "@convex-dev/chef-cloud/convex.config.js";

app.use(feedback);
app.use(chefCloud); // Daytona, Code Storage, Resend and @convex-dev/workflow come with it
```

**2. Add the cloud functions.** Next to `exposeChefApi` in `convex/chef.ts`
(in place of `chefAdmin`, whose two functions are in this list):

```ts
import { chefCloud } from "@convex-dev/chef-cloud";

export const {
  chefStep, chefSweep, chefCleanup, chefRunStart, chefShipStart, chefReconcile, chefRepairApply,
  chefSetup, chefSetupStatus, chefEnableCloudBuilds, chefDisableCloudBuilds, chefCreateWorkerKey,
  chefSetAdmin, chefSetPreviewDeployKey, chefSetDeployKey, chefCancelRun, chefMigrateAgentKeys,
  chefRepoSetup, chefRepoUploadUrl, chefRepoPushPack, chefGitCredential, chefRepoRefs, chefIos,
  chefPlanBatches,
} = chefCloud(components.feedback, components.chefCloud);
```

The two components never call each other: these functions, in your app,
call both. The workflows in chef-cloud run each step through `chefStep`,
and the feedback component hands a claimed run to `chefRunStart`, a "Ship
to live" to `chefShipStart`, a stale run's cleanup to `chefReconcile` and
each finished run to `chefCleanup` (setup registers them).

No `convex/crons.ts`: Chef has no crons ("No crons" below). An app that
still has `chefCrons(crons)` there pushes fine; it registers nothing now.

```ts
// convex/http.ts
import { mountChefAgentRoutes } from "@convex-dev/feedback/http";
mountChefAgentRoutes(http, components.feedback);
```

All of them are internal: only your deployment's functions and its CLI
can call them.

**3. Set it up**, once per deployment. `npx chef init` does all of it. By hand:

```sh
npx convex run chef:chefSetup                    # the repo on Code Storage; registers chefStep and the rest
npx convex run chef:chefSetAdmin '{"userId":"<id>"}'  # the app's admin ("your Chef user id" in the panel)
# push your app to the repo's main (npx chef init does; see "The repo functions")
npx convex env set CHEF_PREVIEW_DEPLOY_KEY "$(cat preview-key)"   # a preview deploy key
npx convex run chef:chefSetPreviewDeployKey
npx convex run chef:chefEnableCloudBuilds        # on; each approved request builds
```

For "Ship it", a deploy key for the live deployment:
`npx convex env set CHEF_DEPLOY_KEY "$(cat deploy-key)"` and
`npx convex run chef:chefSetDeployKey`. `chef:chefSetupStatus` shows what
is set up, by name only.

`chefSetup`, `chefRepoSetup`, `chefEnableCloudBuilds` and `chefSetupStatus`
check the feedback component's contract version first (`contract` in the
status). A chef-cloud and a feedback component from different commits that
don't match are refused, with a message saying which is older: install both
from the same commit.

Sandboxes start from `shared:chef-base-1`, a public image with Node, git,
Claude Code, the Convex CLI and local backend, and Playwright, and no app
or Chef code: the launcher writes the runner of the `@convex-dev/feedback`
you have into each sandbox and checks its sha256 there before it runs.

`chefCloud(components.feedback, components.chefCloud, options)`, every option optional:

| Option | Default |
| --- | --- |
| `appName` | "your app", in emails |
| `module` | `"chef"`: where these functions are exported (`convex/chef.ts`) |
| `repoName` | `"app"` |
| `snapshot` | `CHEF_RUNNER_SNAPSHOT`, else `"shared:chef-base-1"` |
| `gates` | `"auto"`: `npm run typecheck`, `npm run lint`, `npm test`, each if package.json has it. Each runs on the untouched checkout first; one that already fails there never fails a build |
| `fixRounds` | `3`: when verification fails in a way the agent can fix (a check that passed before, a guard on its diff, the frontend build), its same Claude Code session gets the failure and another go, up to this many times (0 to 5), within the run's spend cap and deadline |
| `frontend` | Vite: `{ command: ["npm", "run", "build"], urlEnvVar: "VITE_CONVEX_URL", distDir: "dist" }`; `false` for none |
| `localEnv` | `"auto"`: `npm run chef:local-env` if package.json has it, to set the env vars your convex.config requires on the agent's local backend |
| `notify` | off. `{ send, to }` or `{ from, to }` emails the owner when a build is ready or failed and when a release ships or doesn't. `send` is your app's own mailer (see "Use your app's own mail"); without it, `from` sends through Chef's bundled Resend and must be on a sending domain verified for this deployment. `to` is a string or `async (ctx) => email`; null sends nothing |
| `previewLoginFunction`, `seed` | none: `module:function` to run on each preview. `previewLoginFunction` also signs in the build's screenshots on its local backend (`chef-screenshot --signed-in`, the final screenshots), so agents don't write their own way in |
| `beta` | off: `{ siteUrl, deployKeyEnv?, mode? }` deploys each successful build to the app's persistent beta deployment after its preview (`mode: "also"`) or instead of one (`"instead"`); the Ship card then says "Promote to everyone". docs/chef-pipeline.md, "The beta channel" |
| `previewData` | off: `{ exportFunction, seedFunction, maxBytes?, includeFiles? }` lets an admin try previews on a copy of their own data ("admin-copy" in the panel, default "demo"); the contract and an example are in docs/chef-pipeline.md, "Preview data" |
| `ship` | `{ migration?, healthCheck?, siteUrl? }` for "Ship it" |
| `skills` | none: `{ name: SKILL.md text }` for the build agent, read-only to it |
| `runner` | overrides for the delivered runner's config |
| `runnerPath`, `deployPath`, `shipPath` | none: scripts baked into your own image instead of delivered |
| `warmSnapshots` | on, `{ keep: 2 }`: the app's own snapshots with its dependencies already downloaded (below); `false`, or `CHEF_WARM_SNAPSHOTS=0` in the deployment's env, for none |
| `batching` | on: approved requests that touch the same part of the app are built together, at most 4 to a build ("Batching", below); `false` builds every request alone. `{ model }` picks the planner's model |

### Batching: related requests in one build

When more than one approved request is waiting at a claim, Chef asks a
cheap model (Haiku, one call through the Convex AI gateway, a fraction of a
cent) to group the ones that touch the same part of the app: the request's
title, text, the screen it was asked from (`context.screen`, the
`_screen: shelf_` footer) and votes. Each group of 2 to 4 becomes **one
build**: one run, one sandbox, one agent told to implement every request
in it coherently and to say per request what it did. Six requests from
three screens are three builds, not six that collide in the same files.

- Every request in a batch is still built from its own approved snapshot,
  checked by its own hash; the planner only decides which go together, and
  can only answer with request numbers it was given.
- The requests move together: In progress, Ready, Done. Each shows "Built
  together with #2, #3", the Ship card lists them all, and Ship it ships
  them all.
- Until a batch's build starts, an admin can **Split out** a request
  (`splitFromBatch` in `exposeChefApi`; the panel's Up next, ChefKit's
  "Built together"): it builds on its own, where it was in the queue.
- A failed batch is tried once more together, then each request builds on
  its own; one that failed for being too big (the deadline, the spend
  ceiling) is split at once, and a cancel, a security stop or a repo
  problem goes back to the queue as a single build's would.
- No polling: the planning call happens at the claim (approval, a run
  finishing, the button), with one timeout check; a planner that fails or
  doesn't answer in 2 minutes means every request builds alone, as before.
  A claim plans only when something was queued since the last plan.

On by default for chefCloud apps (it registers the planner,
`chefPlanBatches`); `chefCloud(..., { batching: false })` turns it off, and
so does the feedback component's `cloudBatching: false` setting
(`chefSettings.set`). An app that hasn't exported `chefPlanBatches` builds
each request alone. docs/chef-pipeline.md, "Batching".

### Warm snapshots

The slow part of starting a sandbox is installing the app's dependencies
from the registry, and the build, the preview deploy and Ship it each did
it. With warm snapshots (on by default), Chef builds the app's own Daytona
snapshot for its lockfile in the background, the first time a sandbox
finds none: chef-base's recipe plus one layer that runs the same install
(`npm ci --ignore-scripts`, or pnpm frozen without scripts) on only the
committed `package.json` install fields, lockfile and `file:` tarballs,
read from the app's repo at one commit, and keeps npm's cache (or pnpm's
store). That build never holds up a run: sandboxes start from chef-base
until it's ready. After that, a sandbox whose commit has exactly that
lockfile starts from it, and the install is the same command offline;
npm and pnpm still check every package against the lockfile, and any
mismatch or failure installs normally. A run records which snapshot it
used (provenance, the audit log), the runner times "install (warm)"
separately, and `buildCosts` and the panel's cost view show how many
recent installs were warm. At most `keep` per app (the least recently used
are deleted first, never while a sandbox uses one). It needs the default
snapshot and the delivered runner. Cost: snapshot storage (a few GB each)
and a snapshot build per new lockfile.

### Use your app's own mail

If the app already sends email, give Chef its mailer with `notify.send`.
Every Chef email then goes through it, and `from` is unused. `send` runs in
Chef's step action in your app, so it has your `ctx`, env vars and
components. It gets the email already built (HTML escaped, secrets
scrubbed, links checked) and a `kind`: `"built"`, `"failed"`, `"shipped"`
or `"shipFailed"`.

Pass `idempotencyKey` on to your provider. Chef records each email it sent
and never calls `send` twice for the same key, but if the response to a
send is lost, the retried step sends again with the same key. Return the
provider's id if there is one. If `send` throws, Chef logs it, audits it
(`email.failed`, or `release.ship.emailFailed`), and the build or ship goes
on without the email.

With the marketplace's Resend component (`@convex-marketplace/resend`, the
one Chef bundles), which dedupes on `idempotencyKey`:

```ts
import { Resend } from "@convex-marketplace/resend";

const resend = new Resend(components.resend, { testMode: false });

export const { /* ... */ } = chefCloud(components.feedback, components.chefCloud, {
  appName: "My App",
  notify: {
    to: async (ctx) => process.env.OWNER_EMAIL ?? null,
    send: async (ctx, m) => {
      const id = await resend.sendEmail(ctx, {
        from: "My App <chef@mail.example.com>",
        to: m.to,
        subject: m.subject,
        html: m.html,
        text: m.text,
        idempotencyKey: m.idempotencyKey,
      });
      return { id };
    },
  },
});
```

Anything else, from an internal action of your own:

```ts
notify: {
  to: "owner@example.com",
  send: async (ctx, m) => {
    await ctx.runAction(internal.mail.send, {
      to: m.to, subject: m.subject, html: m.html, text: m.text, key: m.idempotencyKey,
    });
  },
},
```

Chef's own Resend child stays installed either way (a component's children
are fixed), but with `send` set nothing calls it.

### The repo functions

For CLIs such as `npx chef init`, through `npx convex run chef:<name>`.
The token never leaves Convex except from `chefGitCredential`, which is
for a git credential helper. Every call is audited as `operator:cli`, in
the feedback component's audit log. The repo itself is chef-cloud's.

| Function | Args | Returns |
| --- | --- | --- |
| `chefRepoSetup` | `{}` | `{ repo, remoteUrl, created }`: creates or adopts the repo, records `remoteUrl` (no credentials), registers `chefStep`, `chefRunStart`, `chefShipStart` and `chefReconcile`. Safe to repeat |
| `chefRepoUploadUrl` | `{}` | an upload URL for a git pack (`git pack-objects --stdout`), POST it with any content type; the response is `{ storageId }` |
| `chefRepoPushPack` | `{ storageId, ref, newSha, oldSha? }` | `{ ref, before, after, updated }`. `ref` is a branch name like `"main"`. Moves it only if it is at `oldSha` now (omit `oldSha` for a new branch): never a force. The same sha again is a no-op. The upload is deleted |
| `chefGitCredential` | `{ write }` | `{ remoteUrl, username, password, expiresAt }`, good for 10 minutes; read-only unless `write` |
| `chefRepoRefs` | `{}` | `{ main: "<sha>", chef: "<sha>", ... }`, every branch by name |
| `chefSetupStatus` | `{}` | what's set up, names only, with `cloudEnabled` (and the same value as `enabled`), `workerKeys` (live worker keys), `adminUserId` (an app admin, or null) and `contract` (the feedback component's contract version, checked) |
| `chefEnableCloudBuilds` | `{ autoBuild?, adminUserId? }` | `{ prefix, alreadyOn, autoBuild }`: creates the cloud key. Refused until an app admin exists |
| `chefSetAdmin` | `{ userId }` | `{ userId, wasAdmin }`: makes an app user an admin. Refuses `operator:` ids |
| `chefDisableCloudBuilds` | `{ reason?, workers?, adminUserId? }` | `{ revoked, workerKeys }`: revokes the cloud keys; worker keys stay unless `workers: true` |
| `chefCreateWorkerKey` | `{ name?, adminUserId? }` | a new worker key, once, as a string: pipe it into `npx chef work --save-key`, or let `npx chef work --setup` do it |
| `chefSetPreviewDeployKey`, `chefSetDeployKey` | `{ adminUserId? }` | `{ prefix }`, from `CHEF_PREVIEW_DEPLOY_KEY` and `CHEF_DEPLOY_KEY` |
| `chefPlanBatches` | `{ planId, requests, maxBatch }` | not for the CLI: the feedback component schedules it (batching). One model call through the AI gateway; answers with `chefBatches.applyPlan` |
| `chefIos` | `{ ref, report? }` | for `npx chef ios`: the run (by run or item id) with its branch, commit and the preview's or beta's Convex URL; with `report: { compiled, installed, device?, error? }`, records it on the run (the card's iOS flag) |
| `chefMigrateAgentKeys` | `{}` | `{ migrated, legacyRemaining, prefixes }`: hashes every /agent/* key still stored in plaintext, to the end. `npx chef init` and `npx chef upgrade` run it |

The functions that act as an admin take an optional `adminUserId` (it must
be an admin) and otherwise act as `operator:cli`, the CLI's own admin
identity, which never counts as the app's admin.

### When a build fails

Builds recover the way a careful engineer would, and stop with one line of
why and what to do when they can't. The design is `docs/chef-pipeline.md`,
"When a build fails".

- **Before anything is paid for.** `npx chef init --cloud` and `npx chef
  sync` run the sandbox's own install check here (`npm ci --dry-run`, or the
  very pnpm the sandbox runs, frozen, with `--lockfile-only`; an offline
  comparison of pnpm-lock.yaml with package.json first) and refuse a
  lockfile the sandbox would refuse, with the command that fixes it.
- **Checks against the base.** After install, before the agent starts, the
  runner runs every gate on the untouched checkout, as the agent user.
  A gate that already fails there (lint with 110 errors on main) is
  "failing before this build" and doesn't block; one that passed before and
  fails after does. The result for a tree and lockfile is kept, so the next
  build on the same base doesn't run it again.
- **Iterating inside the session.** The agent has `chef-check`, which runs
  what the runner verifies (the gates with their baseline, the frontend
  build, the guards in dry run over its changes), and is told to run it
  until it passes. Its answer is advice: the runner verifies again, fresh,
  after the agent is dead. When that fails in a way the agent can fix, the
  runner resumes the agent's same Claude Code session (`--resume`) with
  what failed, then verifies again: up to `fixRounds` times. Tampering (a
  protected path, package.json scripts, a secret) ends the run at once.
- **The platform's failures are tried again.** A sandbox that didn't
  start, a registry or proxy that didn't answer, a runner that went quiet:
  Chef tries the same approved request again on its own, after 1 and then
  5 minutes, at most twice, within one spend cap for all the attempts.
  Anything else waits for a person.
- **Every failure says why.** `runStatus` has `failure: { code, kind,
  reason, action }` ("Lockfile out of date: pnpm-lock.yaml doesn't match
  package.json." / "Run `pnpm install` and commit pnpm-lock.yaml ..."), the
  gates with their baseline (`gates`), the fix rounds with their reasons and
  spend (`rounds`), and what the agent tried (`summary`, `diffStat`). The
  panel shows those, with the raw error folded away.
- **Try again.** `retryRun({ itemId })` (the panel's "Try again" on a
  failed build) re-snapshots the request and, if it is exactly the text
  approved last time, approves it and starts a build in one step, audited.
  A request that changed goes through the normal approval instead. If the
  failed build kept its work (a diff with nothing secret in it), the new
  build starts from it: on the same base as is, or, when `main` moved
  since, applied three-way onto the new `main`, in which case the agent
  only verifies and adjusts it in a shorter session. Work that conflicts
  with the new `main` is dropped and the build starts fresh; the run says
  which happened ("Earlier attempt" in the panel). Kept work goes through
  the same checks and guards as the agent's own.
- **What the deploy refuses is caught before a build is paid for.** The
  preview and "Ship it" deploys refuse a repo that tracks `.env`,
  `.env.local` or `.npmrc`, has any symlink, points `convex.json`'s
  functions outside the repo, or has git dependencies in
  `package-lock.json`. `npx chef init --cloud` and `npx chef sync` check
  the commit for exactly those (FAIL with the paths and the fix, such as
  `git rm --cached <path>`; sync won't push such a `main`), and a build
  checks right after its clone, before the agent runs.
- **A failed deploy says why.** When a deploy script stops, its own
  reason (the line it died with, or the step it was on and the CLI's
  error) is the build's failure, and its last lines are in the run log.
- **Tokens that only live in the sandbox.** The local backend's admin key
  and the sign-in JWTs it issues, which the agent sees while testing, are
  redacted from its transcript and counted in the log, not treated as a
  leak. Any other secret still fails the build, and the diff has no such
  exception.

### The Convex plugin, used

Builds load the official Convex plugin read-only. For any change under
`convex/`, the agent is told to ask the `convex-expert` agent (or the
matching `convex:` skill) before writing it and to run `convex-reviewer` on
its diff before finishing. The runner counts what it used (skills, agents,
hook runs), logs "plugin used: ...", and records it in the run's provenance
(`pluginUsage`) and in what Chef learns about the app.

### What Chef does about a failure

One table (`src/chef/recovery.ts`, `docs/chef-pipeline.md`, "Recovery: one
table for every failure"): the platform's failures are tried again with
backoff (a build, a preview deploy, a ship); the change's own get fix
rounds, and a preview that fails on the build's code gets one follow-up
build that is told why; repo problems Chef can fix mechanically get a repair
offer; everything else says what to do in one line; and a protected path,
a secret in the change or a failed network lockdown stops Chef cold.

### What Chef learns about the app

Each build reports what it saw (how the app installs, its checks and their
baseline, how the frontend builds, the files it changed, each phase's
time) and the agent's own notes about the repo (a fixed set of topics, one
line each, scrubbed). The next build's agent gets a brief of it (about
2,000 tokens, newest first, notes fenced as data), read-only; an entry
nobody reconfirms expires after a few builds. The agent's notes are never
read as config: only the runner's own reports change what a runner does
(a cached baseline for the same tree and lockfile). Admins see it with
`appLearnings`, delete an entry with `forgetLearning`, and see what builds
cost over time with `buildCosts` (with each phase's time, and whether its
install was warm); the panel shows both under "What Chef knows about this
app", with the warm hit rate.

Builds load the official Convex plugin (`convex@claude-plugins-official`,
Apache-2.0) from a pinned copy that ships with the runner
(`vendor/convex-plugin`, refreshed with `scripts/vendor-convex-plugin.mjs`):
its skills, the convex-expert and convex-reviewer agents, and its offline
lint and typecheck hooks, root-owned and read-only. Not its MCP server,
monitors, telemetry or network version check. The version is in each run's
provenance. Skill feedback about its skills keeps the `convex:` prefix.

### Local builds: `npx chef work`

`npx chef work` builds approved requests on the developer's machine with
their own Claude Code (or Codex) login, through the same claim as every
other build: it presents a Chef agent key to `POST /chef-agent/enroll`
every few seconds and builds whatever that claims. The panel shows the run
like a cloud one, marked "built locally". The claim and the routes are the
feedback component's; the app's repo it clones and pushes is chef-cloud's,
so a worker needs chef-cloud installed, with cloud builds on or off.

```sh
npx chef work --setup   # creates a worker key (chefCreateWorkerKey) and saves it, 0600, never shown
npx chef work           # builds until Ctrl-C
```

`npx chef worker-key | npx chef work --save-key` does the same in two
steps (`worker-key` writes only into a pipe).

Chef agent keys come in two kinds:

- a **worker key** (`chefCreateWorkerKey`) only lets a worker enroll and
  claim. It never turns cloud builds on: with only worker keys, approvals
  and "Build in cloud" claim nothing, the panel hides
  "Build in cloud", and a worker's run can't hand off to the cloud preview
  (it finishes without one, or deploys one from the machine with
  `--preview local`). That is **worker-only mode**: chef-cloud installed
  and set up (`npx chef init --cloud`, the repo), cloud builds left off,
  plus a worker key. Nothing is spent on the Convex bill except "Ship it"'s
  deploy sandbox, when an admin ships.
- a **cloud key** (`chefEnableCloudBuilds`) is the on switch for cloud
  builds. `chefDisableCloudBuilds` revokes it and leaves worker keys.

**Only admins' requests build locally.** The worker's agent
holds the developer's reusable login (a long-lived Claude Code token in its
environment, or a readable Codex `auth.json`), and its container can reach
the internet, so text a member wrote could get the agent to send that login
away; approving the exact snapshot doesn't help once it's sent. So a worker
key only ever claims requests an admin wrote: the claim passes over the
rest and leaves them queued for a cloud build, where the agent reaches the
model through a run-bound inference proxy and runs in a sandbox whose
egress Chef controls. Each run records `requestedBy`, and the worker
refuses one that isn't "admin". There is no flag to change this. A safe
local path for members' requests is future work: a host-side inference
proxy holds the login, the agent gets a short-lived capability bound to
its run (fixed provider and model, a budget), and the container's egress
is limited to that proxy and the Chef endpoint.

With both, local and cloud share one queue and one build slot, and
whoever claims first builds. With auto-build on, an approval claims for
the cloud in its own transaction, and so does the end of each run, so the
cloud takes nearly everything and a worker only gets a request that was
left queued (when it enrolls before an approval or a finish claims it). With auto-build off,
approvals wait, a worker claims the oldest one when it next asks, and an
admin can press "Build in cloud" to take one for the cloud instead.

### What's in the components

Everything above is built on these. The run's side is the feedback
component's; the steps that make sandboxes, secrets, emails and pushes are
chef-cloud's, which a host can also wire by hand from
`@convex-dev/chef-cloud/launcher`, `/effects`, `/daytona` and `/ship` (wishbox
does). Each of those takes the host's two components, `{ feedback:
components.feedback, cloud: components.chefCloud }`: the ledger of a run's
side effects is chef-cloud's `effects` table, and the feedback component
checks each new effect against the active run and records what it did
(`chefEffects.checkIntent`, `recordEffect`).

- Approval snapshots: `chefSnapshots.prepareApproval` and `approve`
  (`approvalSnapshot`, `prepareApproval`, `approveSnapshot` in `exposeChefApi`).
  Only a snapshot approval can lead to a cloud build. The panel's Approve
  button is this flow.
- The panel's build view: `runStatus`, `recentRuns`, `runScreenshots`,
  `skillFeedback`, `approvalRequests` (with `approveApprovalRequest` and
  `declineApprovalRequest`) and `runLogs`, all admins only.
- The Chef agent keys (`chefAgentKeys.create({ kind })` / `revoke`),
  hash-only, of two kinds: `"cloud"` (the default; no live cloud key, no
  cloud builds) and `"worker"` (enroll only). External runners present one
  to `POST /chef-agent/enroll` (`mountChefAgentRoutes` from
  `@convex-dev/feedback/http`). Keys from before kinds existed act as cloud
  keys.
- One build at a time: `chefRuns.buildNow` (the "Build in cloud" button,
  `buildInCloud` in `exposeChefApi`, shown by the panel only while
  `buildState` says cloud builds are on), approvals with `cloudAutoBuild`
  on, enroll, the end of each run and cloud builds or auto-build turning on
  all go through one claim mutation. Nothing polls (see "No crons").

### No crons: what Chef schedules and when

An app with Chef installed has no recurring jobs: no cron, no interval, no
self-rescheduling loop while idle. Everything is scheduled once, by the
event that makes it necessary, and does nothing if it is no longer needed.

| What | Scheduled when | Runs | If it finished meanwhile |
| --- | --- | --- | --- |
| Claim the next approved build | approval; any run finishing (built, failed, cancelled, reconciled, given up); a cloud key created; auto-build turned on; Chef's own retry | in that same transaction | nothing to claim: `busy` or `empty` |
| Batch planning (`chefPlanBatches`, the host's) and its timeout check (`chefBatches.planTimeout`) | a claim that finds more than one approved request waiting, one of them new since the last plan | the planner at once (one model call, then the claim); the check 2 minutes later | the check is a no-op once the planner answered |
| A run's deadline check (`chefWatchdog.checkRun`) | the claim; going to reconciling; the check itself while the run is live | at its next deadline: no heartbeat for 15 minutes or past its 90, then the reconciler again after 20 minutes, finished failed after 2 hours | no-op (`watchdogDueAt` no longer matches) |
| A ship's check (`chefWatchdog.checkShip`) | the shipper starting; a transient failure's retry; the check itself while the ship is open | 45 minutes after the ship last changed: started again, a bounded number of times, then it waits for a person | no-op once the release closed |
| A failed or cancelled workflow | chef-cloud's workflow `onComplete` | at once: a run it left active goes to reconciliation | no-op for a run that finished |
| The cleanup sweep (leftover sandboxes and secrets) | each run finishing (the feedback component schedules the host's `chefCleanup`); each ship's workflow ending | on chef-cloud's `chefCleanup` workpool, with retries | deletes nothing a live run or open ship owns |
| Request branches older than 14 days | the sweep, for the oldest branch still waiting | once, on the pool, at that branch's 14 days (one pending at a time) | marks each branch once |
| Rejected-attempt and refusal counts older than 30 days | each new minute's row | in that same transaction, a few at a time; `chefRejected.prune` for the rest | nothing older left |

A check is at most every 15 minutes per live run (a run lives at most 90)
and every 45 per open ship; an idle app has nothing scheduled.
`npx chef cleanup` runs the old sweep by hand (chefCloud's `chefSweep`, then
`chefCleanup`): it claims, checks every live run and ship (arming a check
for any that predates this), and queues the cleanup sweep.

Upgrading from `chefCrons`: install both packages from the same commit
(contract 10 or later) and push (`npx chef upgrade`). The "chef sweep" and "chef
cleanup" crons go away at that push even if `chefCrons(crons)` stays in
`convex/crons.ts`. The next run's start registers the cleanup with the
feedback component (so does `chefSetup`), and a run or ship already live
gets its check from its next heartbeat or claim, `chefSetup`, or `npx chef
cleanup`. Remove the call whenever convenient.

- The Chef agent API, mounted with `mountChefAgentRoutes(http, components.feedback)`:
  `GET /chef-agent/run`, `GET /chef-agent/attachments/<i>`,
  `POST /chef-agent/report` (compare-and-set on the phase), `/log` (keyed by
  `seq`) and `/heartbeat`. Each takes a run credential (`chefr_...`, hash-only,
  scoped, valid only for the active run and its phase); enroll returns one, and
  `chefAgent.issueRunCredentials` returns the pair for a Daytona run. Never
  expose that function to clients.
- An append-only audit log (`chefAudit.list`), admin-only reads.
- **The Ship card** (`buildCard` in `exposeChefApi`, admins only; the
  panel, the React `ShipIt`/`CloudBuildView` and ChefKit show it): for one
  build, or for what Ship it would ship, in one narrow column that reads on
  a phone. "What changed" (2 to 4 bullets) and "What to try" (1 to 3 steps)
  come from the agent's summary, whose first two sections the fixed prompt
  asks for in the owner's words; they are scrubbed when stored and shown
  as text only. Then the preview ("Try it, signed in"), the screenshots, and
  risk flags computed from the diff's paths and changed lines by fixed rules
  (`src/chef/card.ts`), never from what the agent wrote: sign-in or session
  code, new sign-in or token paths, deletes and migrations, schema changes,
  payments and billing, env vars and secrets, sharing and permissions,
  dependencies, iOS code the cloud can't compile. The raw diff is under
  "Details", folded, and loads only when opened. On top, a short video of
  the feature being used on the preview: the agent writes a demo script
  (steps as data: open, click, type, wait), and a sandbox with no secret
  and only the preview as its network plays it with Playwright, signed in
  with a one-time demo link, on a phone and a desktop screen, at most 45
  seconds each (chefCloud's `demo: false` turns it off).
- **Ship it**: the panel's merge button, a cloud release with no laptop
  (`docs/chef-pipeline.md`, "Ship it: a cloud release"). The runner uploads
  `git diff main..<commit>` next to the built frontend, and Chef keeps both
  for the newest built run. An admin ships it by the diff's hash
  (`shipCandidate`, `shipDiffChunk`, `shipApprove` in `exposeChefApi`), which
  opens a `cloud` release and schedules the host's shipper. The shipper
  (`driveShip` from `@convex-dev/chef-cloud/ship`) checks `chef` and `main`
  haven't moved, deploys that commit to the host's own deployment from a
  deploy sandbox that runs no repo code (`runner/chef-ship-deploy.sh`),
  publishes the kept frontend to its static hosting (if `main` moved since
  the build, Chef first merges it in with a merge-only build, no agent, and
  ships on the same approval when the merged change is the one approved;
  `docs/chef-pipeline.md`, "When main moves before Ship it"), runs an optional
  migration and health check, GETs the live site (a ship that reaches
  production and then fails a check is rolled back on its own to the
  release before it, main untouched), and only then
  fast-forwards `main` (compare-and-swap, never a force). Then the release is
  done, its requests completed and requesters notified, and the owner gets
  an email. With chefCloud the ship runs as a workflow in chef-cloud and
  `chefSetDeployKey` is the whole setup. A host wiring it by hand:

  To have GitHub follow what's live (for Xcode Cloud or other CI that builds
  from GitHub), set `CHEF_GITHUB_MIRROR` (`owner/name`) and `CHEF_GITHUB_TOKEN`
  (a fine-grained token, that one repo, Contents read and write): each ship
  then fast-forwards GitHub's `main` to the release, never a force
  (`docs/chef-pipeline.md`, "Mirroring main to GitHub").

  ```sh
  # A deploy key for the live deployment (prod, or the dev deployment the app runs on).
  npx convex env set --prod CHEF_DEPLOY_KEY "$KEY"
  npx convex run --prod chefPipeline:setDeployKey '{"adminUserId":"<your user id>"}'
  npx convex run --prod chefPipeline:registerShipper
  ```

  ```ts
  // convex/chefPipeline.ts (next to the launcher's actions)
  import { driveShip } from "@convex-dev/chef-cloud/ship";
  import { setDeployKey as setKey } from "@convex-dev/chef-cloud/effects";

  const chef = { feedback: components.feedback, cloud: components.chefCloud };
  export const setDeployKey = internalAction({
    args: { adminUserId: v.string() },
    handler: (ctx, args) => setKey(ctx, chef, args),
  });
  export const ship = internalAction({
    args: { releaseId: v.string() },
    handler: (ctx, { releaseId }) =>
      driveShip(ctx, chef, effects(ctx), {
        releaseId,
        config: { gitHost, repoUrl, snapshot, healthCheck: "health:check", notify },
        wait: { sleep: (ms) => new Promise((r) => setTimeout(r, ms)) },
      }),
  });
  export const registerShipper = internalAction({
    args: {},
    handler: async (ctx) =>
      await ctx.runMutation(components.feedback.chefShip.setShipper, {
        handle: await createFunctionHandle(internal.chefPipeline.ship),
      }),
  });
  ```

  The host's `RefsApi` needs `updateRef(ref, { from, to })`: move a branch
  only if it is at `from` (a push without force from a known old value).

## Trust model

The component never reads `ctx.auth` (`exposeChefApi` reads it in *your* module, through the `getUserId` you pass). Every mutation takes a `userId: string` arg — the host authenticates first, then forwards a trusted ID. Works with any auth provider.

## Agent API

Install HTTP routes in one line:

```ts
import { mountAgentRoutes } from "@convex-dev/feedback/http";
mountAgentRoutes(http, components.feedback);
```

Then issue bearer tokens in the admin UI and paste agent prompts into Claude / Cursor / Codex.

Keys come from `feedback.agentKeys.create(ctx, { name, adminUserId })`, which
checks that `adminUserId` is an admin and returns the key once. Convex stores
only its sha256 and a `ship_xxxxxxxx` prefix, and `agentKeys.list(ctx, { viewer })`
returns names, prefixes and scopes (and `[]` to anyone but an admin).

Installs from before hashing have keys stored as plaintext. They keep working,
and each one is hashed the next time it is used, but a key nobody uses would
stay plaintext. So upgrading includes a step: `npx chef upgrade` (or `npx chef
init`, which runs the same step) pushes the functions, runs chefCloud's
`chefMigrateAgentKeys` until every row is hashed, checks that no plaintext
row is left, and prints how many it migrated and their prefixes. Without the CLI, run
`npx convex run chef:chefMigrateAgentKeys` and check that `legacyRemaining`
is false. Any key it migrated sat in the database in the clear, where an
export or a dashboard session could have read it: revoke those with
`agentKeys.revoke(ctx, { id, adminUserId })` and issue new ones. `list` marks
rows not yet hashed with `legacy: true`.

## iOS

**ChefKit** is the drop-in SwiftUI client (floating Chef button, screenshot + voice-note composer, offline outbox,
requests/questions sheet, admin approvals). Add this repo as a Swift package (`https://github.com/sethconvex/feedback`,
product `ChefKit`), add `NSMicrophoneUsageDescription` + `NSSpeechRecognitionUsageDescription` to Info.plist, then:

```swift
import ChefKit
ChefKit.install(client: convex, prefix: "chef")
```

Details: [ios/README.md](ios/README.md). To build the host app in the cloud and put every `main` push on
TestFlight (Chef's sandboxes can't compile Swift), see [docs/ios-xcode-cloud.md](docs/ios-xcode-cloud.md).

## Developing this repo

Two packages, one repo. `@convex-dev/feedback` is the root: its component in
`src/component`, and `example/` a small host app with the board
(`convex.json` points Convex at `example/convex`). `@convex-dev/chef-cloud`
is `packages/chef-cloud/`, with its own component, client, `/test`
entrypoint, `example/` (both components, the way a cloud app has them) and
tests. Generated code comes from Convex itself, against local deployments
(one per package; nothing in the cloud):

```sh
CONVEX_AGENT_MODE=anonymous npx convex dev --once   # first time: a local backend, no account
npm run build:codegen                              # component codegen, build to dist/, app codegen
(cd packages/chef-cloud && CONVEX_AGENT_MODE=anonymous ../../node_modules/.bin/convex dev --once)  # first time
npm run build:cloud && (cd packages/chef-cloud && npm run build:codegen)
npm run typecheck && npm run lint && npm test
```

chef-cloud imports `@convex-dev/feedback` as a peer (its `/delivery`,
`/chef/*` and component types). Here that resolves to this repo's own
`dist/`: `scripts/dev-link.mjs` links `node_modules/@convex-dev/feedback` to
the root and `node_modules/@convex-dev/chef-cloud` to the package, and
`npm run build`, `typecheck`, `test` and `build:cloud` run it. chef-cloud's
dependencies (workflow, workpool, Resend's) are the root's devDependencies,
so a feedback-only app installs none of them. `npm test` runs both
packages' tests; chef-cloud's run the feedback component as the root app
with chef-cloud registered through its own `/test`, as an app has them.

The feedback package's runtime entry points (`.`, `/convex.config`,
`/http`, `/delivery`, `/chef/*`, `/react`) resolve to `dist/`, built by
`npm run build` with `tsconfig.build.json` (and by `prepare`, so installing
from git builds it). `/test` is `src/test.ts`, for hosts' convex-test
suites. chef-cloud's (`.`, `/convex.config`, `/effects`, `/launcher`,
`/ship`, `/daytona`) resolve to its `dist/`; its `/test` registers its
children too.

`npm run build` first runs `scripts/build-runner.mjs`, which bundles the
runner with esbuild into `dist/runner-bundle.mjs` (also the `/runner-bundle`
export) and `dist/runner/`, and generates
`src/client/runnerBundle.generated.ts` (not checked in), the files the
launcher delivers. `npm run typecheck` and `npm test` run it first too.
In `packages/chef-cloud`, `npm run vendor:marketplace` refreshes
`vendor/marketplace/` from the marketplace's dist branches (needs GitHub SSH
access to it); `node scripts/vendor-marketplace.mjs --check` checks it
against `SOURCES.json`.

The contract between the two is `CHEF_CONTRACT_VERSION`
(`src/chef/contract.ts`) and chef-cloud's `FEEDBACK_CONTRACT`: bump both
when what chef-cloud calls in the feedback component, or imports from it,
changes in a way an older chef-cloud can't use.

Shipping:

- `npm run test:consumers` (`scripts/consumer-check.mjs`) packs both
  packages and installs them, as apps do, into two scratch apps: one with
  the board alone (no Daytona, Code Storage, Resend, workflow or workpool in
  its node_modules or its components) and one with cloud builds (both
  components, both `/test` entrypoints, the handshake). Each is pushed once
  to its own local deployment.
- `npm run publish:cloud` (`scripts/publish-dist.sh`) builds chef-cloud and
  commits the packed package to the `dist/chef-cloud` branch, one commit
  per publish naming the source commit (`--dry-run` to look first). Publish
  after pushing `chef-pipeline`, from the same commit.

`npm run e2e:local` (`scripts/local-e2e.mjs`) drives the inference proxy
through the example app on that local backend, including client
cancellation and an upstream that dies mid-stream; results are in
`docs/local-e2e.md`.
