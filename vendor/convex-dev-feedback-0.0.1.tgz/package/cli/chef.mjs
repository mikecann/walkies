#!/usr/bin/env node
// Entry point for `chef` (cli/main.ts). Node 22 runs the
// TypeScript with its type stripping, which it refuses for files under
// node_modules, where this package lives in a host app. So a load hook
// strips the types of this package's own .ts files itself, and a resolve
// hook maps the shared modules' `./x.js` imports to their `.ts` files.
import { register } from "node:module";

const pkgRoot = new URL("../", import.meta.url).href;
const hook = `
import { readFile } from "node:fs/promises";
import { stripTypeScriptTypes } from "node:module";
const root = ${JSON.stringify(pkgRoot)};
export async function resolve(specifier, context, next) {
  try {
    return await next(specifier, context);
  } catch (e) {
    if (e && e.code === "ERR_MODULE_NOT_FOUND" && /^\\.\\.?\\//.test(specifier) && specifier.endsWith(".js")) {
      return await next(specifier.slice(0, -3) + ".ts", context);
    }
    throw e;
  }
}
export async function load(url, context, next) {
  if (url.startsWith(root) && url.endsWith(".ts")) {
    const source = await readFile(new URL(url), "utf8");
    const emit = process.emitWarning;
    process.emitWarning = () => {};
    try {
      return { format: "module", source: stripTypeScriptTypes(source), shortCircuit: true };
    } finally {
      process.emitWarning = emit;
    }
  }
  return next(url, context);
}
`;
register("data:text/javascript," + encodeURIComponent(hook), import.meta.url);

const { main } = await import("./main.ts");
process.exitCode = await main(process.argv.slice(2));
