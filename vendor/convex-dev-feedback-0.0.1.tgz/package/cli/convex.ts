// The Convex CLI, as `chef` uses it: run the host's internal chefCloud
// functions, push the functions, and read and set env vars by name. Values
// that come back (git passwords, env values) stay in memory; error messages
// carry the CLI's stderr, scrubbed, never its stdout.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { scrub } from "../src/chef/scrub.ts";
import { CliError, lastLines, type Deps } from "./deps.ts";

/** A deploy key for one cloud deployment: `prod:<name>|<secret>` or `dev:<name>|<secret>`. */
const DEPLOY_KEY = /^(prod|dev):[a-z0-9-]+\|\S+$/;

export type ConvexTarget = {
  /** The app directory: where `npx convex` finds the project. */
  cwd: string;
  /** The module the host exported chefCloud's functions from (default `chef`). */
  module: string;
  /** Production instead of the dev deployment in .env.local. */
  prod: boolean;
};

export class Convex {
  deps: Deps;
  t: ConvexTarget;

  constructor(deps: Deps, target: ConvexTarget) {
    this.deps = deps;
    this.t = target;
  }

  private async exec(args: string[], input?: string) {
    const [cmd, ...pre] = this.deps.convex;
    return await this.deps.exec(cmd, [...pre, ...args], {
      cwd: this.t.cwd,
      ...(input === undefined ? {} : { input }),
    });
  }

  private prodFlag(): string[] {
    return this.t.prod ? ["--prod"] : [];
  }

  /** `convex run [--prod] <module>:<name> <json>`; the printed result, parsed. */
  async run<R>(name: string, args: Record<string, unknown> = {}): Promise<R> {
    const fn = `${this.t.module}:${name}`;
    const r = await this.exec(["run", ...this.prodFlag(), fn, JSON.stringify(args)]);
    if (r.code !== 0) {
      // `convex run` follows "Could not find function" with every function
      // the deployment has, so its last lines are an unrelated app
      // function's name. Say what it means instead.
      if (/Could not find function/.test(r.stderr)) {
        throw new CliError(`${fn} failed: Could not find function ${fn} on the deployment (it isn't pushed there)`);
      }
      throw new CliError(`${fn} failed: ${scrub(lastLines(r.stderr, 12)) || `exit ${r.code}`}`);
    }
    const out = r.stdout.trim();
    // The CLI prints nothing for null, and JSON otherwise when not on a TTY.
    if (!out) return null as R;
    try {
      return JSON.parse(out) as R;
    } catch {
      throw new CliError(`${fn} printed something that isn't JSON`);
    }
  }

  /** Push the functions once: `convex dev --once`, or `convex deploy` with --prod. */
  async push(): Promise<void> {
    const args = this.t.prod ? ["deploy", "--yes"] : ["dev", "--once"];
    const r = await this.exec(args);
    if (r.code !== 0) {
      throw new CliError(`npx convex ${args.join(" ")} failed:\n${scrub(lastLines(r.stderr || r.stdout, 20))}`);
    }
  }

  /**
   * The names of the deployment's env vars. `env list` prints values too;
   * its output is parsed for names and dropped.
   */
  async envNames(): Promise<Set<string>> {
    const r = await this.exec(["env", "list", ...this.prodFlag()]);
    if (r.code !== 0) throw new CliError(`npx convex env list failed: ${scrub(lastLines(r.stderr, 8))}`);
    const names = new Set<string>();
    for (const line of r.stdout.split("\n")) {
      const m = /^([A-Za-z_][A-Za-z0-9_]*)=/.exec(line);
      if (m) names.add(m[1]);
    }
    return names;
  }

  /**
   * A new deploy key for this deployment (`convex deployment token create`):
   * production with --prod, else the named deployment. The key stays in
   * memory for the caller to hand to envSet; it is never printed.
   */
  async createDeployKey(name: string, deploymentName: string): Promise<string> {
    const target = this.t.prod ? ["--prod"] : ["--deployment", deploymentName];
    const r = await this.exec(["deployment", "token", "create", name, ...target]);
    if (r.code !== 0) {
      throw new CliError(`npx convex deployment token create failed: ${scrub(lastLines(r.stderr, 8)) || `exit ${r.code}`}`);
    }
    const key = r.stdout
      .split("\n")
      .map((l) => l.trim())
      .find((l) => DEPLOY_KEY.test(l));
    if (!key) throw new CliError("npx convex deployment token create printed no deploy key");
    return key;
  }

  /** A deploy key for another deployment (the beta channel's), whatever --prod says. Never printed. */
  async createDeployKeyFor(name: string, deploymentName: string): Promise<string> {
    const r = await this.exec(["deployment", "token", "create", name, "--deployment", deploymentName]);
    if (r.code !== 0) {
      throw new CliError(`npx convex deployment token create failed: ${scrub(lastLines(r.stderr, 8)) || `exit ${r.code}`}`);
    }
    const key = r.stdout
      .split("\n")
      .map((l) => l.trim())
      .find((l) => DEPLOY_KEY.test(l));
    if (!key) throw new CliError("npx convex deployment token create printed no deploy key");
    return key;
  }

  /** Set one env var, its value on stdin so it is never in an argv. */
  async envSet(name: string, value: string): Promise<void> {
    const r = await this.exec(["env", "set", ...this.prodFlag(), name], value);
    if (r.code !== 0) throw new CliError(`npx convex env set ${name} failed: ${scrub(lastLines(r.stderr, 8))}`);
  }
}
