// `chef init`'s preflight: everything the feedback board, or a cloud build,
// needs from the app, checked before anything changes. Every check runs, so
// one pass lists every problem. Reads files and runs git; never the network.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { existsSync, readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import type { Deps } from "./deps.ts";
import { containedPath, OutsideAppError } from "./paths.ts";
import { installPlan } from "../runner/chef-install.mjs";
import { offlineLockfileProblem } from "./lockcheck.ts";
import { deployRefusals, parseLsTreeZ } from "../src/chef/deployChecks.ts";

export const MIN_CONVEX = "1.45.0";
/** The feedback board alone: @convex-dev/feedback's peer range. */
export const MIN_CONVEX_FEEDBACK = "1.35.1";

export type Check = {
  name: string;
  /** "fail" stops init; "warn" is reported and init goes on. */
  status: "ok" | "warn" | "fail";
  detail: string;
  /** Extra lines: what to do about it. */
  help?: string[];
};

export type Deployment = { kind: "dev" | "prod" | "local" | "anonymous" | "self-hosted"; name: string };

export type Frontend = { kind: "vite" | "next" | "none"; urlVar: string | null };

export type PreflightResult = {
  checks: Check[];
  ok: boolean;
  deployment: Deployment | null;
  frontend: Frontend;
  gitRoot: string | null;
  convexDir: string;
};

// ------------------------------------------------------------------ helpers

function readJson(path: string): any {
  try {
    return JSON.parse(readFileSync(path, "utf8"));
  } catch {
    return null;
  }
}

function readText(path: string): string | null {
  try {
    return readFileSync(path, "utf8");
  } catch {
    return null;
  }
}

/** `1.45.2` as [1, 45, 2]; null for anything else. */
export function parseVersion(v: string): [number, number, number] | null {
  const m = /^v?(\d+)\.(\d+)\.(\d+)/.exec(v.trim());
  return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null;
}

export function versionAtLeast(v: string, min: string): boolean {
  const a = parseVersion(v);
  const b = parseVersion(min);
  if (!a || !b) return false;
  for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] > b[i];
  return true;
}

/** A value from a dotenv file, without quotes or a trailing comment. */
export function dotenvValue(text: string, name: string): string | null {
  for (const line of text.split("\n")) {
    const m = new RegExp(`^\\s*(?:export\\s+)?${name}\\s*=\\s*(.*)$`).exec(line);
    if (!m) continue;
    let v = m[1].trim();
    if (/^["']/.test(v)) {
      const q = v[0];
      const end = v.indexOf(q, 1);
      v = end > 0 ? v.slice(1, end) : v.slice(1);
    } else {
      v = v.replace(/\s+#.*$/, "").trim();
    }
    return v;
  }
  return null;
}

/** CONVEX_DEPLOYMENT from the environment, then .env.local, then .env. */
export function readConvexDeployment(appDir: string, env: Record<string, string | undefined>): string | null {
  if (env.CONVEX_DEPLOYMENT) return env.CONVEX_DEPLOYMENT.trim();
  for (const f of [".env.local", ".env"]) {
    const text = readText(join(appDir, f));
    const v = text === null ? null : dotenvValue(text, "CONVEX_DEPLOYMENT");
    if (v) return v;
  }
  return null;
}

/** `dev:happy-cat-123` (a cloud dev or prod deployment), or why not. */
export function parseDeployment(raw: string | null): Deployment | { error: string } {
  if (!raw) return { error: "CONVEX_DEPLOYMENT is not set (no .env.local): run `npx convex dev` once to pick a cloud deployment" };
  const v = raw.replace(/\s+#.*$/, "").trim();
  const m = /^(dev|prod|preview|local|anonymous|self-hosted):(.+)$/.exec(v);
  if (!m) {
    // Old CLIs wrote a bare name for cloud dev deployments.
    if (/^[a-z]+-[a-z]+-\d+$/.test(v)) return { kind: "dev", name: v };
    return { error: `CONVEX_DEPLOYMENT is "${v}", which is not a cloud deployment` };
  }
  const [, kind, name] = m;
  if (kind === "dev" || kind === "prod") return { kind, name };
  if (kind === "preview") return { error: `CONVEX_DEPLOYMENT is a preview deployment (${name}); use the project's dev or prod deployment` };
  return {
    error: `CONVEX_DEPLOYMENT is a ${kind} deployment (${name}). Cloud builds run against a cloud deployment: run \`npx convex dev --configure\` and pick a cloud project`,
  };
}

export type GitDep = { name: string; source: string };

const GIT_SOURCE = /^(git\+|git:|github:|gitlab:|bitbucket:|gist:)|codeload\.github\.com|github\.com[/:]|gitlab\.com[/:]|bitbucket\.org[/:]/;

/**
 * Dependencies installed from git rather than a registry, from the
 * lockfile (npm's in full, others by line) and package.json.
 */
export function gitDependencies(appDir: string): { lockfile: string | null; deps: GitDep[] } {
  const found = new Map<string, string>();
  let lockfile: string | null = null;
  const npm = readJson(join(appDir, "package-lock.json"));
  if (npm) {
    lockfile = "package-lock.json";
    for (const [path, entry] of Object.entries<any>(npm.packages ?? {})) {
      if (!path) continue;
      const source = [entry?.resolved, entry?.version].find((s) => typeof s === "string" && GIT_SOURCE.test(s));
      if (source) found.set(path.replace(/^.*node_modules\//, ""), source);
    }
    const walk = (deps: Record<string, any> | undefined) => {
      for (const [name, entry] of Object.entries<any>(deps ?? {})) {
        const source = [entry?.resolved, entry?.version].find((s) => typeof s === "string" && GIT_SOURCE.test(s));
        if (source) found.set(name, source);
        walk(entry?.dependencies);
      }
    };
    walk(npm.dependencies);
  } else {
    for (const f of ["pnpm-lock.yaml", "yarn.lock", "bun.lock"]) {
      const text = readText(join(appDir, f));
      if (text === null) continue;
      lockfile = f;
      for (const line of text.split("\n")) {
        if (!/(git\+ssh|git\+https|git:\/\/|github:|codeload\.github\.com|\btype: git\b)/.test(line)) continue;
        const name = /["']?((?:@[\w.-]+\/)?[\w.-]+)@/.exec(line.trim())?.[1] ?? line.trim().slice(0, 60);
        found.set(name, line.trim().slice(0, 160));
      }
      break;
    }
  }
  const pkg = readJson(join(appDir, "package.json"));
  for (const field of ["dependencies", "devDependencies", "optionalDependencies"]) {
    for (const [name, spec] of Object.entries<any>(pkg?.[field] ?? {})) {
      if (typeof spec === "string" && (GIT_SOURCE.test(spec) || /^[\w.-]+\/[\w.-]+(#.*)?$/.test(spec)) && !found.has(name)) {
        found.set(name, spec);
      }
    }
  }
  return {
    lockfile,
    deps: [...found].map(([name, source]) => ({ name, source })).sort((a, b) => a.name.localeCompare(b.name)),
  };
}

const VENDOR_HELP = [
  "The build sandbox installs with npm or pnpm and reaches only registry.npmjs.org, not GitHub.",
  "Vendor each one: pack it into the repo and depend on the tarball, e.g.",
  "  npm pack <the git spec> --pack-destination vendor",
  '  then in package.json: "<name>": "file:vendor/<name>-<version>.tgz"',
  "  npm install   # refreshes the lockfile; commit vendor/ with it",
  "A package whose build runs on install (a `prepare` script) should be packed after building.",
];

function walkFiles(dir: string, depth: number, out: string[]) {
  if (depth < 0) return;
  let entries;
  try {
    entries = readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const e of entries) {
    if (e.name === "node_modules" || e.name.startsWith(".") || e.name === "dist" || e.name === "_generated") continue;
    const p = join(dir, e.name);
    if (e.isDirectory()) walkFiles(p, depth - 1, out);
    else if (/\.(tsx?|jsx?|mjs|html)$/.test(e.name)) out.push(p);
  }
}

/** Source files of the frontend (src/, app/, pages/, index.html), a few levels deep. */
export function frontendFiles(appDir: string): string[] {
  const out: string[] = [];
  for (const d of ["src", "app", "pages", "components"]) walkFiles(join(appDir, d), 4, out);
  if (existsSync(join(appDir, "index.html"))) out.push(join(appDir, "index.html"));
  return out;
}

export function detectFrontend(appDir: string): Frontend {
  const pkg = readJson(join(appDir, "package.json")) ?? {};
  const deps = { ...(pkg.dependencies ?? {}), ...(pkg.devDependencies ?? {}) };
  const has = (base: string) =>
    ["ts", "js", "mjs", "mts", "cjs"].some((ext) => existsSync(join(appDir, `${base}.${ext}`)));
  const kind: Frontend["kind"] = has("vite.config") || "vite" in deps ? "vite" : has("next.config") || "next" in deps ? "next" : "none";
  if (kind === "none") return { kind, urlVar: null };
  // The variable the code actually reads, else the convention. The panel
  // runs a ConvexClient, so it needs the .convex.cloud client URL: never a
  // *_SITE_URL (the .convex.site HTTP actions URL), which apps often read too.
  const convention = kind === "vite" ? "VITE_CONVEX_URL" : "NEXT_PUBLIC_CONVEX_URL";
  const re = kind === "vite" ? /import\.meta\.env\.(VITE_\w*CONVEX\w*URL)\b/g : /process\.env\.(NEXT_PUBLIC_\w*CONVEX\w*URL)\b/g;
  const seen: string[] = [];
  for (const f of frontendFiles(appDir)) {
    for (const m of (readText(f) ?? "").matchAll(re)) if (!/SITE/.test(m[1])) seen.push(m[1]);
  }
  return { kind, urlVar: seen.includes(convention) ? convention : (seen[0] ?? convention) };
}

function functionsSetting(appDir: string): string {
  const cfg = readJson(join(appDir, "convex.json"));
  return typeof cfg?.functions === "string" ? cfg.functions.replace(/\/+$/, "") : "convex";
}

/** The functions directory: convex.json's `functions`, else `convex/`. */
export function convexDirOf(appDir: string): string {
  return join(appDir, functionsSetting(appDir));
}

/**
 * Why the functions directory can't be used: convex.json points it outside
 * the app (`..`, an absolute path) or a symlink leads it out. null if fine.
 * init writes into it, so it must be the app's own.
 */
export function functionsDirProblem(appDir: string): string | null {
  const fn = functionsSetting(appDir);
  try {
    containedPath(appDir, fn);
    return null;
  } catch (e) {
    if (e instanceof OutsideAppError) return `convex.json's functions, ${JSON.stringify(fn)}: ${e.message}`;
    throw e;
  }
}

/**
 * What the preview and "Ship it" deploy scripts would refuse in `rev`
 * (src/chef/deployChecks.ts: a tracked .env, .env.local or .npmrc, any
 * symlink, convex.json's functions outside the repo, git dependencies in
 * package-lock.json), as a check with the exact paths and the fix. The
 * cloud deploys what is committed, so it reads the commit, not the working
 * tree. Null when there is no such commit to read.
 */
export async function deployCheck(appDir: string, deps: Deps, rev = "HEAD"): Promise<Check | null> {
  const ls = await deps.exec("git", ["ls-tree", "-r", "-z", "--full-tree", rev], { cwd: appDir });
  if (ls.code !== 0) return null;
  const entries = parseLsTreeZ(ls.stdout);
  const texts = new Map<string, string | null>();
  for (const p of ["convex.json", "package-lock.json"]) {
    if (!entries.some((e) => e.path === p)) continue;
    const x = await deps.exec("git", ["show", `${rev}:${p}`], { cwd: appDir });
    texts.set(p, x.code === 0 ? x.stdout : null);
  }
  const refusals = deployRefusals(entries, (p) => texts.get(p) ?? null);
  if (refusals.length === 0) {
    return { name: "deploy", status: "ok", detail: "nothing committed that the preview deploy refuses" };
  }
  return {
    name: "deploy",
    status: "fail",
    detail: `the preview deploy would refuse this commit: ${refusals.map((r) => r.message).join("; ")}`,
    help: refusals.flatMap((r) => [
      `${r.message}${r.code === "symlinks" ? `: ${r.paths.length} symlink${r.paths.length === 1 ? "" : "s"}` : ""}`,
      ...r.fix.map((l) => `  ${l}`),
    ]),
  };
}

export function cliLoggedIn(home: string): boolean {
  const cfg = readJson(join(home, ".convex", "config.json"));
  return typeof cfg?.accessToken === "string" && cfg.accessToken.length > 0;
}

// ------------------------------------------------------------------ preflight

/**
 * cloud: the cloud build checks too. allowDirty: uncommitted changes are a
 * warning, not a FAIL (`init --write --no-commit`, which commits and pushes
 * nothing).
 */
export async function preflight(
  appDir: string,
  deps: Deps,
  opts: { cloud: boolean; allowDirty?: boolean } = { cloud: true },
): Promise<PreflightResult> {
  const checks: Check[] = [];
  const add = (c: Check) => checks.push(c);
  const minConvex = opts.cloud ? MIN_CONVEX : MIN_CONVEX_FEEDBACK;
  const needs = opts.cloud ? "cloud builds need" : "Chef needs";

  // convex/
  const convexDir = convexDirOf(appDir);
  const rel = convexDir.slice(appDir.length + 1) || "convex";
  const outside = functionsDirProblem(appDir);
  add(
    outside
      ? { name: "functions", status: "fail", detail: outside }
      : existsSync(convexDir)
        ? { name: "functions", status: "ok", detail: `${rel}/` }
        : { name: "functions", status: "fail", detail: `no ${rel}/ directory here; run chef in the app's directory` },
  );

  // convex >= 1.45, the version installed, else the range asked for.
  const installed = readJson(join(appDir, "node_modules", "convex", "package.json"))?.version;
  const pkg = readJson(join(appDir, "package.json"));
  const wanted = pkg?.dependencies?.convex ?? pkg?.devDependencies?.convex;
  if (typeof installed === "string") {
    add(
      versionAtLeast(installed, minConvex)
        ? { name: "convex", status: "ok", detail: installed }
        : { name: "convex", status: "fail", detail: `${installed} is installed; ${needs} ${minConvex} or later`, help: ["npm install convex@latest"] },
    );
  } else if (typeof wanted === "string") {
    const v = wanted.replace(/^[\^~>=\s]+/, "");
    add(
      versionAtLeast(v, minConvex)
        ? { name: "convex", status: "warn", detail: `${wanted} in package.json, but not installed: run npm install` }
        : { name: "convex", status: "fail", detail: `${wanted} in package.json; ${needs} ${minConvex} or later`, help: ["npm install convex@latest"] },
    );
  } else {
    add({ name: "convex", status: "fail", detail: "convex is not a dependency in package.json", help: ["npm install convex@latest"] });
  }

  // The component itself.
  add(
    existsSync(join(appDir, "node_modules", "@convex-dev", "feedback", "package.json"))
      ? { name: "@convex-dev/feedback", status: "ok", detail: "installed" }
      : { name: "@convex-dev/feedback", status: "fail", detail: "not installed in this app", help: ["Add @convex-dev/feedback to package.json (vendored, see below) and npm install"] },
  );

  // CONVEX_DEPLOYMENT
  let deployment: Deployment | null = null;
  if (deps.env.CONVEX_SELF_HOSTED_URL || (readText(join(appDir, ".env.local")) ?? "").match(/^\s*CONVEX_SELF_HOSTED_URL\s*=/m)) {
    add({ name: "deployment", status: "fail", detail: "CONVEX_SELF_HOSTED_URL is set: cloud builds need a Convex cloud deployment, not a self-hosted one" });
  } else {
    const raw = readConvexDeployment(appDir, deps.env);
    const d = parseDeployment(raw);
    const local = raw ? /^(local|anonymous):(.+)$/.exec(raw.replace(/\s+#.*$/, "").trim()) : null;
    if (!("error" in d)) {
      deployment = d;
      add({ name: "deployment", status: "ok", detail: `${d.kind}:${d.name}` });
    } else if (!opts.cloud && local) {
      // The feedback board runs anywhere; only cloud builds need a cloud deployment.
      deployment = { kind: local[1] as "local" | "anonymous", name: local[2] };
      add({ name: "deployment", status: "ok", detail: `${local[1]}:${local[2]}` });
    } else add({ name: "deployment", status: "fail", detail: d.error });
  }

  // git: a repo, a commit, a clean tree.
  let gitRoot: string | null = null;
  const top = await deps.exec("git", ["rev-parse", "--show-toplevel"], { cwd: appDir });
  if (top.code !== 0) {
    add({ name: "git", status: "fail", detail: "not a git repository; cloud builds start from the app's git history", help: ["git init && git add -A && git commit -m 'Initial commit'"] });
  } else {
    gitRoot = top.stdout.trim();
    const head = await deps.exec("git", ["rev-parse", "--verify", "-q", "HEAD"], { cwd: appDir });
    const dirty = await deps.exec("git", ["status", "--porcelain", "--untracked-files=no"], { cwd: appDir });
    if (head.code !== 0) add({ name: "git", status: "fail", detail: "the repository has no commits yet" });
    else if (dirty.stdout.trim()) {
      const files = dirty.stdout.trim().split("\n").slice(0, 8).map((l) => "  " + l);
      add(
        opts.allowDirty
          ? { name: "git", status: "warn", detail: "uncommitted changes; --no-commit leaves them, and init's edits, uncommitted", help: files }
          : { name: "git", status: "fail", detail: "uncommitted changes; commit or stash them first (init pushes HEAD and commits its own edits)", help: files },
      );
    } else add({ name: "git", status: "ok", detail: `clean, HEAD ${head.stdout.trim().slice(0, 12)}` });
  }

  // The rest is for cloud builds: the sandbox installs from the lockfile and
  // builds the frontend, and the CLI login makes the deploy keys.
  const frontend = detectFrontend(appDir);
  if (!opts.cloud) return { checks, ok: checks.every((c) => c.status !== "fail"), deployment, frontend, gitRoot, convexDir };

  // Lockfile and git dependencies.
  const g = gitDependencies(appDir);
  if (g.deps.length > 0) {
    add({
      name: "dependencies",
      status: "fail",
      detail: `${g.deps.length} installed from git: ${g.deps.map((d) => d.name).join(", ")}`,
      help: [...g.deps.map((d) => `  ${d.name}: ${d.source}`), ...VENDOR_HELP],
    });
  } else {
    // What the sandboxes install with (runner/chef-install.mjs): npm or
    // pnpm by the lockfile, or nothing, and then no cloud build can start.
    const plan = installPlan(appDir);
    if ("error" in plan) add({ name: "dependencies", status: "fail", detail: plan.error, help: plan.help });
    else {
      add({ name: "dependencies", status: "ok", detail: `${plan.lockfile}, all from the registry; installs with ${plan.manager === "pnpm" ? `pnpm ${plan.version}` : "npm ci"}` });
      // A pnpm-lock.yaml the sandbox's frozen install would refuse, offline.
      // init runs the sandbox's own install check after this (cli/lockcheck.ts).
      const stale = offlineLockfileProblem(appDir);
      if (stale) add(stale);
    }
  }

  // What the deploy scripts refuse, in what would be pushed: a cloud build
  // of it would pay for the agent and then fail at the preview deploy.
  if (gitRoot !== null) {
    const dc = await deployCheck(appDir, deps);
    if (dc) add(dc);
  }

  // Frontend.
  if (frontend.kind === "vite") add({ name: "frontend", status: "ok", detail: `Vite; reads the deployment URL from ${frontend.urlVar}` });
  else if (frontend.kind === "next") {
    add({ name: "frontend", status: "warn", detail: `Next.js (reads ${frontend.urlVar}); cloud builds build Vite-style static frontends, so the preview may be backend only` });
  } else add({ name: "frontend", status: "warn", detail: "no Vite or Next.js frontend found; previews will be backend only" });

  // CLI login.
  add(
    cliLoggedIn(deps.home)
      ? { name: "convex login", status: "ok", detail: "logged in" }
      : { name: "convex login", status: "fail", detail: "the Convex CLI is not logged in", help: ["npx convex login"] },
  );

  return { checks, ok: checks.every((c) => c.status !== "fail"), deployment, frontend, gitRoot, convexDir };
}

export function renderChecks(checks: Check[]): string[] {
  const lines: string[] = [];
  for (const c of checks) {
    const tag = c.status === "ok" ? "ok  " : c.status === "warn" ? "warn" : "FAIL";
    lines.push(`  ${tag}  ${c.name}: ${c.detail}`);
    if (c.status !== "ok") for (const h of c.help ?? []) lines.push(`        ${h}`);
  }
  return lines;
}
