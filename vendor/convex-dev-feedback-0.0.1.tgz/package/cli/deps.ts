// What the `chef` CLI touches outside itself, so the tests can swap it:
// programs (git, the Convex CLI), HTTP, the terminal and the clock.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { spawn } from "node:child_process";
import { homedir } from "node:os";
import { createInterface } from "node:readline/promises";

export type ExecResult = { code: number; stdout: string; stderr: string; stdoutBytes: Buffer };
export type ExecOpts = {
  cwd: string;
  env?: Record<string, string | undefined>;
  /** Written to the program's stdin (values for `convex env set`, a pack). */
  input?: string | Buffer;
};
export type Exec = (cmd: string, args: string[], opts: ExecOpts) => Promise<ExecResult>;

export type FetchLike = (
  url: string,
  init?: { method?: string; headers?: Record<string, string>; body?: string | Uint8Array },
) => Promise<{ ok: boolean; status: number; text: () => Promise<string> }>;

export type Deps = {
  exec: Exec;
  fetch: FetchLike;
  /** Progress and messages for the person: stderr. */
  log: (line: string) => void;
  /** Results: stdout. The credential helper does not use this. */
  out: (line: string) => void;
  /** Asks a yes/no question; null when there is no terminal to ask on. */
  ask: (question: string) => Promise<string | null>;
  /** Where ~/.convex/config.json lives. */
  home: string;
  env: Record<string, string | undefined>;
  /** How to run the Convex CLI (default `npx convex`, or CHEF_CONVEX_COMMAND). */
  convex: string[];
  /** How to run npm, to vendor @convex-dev/chef-cloud (default `npm`, or CHEF_NPM_COMMAND). */
  npm: string[];
};

/** Spawns a program and collects its output. Never through a shell. */
export const spawnExec: Exec = (cmd, args, opts) =>
  new Promise((done) => {
    const child = spawn(cmd, args, {
      cwd: opts.cwd,
      env: { ...process.env, ...(opts.env ?? {}) },
      stdio: [opts.input === undefined ? "ignore" : "pipe", "pipe", "pipe"],
    });
    const chunks: Buffer[] = [];
    let stderr = "";
    child.stdout!.on("data", (d: Buffer) => chunks.push(d));
    child.stderr!.on("data", (d: Buffer) => (stderr += d.toString("utf8")));
    if (opts.input !== undefined && child.stdin) {
      child.stdin.on("error", () => {});
      child.stdin.end(opts.input);
    }
    const finish = (code: number, extra = "") => {
      const stdoutBytes = Buffer.concat(chunks);
      done({ code, stdout: stdoutBytes.toString("utf8"), stderr: stderr + extra, stdoutBytes });
    };
    child.on("error", (e) => finish(127, String(e)));
    child.on("close", (code) => finish(code ?? 1));
  });

/** A command from an env var: a JSON argv, or words split on spaces. */
function commandFrom(env: Record<string, string | undefined>, name: string, fallback: string[]): string[] {
  const raw = env[name]?.trim();
  if (!raw) return fallback;
  if (raw.startsWith("[")) {
    const argv = JSON.parse(raw);
    if (!Array.isArray(argv) || argv.length === 0 || !argv.every((a) => typeof a === "string")) {
      throw new Error(`${name} must be a JSON array of strings`);
    }
    return argv;
  }
  return raw.split(/\s+/);
}

/** `CHEF_CONVEX_COMMAND`: a JSON argv, or words split on spaces. */
export function convexCommand(env: Record<string, string | undefined>): string[] {
  return commandFrom(env, "CHEF_CONVEX_COMMAND", ["npx", "convex"]);
}

/** `CHEF_NPM_COMMAND`: a JSON argv, or words split on spaces. */
export function npmCommand(env: Record<string, string | undefined>): string[] {
  return commandFrom(env, "CHEF_NPM_COMMAND", ["npm"]);
}

export function defaultDeps(): Deps {
  return {
    exec: spawnExec,
    fetch: async (url, init) => {
      const r = await fetch(url, init as RequestInit);
      return { ok: r.ok, status: r.status, text: () => r.text() };
    },
    log: (line) => process.stderr.write(line + "\n"),
    out: (line) => process.stdout.write(line + "\n"),
    ask: async (question) => {
      if (!process.stdin.isTTY) return null;
      const rl = createInterface({ input: process.stdin, output: process.stderr });
      try {
        return await rl.question(question);
      } finally {
        rl.close();
      }
    },
    home: homedir(),
    env: process.env,
    convex: convexCommand(process.env),
    npm: npmCommand(process.env),
  };
}

export class CliError extends Error {
  code: number;
  constructor(message: string, code = 1) {
    super(message);
    this.code = code;
  }
}

/** The last `n` lines of some output, for an error message. */
export function lastLines(text: string, n: number): string {
  return text.trim().split("\n").slice(-n).join("\n");
}
