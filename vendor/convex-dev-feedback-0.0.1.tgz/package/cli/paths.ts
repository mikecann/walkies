// Containment for the files `chef init` reads its plan from and writes: every
// one must be inside the app directory, by its real path. A relative path
// with `..`, an absolute path, or a symlink anywhere along the way that
// leads out of the app is refused.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { lstatSync, realpathSync } from "node:fs";
import { dirname, isAbsolute, join, sep } from "node:path";

export class OutsideAppError extends Error {}

function within(root: string, path: string): boolean {
  return path === root || path.startsWith(root.endsWith(sep) ? root : root + sep);
}

function lexists(path: string): boolean {
  try {
    lstatSync(path);
    return true;
  } catch {
    return false;
  }
}

/** Why `rel` can't name a file inside the app, by its spelling alone; null if it can. */
export function relativePathProblem(rel: string): string | null {
  if (rel === "" || isAbsolute(rel) || /^[a-zA-Z]:/.test(rel)) return "is not a path inside the app directory";
  if (rel.split(/[\\/]+/).includes("..")) return "leaves the app directory (..)";
  return null;
}

/**
 * The real path for `rel` inside `appDir`, or OutsideAppError. The deepest
 * part that exists is resolved through its symlinks and must still be in
 * the app; a symlink that leads nowhere is refused too.
 */
export function containedPath(appDir: string, rel: string): string {
  const spelled = relativePathProblem(rel);
  if (spelled) throw new OutsideAppError(`${rel} ${spelled}; chef init only edits files inside it`);
  const root = realpathSync(appDir);
  const path = join(root, rel);
  let probe = path;
  while (!lexists(probe)) probe = dirname(probe);
  let real: string;
  try {
    real = realpathSync(probe);
  } catch {
    throw new OutsideAppError(`${rel}: ${probe.slice(root.length + 1)} is a symlink to nothing; chef init won't write through it`);
  }
  if (!within(root, real)) {
    throw new OutsideAppError(`${rel} leads outside the app directory (to ${real}) through a symlink; chef init only edits files inside it`);
  }
  return path;
}
